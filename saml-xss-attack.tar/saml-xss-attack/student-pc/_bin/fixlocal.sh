#!/bin/bash
# ==============================================================================
# Script fixlocal.sh cho may tram kiem thu student-pc (saml-xss-attack)
# Chay tu dong khi container khoi dong de khoi tao moi truong kiem thu
# ==============================================================================

grep -q "$(hostname)" /etc/hosts 2>/dev/null || echo "127.0.0.1 $(hostname)" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "employee.lab" /etc/hosts 2>/dev/null || echo "172.20.0.10 employee.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1

# 1. Thiet lap wrapper script chuan cho Burp Suite Community Edition
if [ -d /usr/local/BurpSuiteCommunity ]; then
    sudo rm -f /usr/local/bin/burpsuite /usr/bin/burpsuite /usr/local/bin/burp /usr/bin/burp
    sudo tee /usr/local/bin/burpsuite > /dev/null << 'EOF'
#!/bin/bash
exec /usr/local/BurpSuiteCommunity/BurpSuiteCommunity "$@"
EOF
    sudo chmod 755 /usr/local/bin/burpsuite
    sudo cp -a /usr/local/bin/burpsuite /usr/bin/burpsuite
    sudo cp -a /usr/local/bin/burpsuite /usr/local/bin/burp
    sudo cp -a /usr/local/bin/burpsuite /usr/bin/burp
fi

# 2. Dam bao ket noi X11 Server cho ung dung do hoa (Burp Suite, Firefox)
if [ -d /var/tmp/.X11-unix ]; then
    sudo mkdir -p /tmp/.X11-unix 2>/dev/null || mkdir -p /tmp/.X11-unix
    sudo ln -sf /var/tmp/.X11-unix/* /tmp/.X11-unix/ 2>/dev/null || true
fi

# 3. Tao bieu tuong Desktop cho Burp Suite tren man hinh sinh vien
mkdir -p /home/ubuntu/Desktop
if [ -f /usr/share/applications/burpsuite.desktop ]; then
    cp /usr/share/applications/burpsuite.desktop /home/ubuntu/Desktop/
    chmod +x /home/ubuntu/Desktop/burpsuite.desktop
    chown -R ubuntu:ubuntu /home/ubuntu/Desktop
fi

# 4. Tao script kiem tra ket noi den he thong SSO
cat << 'EOF_TEST' > /home/ubuntu/test_connection.sh
#!/bin/bash
echo "=== KIỂM TRA KẾT NỐI ĐẾN MÁY CHỦ SSO SERVER ==="
echo "1. Ping đến 172.20.0.10..."
ping -c 2 172.20.0.10

echo ""
echo "2. Kiểm tra dịch vụ Web Portal trên cổng 5001..."
curl -I -s http://employee.lab:5001 | head -n 5

echo ""
echo "3. Kiểm tra dịch vụ Keycloak trên cổng 8080..."
curl -I -s http://172.20.0.10:8080 | head -n 5
EOF_TEST

chmod +x /home/ubuntu/test_connection.sh
chown ubuntu:ubuntu /home/ubuntu/test_connection.sh 2>/dev/null || true
