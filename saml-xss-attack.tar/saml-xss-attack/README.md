# saml-xss-attack: Bài thực hành Khai thác & Phòng thủ SAML Cross-Site Scripting (XSS)

Dự án bài thực hành độc lập được thiết kế theo chuẩn **Labtainers**, tương thích hoàn toàn với trình biên tập đồ họa **Labedit**.

---

## 1. Kiến trúc Hệ thống (System Architecture)

Bài thực hành bao gồm 2 máy ảo (containers) kết nối qua mạng nội bộ `LAN1` (`172.20.0.0/24`):

| Máy ảo | Địa chỉ IP | Vai trò & Dịch vụ |
| :--- | :--- | :--- |
| **`sso-server`** | `172.20.0.10` | • **Apache Reverse Proxy & ModSecurity WAF** (Cổng 5001)<br>• **Ứng dụng Web Flask** (Cổng nội bộ 5000) chứa điểm yếu XSS<br>• **Identity Provider Keycloak SAML 2.0** (Cổng 8080)<br>• **OpenLDAP Server** (Cổng 389) |
| **`student-pc`** | `172.20.0.20` | • Máy trạm của sinh viên kiểm thử bảo mật<br>• Trình duyệt **Mozilla Firefox**<br>• Bộ công cụ kiểm thử **Burp Suite Community Edition** (Cài tự động qua Dockerfile) |

---

## 2. Điểm yếu bảo mật trong Mã nguồn Flask (`app.py`)

Trong ứng dụng web Flask (`/opt/sso-lab/employee_portal/app.py`), khi người dùng đăng nhập qua SSO:
1. Endpoint `/saml/acs` nhận gói tin xác thực SAMLResponse qua phương thức HTTP POST.
2. Ứng dụng giải mã Base64, trích xuất chuỗi định danh từ trường `<saml:NameID>` hoặc các thuộc tính định danh.
3. Thay vì lọc ký tự độc hại (`HTML escape` / `sanitize`), ứng dụng cố tình sử dụng bộ lọc Jinja2:
   ```html
   <div class="stat-value" id="saml-nameid-value">{{ user | safe }}</div>
   ```
4. Bộ lọc `| safe` vô hiệu hóa cơ chế tự động thoát ký tự đặc biệt của Jinja2, khiến cho bất kỳ mã JavaScript nào được tiêm vào Assertion sẽ được trình duyệt thực thi trực tiếp khi hiển thị trang chủ.

---

## 3. Cấu hình Phòng thủ Tường lửa (Defense Configuration)

Tệp tin cấu hình tường lửa `/etc/modsecurity/saml_rules.conf` được khởi tạo sẵn ở trạng thái trống để sinh viên tự viết luật:
- **Nguyên lý hoạt động**: Sử dụng bộ biến đổi `t:base64Decode` của ModSecurity để giải mã trực tiếp dữ liệu gói tin `SAMLResponse` trên bộ nhớ (RAM) mà không làm biến đổi gói tin gửi tới ứng dụng.
- **Biểu thức chính quy**: Quét và phát hiện các thẻ `<script>` hoặc vector XSS nguy hiểm.
- **Hành động**: Ngắt kết nối và trả về mã lỗi `403 Forbidden`.

Mẫu luật ModSecurity tham khảo dành cho sinh viên:
```apache
SecRule REQUEST_URI "@rx ^/saml/acs" \
    "id:200001,\
    phase:2,\
    deny,\
    status:403,\
    log,\
    msg:'Blocked SAML XSS Script Tag Injection',\
    chain"
    SecRule REQUEST_METHOD "@streq POST" "chain"
    SecRule ARGS:SAMLResponse "@rx (?i)(?:<script[\s>]|javascript:|onerror\s*=|onload\s*=|alert\()" "t:base64Decode"
```

Kích hoạt chế độ chặn trong `/etc/modsecurity/modsecurity.conf`:
```apache
SecRuleEngine On
```
Khởi động lại Apache:
```bash
sudo service apache2 restart
```

---

## 4. Hướng dẫn Triển khai & Tương thích Labedit

### Tương thích Labedit
Bài thực hành tuân thủ 100% cấu trúc tệp tin mà công cụ `Labedit` yêu cầu:
- `config/start.config`: Cấu hình mạng LAN1, 2 container và tham số kết nối.
- `config/parameter.config`, `config/about.txt`, `config/keywords.txt`.
- `dockerfiles/Dockerfile.saml-xss-attack.sso-server.student`.
- `dockerfiles/Dockerfile.saml-xss-attack.student-pc.student`.
- `instr_config/goals.config` & `instr_config/results.config`.
- `docs/read_first.txt` & tài liệu bài thực hành.

Để mở bài thực hành trên giao diện Labedit:
```bash
labedit
```
Chọn bài thực hành `saml-xss-attack` để xem sơ đồ mạng và tinh chỉnh thông số.

### Khởi động bài thực hành
```bash
labtainer saml-xss-attack
```

### Đẩy mã nguồn lên GitHub
Do toàn bộ các gói phần mềm dung lượng lớn (Burp Suite, Apache, ModSecurity, Python libraries) đều được cài đặt tự động qua lệnh trong `Dockerfile`, thư mục bài thực hành có dung lượng siêu nhẹ (~3.5MB), sẵn sàng để đẩy lên GitHub:
```bash
cd /home/student/labtainer/trunk/labs/saml-xss-attack
git init
git add .
git commit -m "Initial commit of saml-xss-attack lab"
git branch -M main
git remote add origin <URL-GITHUB-CUA-BAN>
git push -u origin main
```
