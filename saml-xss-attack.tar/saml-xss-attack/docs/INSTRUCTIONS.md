# HƯỚNG DẪN THỰC HÀNH: SAML CROSS-SITE SCRIPTING (XSS) ATTACK & DEFENSE

---

## MỤC TIÊU BÀI HỌC
1. Hiểu rõ luồng trao đổi dữ liệu xác thực của giao thức **SAML 2.0 Web Browser SSO** giữa Service Provider (SP) và Identity Provider (IdP).
2. Nắm vững kỹ thuật khai thác lỗ hổng **Cross-Site Scripting (XSS)** thông qua việc can thiệp và chèn mã độc vào thuộc tính định danh (NameID / Attribute) của gói tin SAML Assertion.
3. Phân tích nguyên nhân gốc rễ của điểm yếu: tắt cơ chế bảo vệ an toàn ký tự của template engine Jinja2 (sử dụng bộ lọc `| safe`).
4. Xây dựng giải pháp phòng thủ chuyên sâu sử dụng **ModSecurity Web Application Firewall (WAF)** trên máy chủ Apache: viết luật giải mã Base64 trên bộ nhớ (`t:base64Decode`) và ngăn chặn các payload độc hại.

---

## BƯỚC 1: KHỞI ĐỘNG VÀ KIỂM TRA MÔI TRƯỜNG

1. Khởi động bài thực hành:
   ```bash
   labtainer saml-xss-attack
   ```
2. Hệ thống sẽ mở 2 cửa sổ terminal tương ứng với 2 máy ảo:
   - `sso-server`: Máy chủ dịch vụ (IP `172.20.0.10`)
   - `student-pc`: Máy trạm sinh viên (IP `172.20.0.20`)
3. Trên máy `sso-server`, kiểm tra các dịch vụ đang chạy:
   ```bash
   sudo docker ps
   sudo service apache2 status
   ps aux | grep "app.py"
   ```
4. Trên máy `student-pc`, kiểm tra kết nối tới máy chủ SSO:
   ```bash
   /home/ubuntu/test_connection.sh
   ```

---

## BƯỚC 2: TIẾN HÀNH TẤN CÔNG (EXPLOITATION PHASE)

1. Mở công cụ **Burp Suite Community Edition** trên `student-pc` từ biểu tượng màn hình Desktop hoặc qua terminal:
   ```bash
   burpsuite &
   ```
2. Mở trình duyệt **Firefox** trên `student-pc`. Cấu hình HTTP Proxy trỏ về Burp Suite (`127.0.0.1:8080`).
3. Truy cập vào cổng thông tin doanh nghiệp:
   `http://employee.lab:5001`
4. Bấm **🔐 Đăng nhập qua SSO (Keycloak)**.
5. Nhập tài khoản xác thực:
   - **Tài khoản**: `nhanvien1`
   - **Mật khẩu**: `password123`
6. Trong Burp Suite, bật tính năng **Intercept is on** (tab `Proxy` -> `Intercept`).
7. Nhấn **Sign In** trên trang Keycloak.
8. Bắt giữ gói tin HTTP POST gửi về URL `/saml/acs`:
   - Quan sát tham số `SAMLResponse` trong phần Body.
   - Chuyển gói tin sang tab **Repeater** (`Ctrl + R`).
9. Giải mã và chỉnh sửa giá trị `SAMLResponse`:
   - Tìm thẻ `<saml:NameID>nhanvien1</saml:NameID>`.
   - Chèn mã độc XSS vào nội dung của NameID, ví dụ:
     ```xml
     <saml:NameID>&lt;script&gt;alert('SAML XSS PWNED!')&lt;/script&gt;</saml:NameID>
     ```
     hoặc sử dụng khối CDATA:
     ```xml
     <saml:NameID><![CDATA[<script>alert(document.cookie)</script>]]></saml:NameID>
     ```
   - Mã hóa toàn bộ chuỗi XML đã sửa đổi về lại chuẩn Base64.
10. Gửi yêu cầu POST tới `/saml/acs` và mở trình duyệt để nhận phản hồi từ trang chủ `/`:
   - Hộp thoại cảnh báo JavaScript hiển thị ngay lập tức trên trình duyệt!
   - Sinh viên đã khai thác thành công lỗ hổng SAML XSS do cơ chế lọc ký tự bị tắt trên Flask!

---

## BƯỚC 3: CẤU HÌNH PHÒNG THỦ TƯỜNG LỬA (DEFENSE PHASE)

1. Chuyển sang máy ảo **`sso-server`**.
2. Mở tệp tin luật tường lửa ModSecurity:
   ```bash
   sudo nano /etc/modsecurity/saml_rules.conf
   ```
3. Viết luật ModSecurity để giải mã Base64 gói tin trong RAM và phát hiện thẻ script:
   ```apache
   SecRule REQUEST_URI "@rx ^/saml/acs" \
       "id:200001,\
       phase:2,\
       deny,\
       status:403,\
       log,\
       msg:'Blocked SAML XSS Script Tag Injection',\
       chain"
       SecRule REQUEST_METHOD "@streq POST" "chain"
       SecRule ARGS:SAMLResponse "@rx (?i)(?:<script[\s>]|javascript:|onerror\s*=|onload\s*=|alert\()" "t:base64Decode"
   ```
4. Kích hoạt chế độ ngăn chặn (Blocking mode) trong `/etc/modsecurity/modsecurity.conf`:
   ```bash
   sudo sed -i 's/^SecRuleEngine DetectionOnly/SecRuleEngine On/' /etc/modsecurity/modsecurity.conf
   ```
5. Kiểm tra cú pháp và khởi động lại Apache:
   ```bash
   sudo apachectl configtest
   sudo service apache2 restart
   ```
6. Chạy script kiểm tra:
   ```bash
   /home/ubuntu/check_defense.sh
   ```

---

## BƯỚC 4: KIỂM TRA LẠI VÀ ĐÁNH GIÁ (VERIFICATION)

1. Từ `student-pc`, sử dụng Burp Suite gửi lại gói tin chứa mã độc XSS.
2. Máy chủ phản hồi ngay lập tức mã trạng thái **`403 Forbidden`**!
3. Kiểm tra log ghi nhận trên `sso-server`:
   ```bash
   sudo tail -n 20 /var/log/apache2/flask_error.log
   ```
   Dòng log ModSecurity hiển thị rõ:
   `ModSecurity: Access denied with code 403 (phase 2)... Blocked SAML XSS Script Tag Injection`
4. Sinh viên đã hoàn thành xuất sắc cả hai nội dung khai thác và phòng thủ!
