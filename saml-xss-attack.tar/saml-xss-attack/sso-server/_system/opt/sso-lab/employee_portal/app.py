import os
import base64
import xml.etree.ElementTree as ET
from flask import Flask, request, redirect, session, render_template_string
from onelogin.saml2.auth import OneLogin_Saml2_Auth
from urllib.parse import urlparse

app = Flask(__name__)
app.secret_key = 'SAML_XSS_LAB_SECRET_KEY_2026'

# ==============================================================================
# CẤU HÌNH TRẠNG THÁI BÀI THỰC HÀNH (SAML XSS LAB):
# False: Chế độ xác thực linh hoạt (cho phép kiểm thử tiêm mã XSS qua Assertion)
# True : Kiểm tra chữ ký số nghiêm ngặt
# ==============================================================================
ENABLE_SIGNATURE_CHECK = False

# Đường dẫn tới thư mục chứa cấu hình SAML (settings.json)
app.config['SAML_PATH'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'saml')

def prepare_flask_request(req):
    url_data = urlparse(req.url)
    return {
        'https': 'on' if req.scheme == 'https' else 'off',
        'http_host': req.host,
        'server_port': url_data.port,
        'script_name': req.path,
        'get_data': req.args.copy(),
        'post_data': req.form.copy()
    }

def init_saml_auth(req):
    return OneLogin_Saml2_Auth(req, custom_base_path=app.config['SAML_PATH'])

def extract_element_content(elem):
    """
    Trích xuất toàn bộ nội dung của phần tử XML bao gồm text và các thẻ con lồng nhau.
    Hỗ trợ đầy đủ: Text thông thường, XML Entity Encoded (&lt;script&gt;),
    CDATA (<![CDATA[<script>...]]>), và thẻ con lồng trực tiếp (<script>...</script>).
    """
    if elem is None:
        return ""
    content = elem.text or ""
    for child in elem:
        content += ET.tostring(child, encoding="unicode")
    return content.strip()

# CSS giao diện doanh nghiệp hiện đại
BASE_STYLE = """
<style>
    :root {
        --primary: #2563eb;
        --primary-hover: #1d4ed8;
        --danger: #dc2626;
        --success: #059669;
        --gray-50: #f8fafc;
        --gray-100: #f1f5f9;
        --gray-200: #e2e8f0;
        --gray-300: #cbd5e1;
        --gray-500: #64748b;
        --gray-600: #475569;
        --gray-700: #334155;
        --gray-900: #0f172a;
    }
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    body {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        background: linear-gradient(135deg, #f0f4f9 0%, #e2e8f0 100%);
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 32px 16px;
        color: var(--gray-900);
    }
    .wrapper {
        width: 100%;
        max-width: 800px;
    }
    .card {
        background: #ffffff;
        border-radius: 18px;
        box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04);
        border: 1px solid var(--gray-200);
        overflow: hidden;
        animation: fadeIn 0.35s ease-out;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    .card-header {
        padding: 24px 32px;
        border-bottom: 1px solid var(--gray-100);
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: #ffffff;
        flex-wrap: wrap;
        gap: 16px;
    }
    .brand {
        display: flex;
        align-items: center;
        gap: 16px;
    }
    .brand-icon {
        width: 50px;
        height: 50px;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
        color: #ffffff;
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.25);
    }
    .brand-title {
        font-size: 20px;
        font-weight: 700;
        color: var(--gray-900);
        line-height: 1.25;
    }
    .brand-subtitle {
        font-size: 13px;
        color: var(--gray-500);
        margin-top: 3px;
    }
    .pill {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 14px;
        border-radius: 9999px;
        font-size: 12px;
        font-weight: 600;
    }
    .pill-green {
        background: #ecfdf5;
        color: #065f46;
        border: 1px solid #a7f3d0;
    }
    .pill-red {
        background: #fef2f2;
        color: #991b1b;
        border: 1px solid #fecaca;
    }
    .status-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #10b981;
    }
    .card-body {
        padding: 32px;
    }
    .alert-banner {
        background: #eff6ff;
        border: 1px solid #bfdbfe;
        border-radius: 12px;
        padding: 16px 20px;
        margin-bottom: 24px;
    }
    .welcome-title {
        font-size: 18px;
        font-weight: 700;
        color: #1e40af;
        margin-bottom: 6px;
    }
    .stat-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 16px;
        margin-bottom: 24px;
    }
    .stat-card {
        background: var(--gray-50);
        border: 1px solid var(--gray-200);
        border-radius: 12px;
        padding: 16px;
    }
    .stat-label {
        font-size: 11px;
        font-weight: 700;
        color: var(--gray-500);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 6px;
    }
    .stat-value {
        font-size: 15px;
        font-weight: 600;
        color: var(--gray-900);
        word-break: break-all;
    }
    .section-title {
        font-size: 13px;
        font-weight: 700;
        color: var(--gray-700);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 12px;
    }
    .table-box {
        border: 1px solid var(--gray-200);
        border-radius: 12px;
        overflow: hidden;
        margin-bottom: 24px;
    }
    .data-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 14px;
    }
    .data-table th {
        background: var(--gray-50);
        padding: 12px 18px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: var(--gray-500);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        border-bottom: 1px solid var(--gray-200);
    }
    .data-table td {
        padding: 12px 18px;
        border-bottom: 1px solid var(--gray-100);
        color: var(--gray-700);
    }
    .data-table tr:last-child td {
        border-bottom: none;
    }
    .code-val {
        background: var(--gray-100);
        padding: 4px 10px;
        border-radius: 6px;
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 13px;
        color: var(--gray-900);
        border: 1px solid var(--gray-200);
        word-break: break-all;
    }
    .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 13px 24px;
        border-radius: 10px;
        font-size: 15px;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.2s ease;
        border: none;
    }
    .btn-login {
        width: 100%;
        background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
        color: #ffffff;
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.25);
    }
    .btn-login:hover {
        background: linear-gradient(135deg, #1d4ed8 0%, #1e40af 100%);
        box-shadow: 0 6px 16px rgba(37, 99, 235, 0.35);
        transform: translateY(-1px);
    }
    .btn-logout {
        background: #ffffff;
        color: #475569;
        border: 1px solid var(--gray-300);
    }
    .btn-logout:hover {
        background: #f8fafc;
        color: #0f172a;
        border-color: var(--gray-500);
    }
    .card-footer {
        padding: 16px 32px;
        background: var(--gray-50);
        border-top: 1px solid var(--gray-100);
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        color: var(--gray-500);
        flex-wrap: wrap;
        gap: 8px;
    }
    .subtle-footer {
        text-align: center;
        margin-top: 20px;
        font-size: 13px;
        color: var(--gray-500);
    }
</style>
"""

# Template trang chủ khi người dùng đã đăng nhập thành công
# ĐIỂM YẾU BẢO MẬT CỐ Ý:
# Sử dụng bộ lọc Jinja2 "| safe" để hiển thị trực tiếp trường định danh người dùng
# trích xuất từ SAML Assertion mà không qua cơ chế lọc ký tự an toàn (HTML escaping / sanitization).
AUTHENTICATED_TEMPLATE = """<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cổng Thông Tin Dịch Vụ - SAML SSO Portal</title>
    {{ BASE_STYLE | safe }}
</head>
<body>
    <div class="wrapper">
        <div class="card">
            <div class="card-header">
                <div class="brand">
                    <div class="brand-icon">🛡️</div>
                    <div>
                        <div class="brand-title">Cổng Thông Tin Dịch Vụ Doanh Nghiệp</div>
                        <div class="brand-subtitle">Hệ thống Single Sign-On (SAML 2.0 Web SSO)</div>
                    </div>
                </div>
                <div class="pill pill-green">
                    <span class="status-dot"></span>
                    Phiên xác thực thành công
                </div>
            </div>
            <div class="card-body">
                <!-- VÙNG HIỂN THỊ ĐỊNH DANH NGƯỜI DÙNG: CỐ TÌNH DÙNG BỘ LỌC | safe ĐỂ TẮT CƠ CHẾ LỌC AN TOÀN -->
                <div class="alert-banner">
                    <div class="welcome-title">Xin chào: {{ user | safe }}</div>
                    <div style="font-size: 14px; color: #475569;">
                        Phiên làm việc của bạn đã được khởi tạo thành công từ Identity Provider (Keycloak).
                    </div>
                </div>

                <div class="stat-grid">
                    <div class="stat-card">
                        <div class="stat-label">Định danh SAML (NameID)</div>
                        <!-- VULNERABILITY: Hiển thị trực tiếp mã định danh không qua sanitization -->
                        <div class="stat-value" id="saml-nameid-value">{{ user | safe }}</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-label">Phương thức xác thực</div>
                        <div class="stat-value">SAML 2.0 Assertion</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-label">Cơ chế bảo vệ ký tự Jinja2</div>
                        <div class="stat-value" style="color: #dc2626; font-weight: 700;">Đã tắt (| safe filter)</div>
                    </div>
                </div>

                <div class="section-title">Thuộc tính Assertion nhận được từ SAML Response:</div>
                <div class="table-box">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Thuộc tính</th>
                                <th>Giá trị xác thực (Unescaped / Safe Filter)</th>
                            </tr>
                        </thead>
                        <tbody>
                            {% for key, val in attrs.items() %}
                            <tr>
                                <td style="font-weight: 600; width: 35%;">{{ key }}</td>
                                <td><span class="code-val">{{ val | safe }}</span></td>
                            </tr>
                            {% endfor %}
                        </tbody>
                    </table>
                </div>

                <div style="display: flex; justify-content: flex-end; margin-top: 12px;">
                    <a href="/logout" class="btn btn-logout">🚪 Đăng xuất (Sign Out)</a>
                </div>
            </div>
            <div class="card-footer">
                <span>Định danh phiên: <b>{{ user | safe }}</b></span>
                <span>Bài thực hành: <b>saml-xss-attack</b></span>
            </div>
        </div>
        <div class="subtle-footer">
            Môi trường Kiểm thử An toàn Thông tin • Khai thác & Phòng thủ SAML XSS
        </div>
    </div>
</body>
</html>
"""

# Template trang chủ khi chưa đăng nhập
LOGIN_TEMPLATE = """<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cổng Thông Tin Doanh Nghiệp - SAML SSO</title>
    {{ BASE_STYLE | safe }}
</head>
<body>
    <div class="wrapper">
        <div class="card">
            <div class="card-header">
                <div class="brand">
                    <div class="brand-icon">🏢</div>
                    <div>
                        <div class="brand-title">Cổng Thông Tin Dịch Vụ Doanh Nghiệp</div>
                        <div class="brand-subtitle">Hệ thống Đăng nhập một lần (SAML 2.0 Single Sign-On)</div>
                    </div>
                </div>
                <div class="pill pill-green">
                    <span class="status-dot"></span>
                    Sẵn sàng kết nối
                </div>
            </div>
            <div class="card-body">
                <p style="font-size: 15px; color: #475569; line-height: 1.6; margin-bottom: 24px;">
                    Chào mừng bạn đến với Cổng Dịch vụ Doanh nghiệp. Hệ thống được tích hợp giải pháp Single Sign-On (SSO) sử dụng tiêu chuẩn SAML 2.0 qua máy chủ định danh Keycloak.
                </p>
                <div class="stat-grid">
                    <div class="stat-card">
                        <div class="stat-label">Giao thức xác thực</div>
                        <div class="stat-value">SAML 2.0 Web Browser SSO</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-label">Identity Provider (IdP)</div>
                        <div class="stat-value">Keycloak (sso-lab)</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-label">Service Provider (SP)</div>
                        <div class="stat-value">Flask Employee Portal</div>
                    </div>
                </div>
                <a href="/saml/login" class="btn btn-login">
                    🔐 Đăng nhập qua SSO (Keycloak)
                </a>
            </div>
            <div class="card-footer">
                <span>Service Provider (ACS): <b>/saml/acs</b></span>
                <span>Bài thực hành: <b>saml-xss-attack</b></span>
            </div>
        </div>
        <div class="subtle-footer">
            Hệ thống Quản lý Danh tính Doanh nghiệp • Labtainers Security Lab
        </div>
    </div>
</body>
</html>
"""

# Route 1: Trang chủ Dashboard
@app.route('/')
def index():
    if 'samlNameId' in session:
        user = session['samlNameId']
        attrs = session.get('samlUserdata', {})
        # Cố ý render biến `user` và `attrs` bằng bộ lọc | safe của Jinja2
        # Tắt cơ chế lọc an toàn để mã độc JavaScript hoạt động nếu người dùng tiêm thành công
        return render_template_string(
            AUTHENTICATED_TEMPLATE,
            user=user,
            attrs=attrs,
            BASE_STYLE=BASE_STYLE
        )
    return render_template_string(LOGIN_TEMPLATE, BASE_STYLE=BASE_STYLE)

# Route 2: Bắt đầu quy trình SSO - Chuyển hướng người dùng sang Keycloak
@app.route('/saml/login')
def login():
    req = prepare_flask_request(request)
    auth = init_saml_auth(req)
    return redirect(auth.login())

# Route 3: Assertion Consumer Service (ACS) - Điểm tiếp nhận SAML Response
@app.route('/saml/acs', methods=['POST'])
def acs():
    req = prepare_flask_request(request)
    auth = init_saml_auth(req)
    
    if not ENABLE_SIGNATURE_CHECK:
        # Chế độ kiểm thử khai thác lỗ hổng:
        # Bỏ qua kiểm tra chữ ký số để mô phỏng lỗi kiểm tra xác thực lỏng lẻo ở tầng Service Provider
        saml_b64 = request.form.get('SAMLResponse', '')
        if not saml_b64:
            return "Lỗi: Không tìm thấy tham số SAMLResponse trong yêu cầu POST!", 400

        try:
            # Làm sạch chuỗi Base64
            clean_b64 = saml_b64.strip().replace(' ', '+')
            missing_padding = len(clean_b64) % 4
            if missing_padding:
                clean_b64 += '=' * (4 - missing_padding)

            xml_data = base64.b64decode(clean_b64)
            # Loại bỏ Byte Order Mark (BOM) nếu có
            if xml_data.startswith(b'\xef\xbb\xbf'):
                xml_data = xml_data[3:]

            root = ET.fromstring(xml_data)

            # Namespace SAML 2.0
            ns = {
                'saml': 'urn:oasis:names:tc:SAML:2.0:assertion',
                'saml2': 'urn:oasis:names:tc:SAML:2.0:assertion'
            }

            # Tìm trường NameID
            name_id_elem = root.find('.//{urn:oasis:names:tc:SAML:2.0:assertion}NameID')
            if name_id_elem is None:
                name_id_elem = root.find('.//saml:NameID', ns)
            if name_id_elem is None:
                name_id_elem = root.find('.//saml2:NameID', ns)
            if name_id_elem is None:
                for elem in root.iter():
                    if elem.tag.endswith('NameID') or elem.tag == 'NameID':
                        name_id_elem = elem
                        break

            # Trích xuất trường thông tin định danh
            username = extract_element_content(name_id_elem)

            # Trích xuất các thuộc tính mở rộng (SAML Attributes)
            attrs = {}
            for attr_elem in root.iter():
                if attr_elem.tag.endswith('Attribute'):
                    attr_name = attr_elem.get('Name') or attr_elem.get('FriendlyName') or 'attribute'
                    val_elem = None
                    for child in attr_elem:
                        if child.tag.endswith('AttributeValue'):
                            val_elem = child
                            break
                    if val_elem is not None:
                        attrs[attr_name] = extract_element_content(val_elem)

            if not attrs:
                attrs = {
                    'username': username,
                    'role': 'employee',
                    'auth_method': 'urn:oasis:names:tc:SAML:2.0:ac:classes:Password'
                }

            if username:
                session['samlNameId'] = username
                session['samlUserdata'] = attrs

                # Ghi log sự kiện xác thực để đánh giá kết quả thực hành (Results Assessment)
                log_entry = f"[AUTH] SAML Assertion received. Identity extracted: {username}\n"
                print(log_entry.strip(), flush=True)

                try:
                    with open('/opt/sso-lab/employee_portal/flask.log', 'a') as f:
                        f.write(log_entry)
                except Exception:
                    pass

                try:
                    with open('/var/log/apache2/flask_access.log', 'a') as f:
                        f.write(f"127.0.0.1 - {username} [AUTH] SAML ACS 200 OK Identity: {username}\n")
                except Exception:
                    pass

                return redirect('/')
            else:
                return "Lỗi SAML: Không tìm thấy trường NameID hợp lệ trong Assertion!", 400

        except Exception as e:
            return f"Lỗi xử lý SAML XML: {str(e)}", 400

    else:
        # Kịch bản kiểm tra chữ ký số nghiêm ngặt
        auth.process_response()
        errors = auth.get_errors()

        if not errors and auth.is_authenticated():
            session['samlUserdata'] = auth.get_attributes()
            session['samlNameId'] = auth.get_nameid()
            return redirect('/')
        else:
            reason = auth.get_last_error_reason()
            return f"Lỗi xác thực chữ ký số SAML: {reason}", 403

# Route 4: Cung cấp Service Provider Metadata cho Identity Provider
@app.route('/saml/metadata')
def metadata():
    req = prepare_flask_request(request)
    auth = init_saml_auth(req)
    settings = auth.get_settings()
    metadata_content = settings.get_sp_metadata()
    errors = settings.validate_metadata(metadata_content)
    if len(errors) == 0:
        return metadata_content, 200, {'Content-Type': 'text/xml'}
    else:
        return ', '.join(errors), 500

# Route 5: Đăng xuất và xóa phiên làm việc
@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)
