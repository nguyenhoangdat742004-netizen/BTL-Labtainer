#!/bin/bash
# ==============================================================================
# Script fixlocal.sh cho may chu sso-server (saml-xss-attack)
# Chay tu dong khi container khoi dong de khoi tao moi truong va quyen han
# ==============================================================================

# 1. Dam bao /etc/hosts co hostname
grep -q "$(hostname)" /etc/hosts 2>/dev/null || echo "127.0.0.1 $(hostname)" | sudo tee -a /etc/hosts >/dev/null

# 2. Dam bao quyen so huu cho user ubuntu
sudo chown -R ubuntu:ubuntu /opt/sso-lab 2>/dev/null || true

# 3. Khoi tao cac file log rong va cap quyen ghi
sudo mkdir -p /var/log/apache2
sudo touch /var/log/apache2/flask_error.log /var/log/apache2/flask_access.log /var/log/apache2/modsec_audit.log /var/log/apache2/error.log
sudo truncate -s 0 /var/log/apache2/flask_error.log 2>/dev/null || true
sudo truncate -s 0 /var/log/apache2/flask_access.log 2>/dev/null || true
sudo truncate -s 0 /var/log/apache2/modsec_audit.log 2>/dev/null || true
sudo truncate -s 0 /var/log/apache2/error.log 2>/dev/null || true
sudo touch /opt/sso-lab/employee_portal/flask.log
sudo truncate -s 0 /opt/sso-lab/employee_portal/flask.log 2>/dev/null || true
sudo chown ubuntu:ubuntu /opt/sso-lab/employee_portal/flask.log 2>/dev/null || true
sudo chmod 755 /var/log/apache2 2>/dev/null || true
sudo usermod -a -G adm ubuntu 2>/dev/null || true
sudo chmod 666 /var/log/apache2/*.log 2>/dev/null || true
sudo chown ubuntu:ubuntu /var/log/apache2/flask_access.log 2>/dev/null || true

# 4. Dam bao tep tin saml_rules.conf ton tai va rong de sinh vien tu viet luat
if [ ! -f /etc/modsecurity/saml_rules.conf ]; then
    sudo touch /etc/modsecurity/saml_rules.conf
fi
sudo chmod 666 /etc/modsecurity/saml_rules.conf 2>/dev/null || true

# Dam bao SecRuleEngine o che do DetectionOnly khi moi bat dau bai thuc hanh
sudo sed -i 's/^SecRuleEngine On/SecRuleEngine DetectionOnly/' /etc/modsecurity/modsecurity.conf 2>/dev/null || true

# 5. Tao script khoi dong dich vu start_sso.sh trong thu muc home cua user ubuntu
cat << 'EOF' > /home/ubuntu/start_sso.sh
#!/bin/bash
grep -q "$(hostname)" /etc/hosts 2>/dev/null || echo "127.0.0.1 $(hostname)" | sudo tee -a /etc/hosts >/dev/null 2>&1
echo "[+] 1. Đang khởi động Identity Provider (Keycloak) và OpenLDAP..."
cd /opt/sso-lab
sudo chown -R ubuntu:ubuntu /opt/sso-lab 2>/dev/null || true
sudo docker rm -f openldap phpldapadmin keycloak 2>/dev/null || true
sudo docker-compose down 2>/dev/null || true
sudo docker-compose up -d

echo "[+] 2. Đợi dịch vụ Keycloak và OpenLDAP sẵn sàng (15s)..."
sleep 15

echo "[+] 3. Đang khởi động Web Flask (Backend Port 5000)..."
sudo chmod 755 /var/log/apache2 2>/dev/null || true
sudo chmod 666 /var/log/apache2/flask_access.log /var/log/apache2/flask_error.log 2>/dev/null || true
cd /opt/sso-lab/employee_portal
sudo pkill -f "python3 app.py" 2>/dev/null || true
nohup python3 app.py >> flask.log 2>&1 &
sleep 2

echo "[+] 4. Đang khởi động Apache Web Server & ModSecurity WAF (Port 5001)..."
sudo service apache2 restart
sleep 2

echo "====================================================================="
echo "[THÀNH CÔNG] Toàn bộ hệ thống dịch vụ SSO và Web Flask đã hoạt động!"
echo "URL truy cập: http://172.20.0.10:5001 hoặc http://employee.lab:5001"
echo "Tệp luật tường lửa phòng thủ: /etc/modsecurity/saml_rules.conf"
echo "====================================================================="
EOF

chmod +x /home/ubuntu/start_sso.sh
chown ubuntu:ubuntu /home/ubuntu/start_sso.sh 2>/dev/null || true

# 6. Tao script huong dan kiem tra phong thu check_defense.sh
cat << 'EOF_CHECK' > /home/ubuntu/check_defense.sh
#!/bin/bash
echo "=== KIỂM TRA TRẠNG THÁI TƯỜNG LỬA MODSECURITY ==="
echo "1. Chế độ SecRuleEngine trong /etc/modsecurity/modsecurity.conf:"
grep -E "^SecRuleEngine" /etc/modsecurity/modsecurity.conf || echo "Chưa cấu hình SecRuleEngine!"

echo ""
echo "2. Nội dung luật phòng thủ trong /etc/modsecurity/saml_rules.conf:"
cat /etc/modsecurity/saml_rules.conf

echo ""
echo "3. Kiểm tra cú pháp cấu hình Apache:"
sudo apachectl configtest

echo ""
echo "4. Kiểm tra dịch vụ Apache:"
sudo service apache2 status | grep -E "Active:"
EOF_CHECK

chmod +x /home/ubuntu/check_defense.sh
chown ubuntu:ubuntu /home/ubuntu/check_defense.sh 2>/dev/null || true

# 7. Tu dong chay start_sso.sh khi container khoi dong
/home/ubuntu/start_sso.sh > /home/ubuntu/autostart.log 2>&1 &
