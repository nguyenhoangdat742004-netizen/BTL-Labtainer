# saml-replay-attack: Khai thác và Vá lỗ hổng Phát lại gói tin SAML (SAML Replay Attack)

Bài thực hành mô phỏng kỹ thuật tấn công **SAML Assertion Replay Attack** trên ứng dụng Web tích hợp cơ chế Single Sign-On (SAML 2.0 Web SSO) và giải pháp phòng thủ của DevSecOps bằng cách kích hoạt chế độ **Strict**, kiểm tra mốc thời gian và lưu vết **Assertion ID** trong bộ nhớ đệm (Replay Cache).

---

## 1. Cấu trúc bài thực hành (2 máy ảo kết nối trong LAN1: 172.20.0.0/24)
- **`sso-server` (`172.20.0.10`):** Máy chủ dịch vụ vận hành:
  - Keycloak Identity Provider (Port 8080) với Realm `sso-lab`.
  - Cổng ứng dụng Service Provider bằng Python Flask (Port 5000) với giao diện người dùng phong cách Bootstrap 5 (Light Theme).
  - Điểm yếu cố ý: Tệp `settings.json` cấu hình `"strict": false`, tắt kiểm tra thời gian `NotOnOrAfter` và không ghi nhớ `Assertion ID` của các gói tin đã nhận.
- **`student-pc` (`172.20.0.20`):** Máy trạm kiểm thử của sinh viên, được cài đặt tự động trình duyệt Firefox và công cụ Burp Suite Community Edition thông qua `wget` trong Dockerfile.

---

## 2. Tiêu chí đánh giá tự động (6 Goals)
1. `1_login_initial`: Xác nhận sinh viên đã đăng nhập hợp lệ lần đầu thành công vào ứng dụng Flask qua Keycloak SSO.
2. `2_session_logged_out`: Xác nhận sinh viên đã thực hiện thao tác Đăng xuất (Logout) thành công.
3. `3_replay_attack_success`: Quét log của Flask xác nhận sinh viên đã bypass thành công bằng cách phát lại gói tin cũ (Replay Attack).
4. `4_config_patched`: Xác nhận sinh viên đã chỉnh sửa đúng các thông số bảo mật (`"strict": true`, kích hoạt `check_timestamps` và `replay_cache`) trong `settings.json`.
5. `5_service_restarted`: Xác nhận dịch vụ ứng dụng Flask đã được sinh viên khởi động lại để nạp cấu hình mới.
6. `6_replay_attack_blocked`: Xác nhận hệ thống Flask đã từ chối gói tin phát lại (trả về lỗi HTTP 403) khi sinh viên thử tấn công lần 2.

---

## 3. Khởi động bài thực hành
```bash
labtainer saml-replay-attack
```

Kiểm tra kết quả:
```bash
checkwork
```

Dừng bài thực hành:
```bash
stoplab
```
