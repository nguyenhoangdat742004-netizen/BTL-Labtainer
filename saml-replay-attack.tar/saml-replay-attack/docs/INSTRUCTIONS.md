# HƯỚNG DẪN THỰC HÀNH: KHAI THÁC & VÁ LỖ HỔNG SAML REPLAY ATTACK
**Tên bài thực hành:** `saml-replay-attack`  
**Chủ đề:** Khai thác và Vá lỗ hổng Phát lại gói tin xác thực SAML (SAML Assertion Replay Attack) trên kiến trúc Single Sign-On (SSO) doanh nghiệp.  
**Thời lượng dự kiến:** 60 - 90 phút.

---

## 1. Mục tiêu bài thực hành
1. **Hiểu rõ cơ chế xác thực SAML 2.0 Web SSO:** Nắm vững luồng trao đổi gói tin giữa Service Provider (SP) và Identity Provider (IdP) qua HTTP-POST Binding.
2. **Khai thác Red Team (SAML Replay Attack):** Tận dụng cấu hình sai lầm phổ biến khi Service Provider tắt chế độ nghiêm ngặt (`"strict": false`), bỏ qua kiểm tra mốc thời gian (`NotOnOrAfter`) và không lưu vết Assertion ID đã tiêu thụ. Kẻ tấn công bắt lại gói tin `SAMLResponse` hợp lệ để tái sử dụng sau khi người dùng đã đăng xuất, chiếm đoạt phiên làm việc mà không cần biết mật khẩu hay tương tác với IdP.
3. **Phòng thủ Blue Team (DevSecOps Patching):** Cấu hình lại thư viện SAML sang chế độ nghiêm ngặt (`"strict": true`), kích hoạt cơ chế kiểm tra thời gian hết hạn (`check_timestamps`) và bật bộ nhớ đệm chống phát lại (`replay_cache`) để ghi nhớ các Assertion ID đã nhận.

---

## 2. Kiến trúc mạng & Các nút thực hành (Topology)

| Tên máy ảo | Địa chỉ IP | Vai trò & Dịch vụ | Tài khoản / Quyền hạn |
| :--- | :--- | :--- | :--- |
| **`sso-server`** | `172.20.0.10` (`sso.lab`, `idp.lab`) | **SSO & Service Server:** Chạy đồng thời Keycloak Identity Provider (Port 8080) và Cổng dịch vụ Python Flask Service Provider (Port 5000). | `ubuntu` / `ubuntu` |
| **`student-pc`** | `172.20.0.20` | **Máy trạm kiểm thử của sinh viên:** Cài sẵn trình duyệt Firefox và công cụ Burp Suite Community Edition. | `ubuntu` / `ubuntu` |

---

## 3. Các bước thực hiện chi tiết

### GIAI ĐOẠN 1: RED TEAM - KHAI THÁC PHÁT LẠI GÓI TIN (REPLAY ATTACK)

#### Bước 1.1: Khởi động công cụ kiểm thử trên `student-pc`
1. Đứng tại màn hình desktop của **`student-pc`**, nhấp đúp vào biểu tượng **Burp Suite Community Edition** trên Desktop (hoặc mở Terminal gõ `burpsuite &`).
2. Khởi động Burp Suite với dự án tạm thời (Temporary Project) và thiết lập mặc định.
3. Tại tab **Proxy** > **Intercept**, đảm bảo tính năng **Intercept is on** (hoặc bạn có thể dùng trình duyệt tích hợp sẵn trong Burp bằng cách vào tab **Proxy** > **Open browser**).

#### Bước 1.2: Đăng nhập hợp lệ lần đầu qua Keycloak IdP (Goal 1)
1. Mở trình duyệt web, truy cập địa chỉ cổng dịch vụ:
   ```text
   http://172.20.0.10:5000
   ```
2. Nhấn nút **"🔐 Đăng nhập qua Identity Provider (Keycloak SSO)"**.
3. Hệ thống sẽ chuyển hướng bạn sang cổng xác thực Keycloak (Port 8080).
4. Nhập thông tin tài khoản nhân viên:
   * **Username:** `employee`
   * **Password:** `Employee@123`
5. Nhấn **"Xác thực & Tạo vé SAML"**.

#### Bước 1.3: Bắt và lưu gói tin SAMLResponse sang Repeater
1. Khi Keycloak xác thực thành công, trình duyệt sẽ gửi một yêu cầu HTTP POST chứa tham số `SAMLResponse` tới endpoint `/saml/acs` của Service Provider:
   ```http
   POST /saml/acs HTTP/1.1
   Host: 172.20.0.10:5000
   Content-Type: application/x-www-form-urlencoded

   SAMLResponse=PD94bWwgdmVyc2lvbj0...
   ```
2. Trong Burp Suite, quan sát thấy request POST `/saml/acs` đang bị chặn lại.
3. Nhấp chuột phải vào gói tin này, chọn **Send to Repeater** (hoặc tổ hợp phím `Ctrl + R`).
4. Bấm **Forward** trên Burp Suite để cho phép gói tin đi tiếp.
5. Trình duyệt được chuyển hướng vào **Bảng Điều Khiển Nhân Viên (Employee Dashboard)**.  
   *(Mục tiêu `1_login_initial` hoàn thành)*.

#### Bước 1.4: Đăng xuất phiên làm việc (Goal 2)
1. Trên giao diện Dashboard của trình duyệt web, tìm đến mục **Thao Tác Phiên Làm Việc** và bấm nút **"🚪 Đăng xuất (Sign Out)"**.
2. Máy chủ Flask sẽ xóa session cookie và chuyển hướng bạn về trang đăng nhập ban đầu. Lúc này phiên làm việc của bạn đã chính thức kết thúc trên server.  
   *(Mục tiêu `2_session_logged_out` hoàn thành)*.

#### Bước 1.5: Thực hiện tấn công Replay Attack qua Repeater (Goal 3)
1. Chuyển sang tab **Repeater** trên giao diện Burp Suite.
2. Bạn sẽ thấy gói tin POST `/saml/acs` với chuỗi `SAMLResponse` cũ đã lưu trước đó.
3. Nhấn nút **Send** để phát lại chính xác gói tin này tới máy chủ Flask SP.
4. Quan sát phản hồi (Response) từ server:
   * Mã trạng thái trả về là **`302 FOUND`** kèm theo header `Location: /dashboard` và một cookie phiên mới `Set-Cookie: session=...`!
   * Hoặc nếu truy cập `/dashboard` kèm session cookie này, bạn sẽ vào lại giao diện Dashboard với thông báo:  
     `⚠️ ĐĂNG NHẬP THÀNH CÔNG BẰNG GÓI TIN PHÁT LẠI (REPLAY ATTACK)`.
5. Cuộc tấn công phát lại đã thành công! Sinh viên đã bypass qua hệ thống xác thực mà không hề phải tương tác lại với Keycloak IdP.  
   *(Mục tiêu `3_replay_attack_success` hoàn thành)*.

---

### GIAI ĐOẠN 2: BLUE TEAM - VÁ LỖ HỔNG & TÁI KIỂM THỬ PHÒNG THỦ

#### Bước 2.1: Truy cập máy chủ `sso-server` và kiểm tra cấu hình
1. Mở cửa sổ terminal của máy **`sso-server`** (hoặc từ máy host / student-pc gõ `ssh ubuntu@172.20.0.10` với mật khẩu `ubuntu`).
2. Xem nội dung tệp cấu hình SAML hiện tại:
   ```bash
   cat /opt/sso-portal/saml/settings.json
   ```
   *Nhận thấy:* Cờ `"strict"` đang là `false`, và `"replay_cache"` đang là `false`.

#### Bước 2.2: Chỉnh sửa cấu hình bảo mật SAML (Goal 4)
1. Mở tệp tin cấu hình bằng trình soạn thảo `nano`:
   ```bash
   nano /opt/sso-portal/saml/settings.json
   ```
2. Tìm và sửa đổi các thông số sau:
   * Đổi `"strict": false` thành `"strict": true`
   * Đổi `"check_timestamps": false` thành `"check_timestamps": true`
   * Đổi `"replay_cache": false` thành `"replay_cache": true`

   *Ví dụ cấu hình sau khi sửa:*
   ```json
   {
       "strict": true,
       "debug": true,
       "security": {
           "check_timestamps": true,
           "replay_cache": true
       },
       "sp": { ... },
       "idp": { ... }
   }
   ```
3. Nhấn `Ctrl + O`, sau đó `Enter` để lưu tệp, và `Ctrl + X` để thoát `nano`.  
   *(Mục tiêu `4_config_patched` hoàn thành)*.

#### Bước 2.3: Khởi động lại dịch vụ Flask SP (Goal 5)
Tại terminal của **`sso-server`**, chạy script khởi động lại dịch vụ để nạp cấu hình mới:
```bash
/home/ubuntu/restart_portal.sh
```
Kiểm tra log xác nhận tiến trình đã nạp cấu hình mới:
```bash
cat /var/log/sso-portal/service.log
```
*(Mục tiêu `5_service_restarted` hoàn thành)*.

#### Bước 2.4: Tái kiểm thử phát lại gói tin để xác nhận đã chặn (Goal 6)
1. Quay trở lại cửa sổ Burp Suite trên máy **`student-pc`**, chọn tab **Repeater** chứa gói tin cũ.
2. Bấm nút **Send** một lần nữa để thử phát lại gói tin.
3. Quan sát kết quả phản hồi từ server:
   * Mã trạng thái HTTP trả về là **`403 Forbidden`**.
   * Phần nội dung hiển thị trang cảnh báo an ninh:  
     `403 Forbidden: Từ Chối Gói Tin Phát Lại - SAML REPLAY ATTACK BLOCKED BY DEFENSE POLICY`.
   * Nguyên nhân: Bộ nhớ đệm `replay_cache` và cơ chế `strict` đã phát hiện Assertion ID này đã tồn tại trong lịch sử và từ chối cấp phiên.
4. Lỗ hổng đã được vá triệt để!  
   *(Mục tiêu `6_replay_attack_blocked` hoàn thành)*.

---

## 4. Đánh giá kết quả tự động (Checkwork)
Sau khi hoàn tất cả 2 giai đoạn, tại terminal của máy trạm **`student-pc`**, thực hiện lệnh:
```bash
checkwork
```

Hệ thống Labtainers sẽ tự động quét và đánh giá cả 6 tiêu chí:
1. `1_login_initial`: Xác nhận đã đăng nhập hợp lệ lần đầu qua Keycloak SSO.
2. `2_session_logged_out`: Xác nhận đã thực hiện thao tác Logout hủy phiên.
3. `3_replay_attack_success`: Xác nhận đã khai thác thành công lỗ hổng Replay Attack.
4. `4_config_patched`: Xác nhận đã cấu hình `strict: true` và `replay_cache: true`.
5. `5_service_restarted`: Xác nhận dịch vụ Flask đã được khởi động lại thành công.
6. `6_replay_attack_blocked`: Xác nhận hệ thống đã chặn đứng cuộc tấn công phát lại lần 2.

Khi cả 6 mục tiêu đều báo **`Passed`**, sinh viên thực hiện lệnh kết thúc bài lab:
```bash
stoplab
```
