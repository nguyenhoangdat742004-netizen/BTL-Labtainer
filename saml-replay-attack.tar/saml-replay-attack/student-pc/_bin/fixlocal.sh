#!/bin/bash
# ==============================================================================
# fixlocal.sh for student-pc (saml-replay-attack)
# Chạy tự động khi student-pc khởi động
# ==============================================================================

# 1. Cấu hình /etc/hosts
grep -q "$(hostname)" /etc/hosts 2>/dev/null || echo "127.0.0.1 $(hostname)" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "sso.lab" /etc/hosts 2>/dev/null || echo "172.20.0.10 sso.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "idp.lab" /etc/hosts 2>/dev/null || echo "172.20.0.10 idp.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "employee.lab" /etc/hosts 2>/dev/null || echo "172.20.0.10 employee.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1

# 2. Wrapper script cho Burp Suite Community Edition
if [ -d /usr/local/BurpSuiteCommunity ]; then
    sudo rm -f /usr/local/bin/burpsuite /usr/bin/burpsuite /usr/local/bin/burp /usr/bin/burp
    sudo tee /usr/local/bin/burpsuite > /dev/null << 'EOF'
#!/bin/bash
exec /usr/local/BurpSuiteCommunity/BurpSuiteCommunity "$@"
EOF
    sudo chmod 755 /usr/local/bin/burpsuite
    sudo cp -a /usr/local/bin/burpsuite /usr/bin/burpsuite
    sudo cp -a /usr/local/bin/burpsuite /usr/local/bin/burp
    sudo cp -a /usr/local/bin/burpsuite /usr/bin/burp
fi

# 3. Tạo thư mục Desktop và biểu tượng Burp Suite
mkdir -p /home/ubuntu/Desktop
if [ -f /usr/share/applications/burpsuite.desktop ]; then
    cp /usr/share/applications/burpsuite.desktop /home/ubuntu/Desktop/
    chmod +x /home/ubuntu/Desktop/burpsuite.desktop
fi

# 4. Script kiểm tra kết nối test_connection.sh
cat << 'EOF_TEST' > /home/ubuntu/test_connection.sh
#!/bin/bash
echo "=== KIỂM TRA KẾT NỐI MẠNG ĐẾN MÁY CHỦ SSO (172.20.0.10) ==="
echo "1. Ping sso-server..."
ping -c 2 172.20.0.10

echo ""
echo "2. Kiểm tra dịch vụ Keycloak IdP (Port 8080)..."
curl -I -s http://172.20.0.10:8080 | head -n 3

echo ""
echo "3. Kiểm tra dịch vụ Service Provider Portal (Port 5000)..."
curl -I -s http://172.20.0.10:5000 | head -n 3
EOF_TEST
chmod +x /home/ubuntu/test_connection.sh

# 5. Hướng dẫn thực hành nhanh trên Desktop
cat << 'EOF_GUIDE' > /home/ubuntu/Desktop/HUONG_DAN_THUC_HANH.txt
================================================================================
BÀI THỰC HÀNH: KHAI THÁC & VÁ LỖ HỔNG SAML REPLAY ATTACK (saml-replay-attack)
================================================================================

A. GIAI ĐOẠN 1: RED TEAM - KHAI THÁC LỖ HỔNG PHÁT LẠI (REPLAY ATTACK)
1. Mở trình duyệt Firefox trên student-pc, cấu hình Proxy qua Burp Suite (Port 8080)
   hoặc sử dụng Chromium / Firefox tích hợp sẵn trong Burp Suite.
2. Truy cập cổng dịch vụ: http://172.20.0.10:5000
3. Nhấn "Đăng nhập qua Keycloak SSO" -> Chuyển sang IdP (Port 8080).
4. Nhập tài khoản: employee / Employee@123
5. Trên Burp Suite (tab HTTP history), tìm gói tin HTTP POST tới endpoint:
   http://172.20.0.10:5000/saml/acs
   Trong Body của request này có chứa chuỗi: SAMLResponse=<chuỗi_Base64>...
6. Nhấp chuột phải vào request này, chọn "Send to Repeater" (Ctrl + R).
7. Cho phép gói tin đi qua (Forward) để trình duyệt hiển thị Dashboard thành công (Goal 1).
8. Trên giao diện Dashboard, bấm nút "Đăng xuất (Logout)" để hủy phiên (Goal 2).
9. Chuyển sang tab Repeater trên Burp Suite, bấm "Send" để phát lại chính gói tin
   SAMLResponse vừa lưu. Do ứng dụng có lỗi cấu hình, server sẽ cấp phiên mới và
   chuyển hướng 302 vào /dashboard (Goal 3).

B. GIAI ĐOẠN 2: BLUE TEAM - VÁ LỖ HỔNG TRÊN sso-server
1. Mở terminal của sso-server (hoặc ssh ubuntu@172.20.0.10 với pass: ubuntu):
   nano /opt/sso-portal/saml/settings.json
2. Chỉnh sửa cấu hình bảo mật:
   - Đổi "strict": false -> "strict": true
   - Đổi "replay_cache": false -> "replay_cache": true
   - Đổi "check_timestamps": false -> "check_timestamps": true
   Lưu lại tệp (Ctrl + O, Enter, Ctrl + X) (Goal 4).
3. Khởi động lại dịch vụ Flask SP:
   ./restart_portal.sh (Goal 5).
4. Quay lại tab Repeater trên Burp Suite, bấm "Send" để phát lại gói tin cũ lần thứ 2.
   Server sẽ trả về HTTP 403 Forbidden: "403 Forbidden: Từ Chối Gói Tin Phát Lại" (Goal 6).

C. ĐÁNH GIÁ KẾT QUẢ TỰ ĐỘNG:
Tại terminal student-pc, chạy lệnh:
checkwork
================================================================================
EOF_GUIDE

sudo chown -R ubuntu:ubuntu /home/ubuntu 2>/dev/null || true
