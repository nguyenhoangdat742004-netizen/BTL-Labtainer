#!/usr/bin/env python3
"""
Keycloak SAML 2.0 Identity Provider (IdP)
saml-replay-attack lab
Chạy trên port 8080, đóng vai trò Identity Provider của realm sso-lab.
"""

import os
import sys
import datetime
import uuid
import base64
from flask import Flask, request, redirect, render_template_string, Response
from lxml import etree

# Monkeypatch các curve ECDSA đã bị cryptography 43+ loại bỏ để tương thích với signxml
from cryptography.hazmat.primitives.asymmetric import ec
for curve in ['SECT163K1', 'SECT233K1', 'SECT233R1', 'SECT283R1', 'SECT409K1', 'SECT409R1', 'SECT571K1', 'SECP192R1', 'SECP224R1']:
    if not hasattr(ec, curve):
        setattr(ec, curve, ec.SECP256R1)

import signxml

app = Flask(__name__)
app.secret_key = 'KEYCLOAK_IDP_SECRET_KEY_2026'

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
KEY_FILE = os.path.join(BASE_DIR, 'keys', 'idp_private.key')
CERT_FILE = os.path.join(BASE_DIR, 'keys', 'idp_cert.crt')

# Cơ sở dữ liệu tài khoản người dùng
USERS = {
    'employee': {
        'password': 'Employee@123',
        'role': 'IT Support Specialist',
        'email': 'employee@enterprise.corp',
        'dept': 'Information Technology'
    },
    'alice': {
        'password': 'Alice@123',
        'role': 'Security Analyst',
        'email': 'alice@enterprise.corp',
        'dept': 'SOC Operations'
    },
    'admin': {
        'password': 'Admin@123',
        'role': 'Enterprise Administrator',
        'email': 'admin@enterprise.corp',
        'dept': 'Executive Board'
    }
}

KEYCLOAK_LOGIN_HTML = """<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keycloak IAM - Đăng nhập tài khoản</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f1f5f9;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .kc-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.01);
            width: 100%;
            max-width: 440px;
            padding: 36px;
        }
        .kc-header {
            text-align: center;
            margin-bottom: 28px;
        }
        .kc-logo {
            font-size: 40px;
            margin-bottom: 12px;
            display: inline-block;
        }
        .kc-title {
            font-size: 20px;
            font-weight: 700;
            color: #0f172a;
        }
        .kc-subtitle {
            font-size: 13px;
            color: #64748b;
            margin-top: 4px;
        }
        .realm-badge {
            background: #e0e7ff;
            color: #3730a3;
            font-size: 11px;
            font-weight: 600;
            padding: 4px 10px;
            border-radius: 9999px;
            display: inline-block;
            margin-top: 8px;
        }
        .form-label {
            font-size: 13px;
            font-weight: 600;
            color: #334155;
            margin-bottom: 6px;
        }
        .form-control {
            border-radius: 8px;
            border: 1px solid #cbd5e1;
            padding: 10px 14px;
            font-size: 14px;
        }
        .form-control:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.15);
        }
        .btn-primary {
            background: #2563eb;
            border: none;
            border-radius: 8px;
            padding: 11px 16px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.15s ease-in-out;
        }
        .btn-primary:hover {
            background: #1d4ed8;
        }
        .hint-box {
            background: #f8fafc;
            border: 1px dashed #cbd5e1;
            border-radius: 8px;
            padding: 12px;
            font-size: 12px;
            color: #64748b;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="kc-card">
        <div class="kc-header">
            <div class="kc-logo">🛡️</div>
            <div class="kc-title">Keycloak Identity Provider</div>
            <div class="kc-subtitle">Hệ thống Quản lý Truy cập & Danh tính Tập trung</div>
            <span class="realm-badge">Realm: sso-lab</span>
        </div>

        {% if error %}
        <div class="alert alert-danger py-2 px-3 small border-0 mb-3 rounded-3" role="alert">
            ⚠️ {{ error }}
        </div>
        {% endif %}

        <form method="POST" action="/realms/sso-lab/protocol/saml">
            <input type="hidden" name="RelayState" value="{{ relay_state }}">
            <div class="mb-3">
                <label class="form-label">Tên đăng nhập (Username):</label>
                <input type="text" name="username" class="form-control" placeholder="employee" value="employee" required autofocus>
            </div>
            <div class="mb-3">
                <label class="form-label">Mật khẩu (Password):</label>
                <input type="password" name="password" class="form-control" placeholder="••••••••" value="Employee@123" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Xác thực & Tạo vé SAML</button>
        </form>

        <div class="hint-box">
            <strong>Tài khoản thử nghiệm sẵn có:</strong><br>
            • <code>employee</code> / <code>Employee@123</code> (Nhân viên IT)<br>
            • <code>alice</code> / <code>Alice@123</code> (Security Analyst)<br>
            • <code>admin</code> / <code>Admin@123</code> (Quản trị viên)
        </div>
    </div>
</body>
</html>
"""

def generate_signed_saml_response(username):
    user_info = USERS.get(username, {
        'role': 'Employee',
        'email': f'{username}@enterprise.corp',
        'dept': 'General'
    })
    
    now = datetime.datetime.now(datetime.timezone.utc)
    issue_instant = now.strftime('%Y-%m-%dT%H:%M:%SZ')
    not_before = (now - datetime.timedelta(minutes=5)).strftime('%Y-%m-%dT%H:%M:%SZ')
    not_on_or_after = (now + datetime.timedelta(minutes=5)).strftime('%Y-%m-%dT%H:%M:%SZ')
    
    response_id = f"_{uuid.uuid4().hex}"
    assertion_id = f"_{uuid.uuid4().hex}"

    xml_template = f"""<samlp:Response xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol"
                xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion"
                ID="{response_id}"
                Version="2.0"
                IssueInstant="{issue_instant}"
                Destination="http://172.20.0.10:5000/saml/acs">
    <saml:Issuer>http://172.20.0.10:8080/realms/sso-lab</saml:Issuer>
    <samlp:Status>
        <samlp:StatusCode Value="urn:oasis:names:tc:SAML:2.0:status:Success"/>
    </samlp:Status>
    <saml:Assertion ID="{assertion_id}"
                    Version="2.0"
                    IssueInstant="{issue_instant}">
        <saml:Issuer>http://172.20.0.10:8080/realms/sso-lab</saml:Issuer>
        <saml:Subject>
            <saml:NameID Format="urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified">{username}</saml:NameID>
            <saml:SubjectConfirmation Method="urn:oasis:names:tc:SAML:2.0:cm:bearer">
                <saml:SubjectConfirmationData NotOnOrAfter="{not_on_or_after}"
                                              Recipient="http://172.20.0.10:5000/saml/acs"/>
            </saml:SubjectConfirmation>
        </saml:Subject>
        <saml:Conditions NotBefore="{not_before}" NotOnOrAfter="{not_on_or_after}">
            <saml:AudienceRestriction>
                <saml:Audience>http://172.20.0.10:5000/saml/metadata</saml:Audience>
            </saml:AudienceRestriction>
        </saml:Conditions>
        <saml:AuthnStatement AuthnInstant="{issue_instant}">
            <saml:AuthnContext>
                <saml:AuthnContextClassRef>urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport</saml:AuthnContextClassRef>
            </saml:AuthnContext>
        </saml:AuthnStatement>
        <saml:AttributeStatement>
            <saml:Attribute Name="Role">
                <saml:AttributeValue>{user_info['role']}</saml:AttributeValue>
            </saml:Attribute>
            <saml:Attribute Name="Email">
                <saml:AttributeValue>{user_info['email']}</saml:AttributeValue>
            </saml:Attribute>
            <saml:Attribute Name="Department">
                <saml:AttributeValue>{user_info['dept']}</saml:AttributeValue>
            </saml:Attribute>
        </saml:AttributeStatement>
    </saml:Assertion>
</samlp:Response>"""

    root = etree.fromstring(xml_template.encode('utf-8'))
    with open(KEY_FILE, 'rb') as kf, open(CERT_FILE, 'rb') as cf:
        signer = signxml.XMLSigner(
            method=signxml.methods.enveloped,
            signature_algorithm='rsa-sha256',
            digest_algorithm='sha256'
        )
        signed_root = signer.sign(root, key=kf.read(), cert=cf.read())

    signed_xml = etree.tostring(signed_root, encoding='utf-8')
    b64_response = base64.b64encode(signed_xml).decode('utf-8')
    return b64_response, assertion_id

@app.route('/')
def index():
    return redirect('/realms/sso-lab/protocol/saml')

@app.route('/realms/sso-lab/protocol/saml', methods=['GET', 'POST'])
def saml_login():
    relay_state = request.args.get('RelayState', '') or request.form.get('RelayState', '')
    if request.method == 'GET':
        return render_template_string(KEYCLOAK_LOGIN_HTML, relay_state=relay_state)
    
    username = request.form.get('username', '').strip()
    password = request.form.get('password', '').strip()

    if username in USERS and USERS[username]['password'] == password:
        saml_resp_b64, assertion_id = generate_signed_saml_response(username)
        print(f"[Keycloak IdP] User '{username}' authenticated successfully. Issued Assertion ID: {assertion_id}", flush=True)

        auto_post_html = f"""<!DOCTYPE html>
<html>
<head><title>Chuyển tiếp SAML Assertion</title></head>
<body onload="document.forms[0].submit()">
    <p style="font-family: sans-serif; text-align: center; margin-top: 50px;">
        Đang chuyển hướng sang Service Provider Portal (ACS)...
    </p>
    <form method="POST" action="http://172.20.0.10:5000/saml/acs">
        <input type="hidden" name="SAMLResponse" value="{saml_resp_b64}"/>
        <input type="hidden" name="RelayState" value="{relay_state}"/>
        <noscript><input type="submit" value="Tiếp tục"/></noscript>
    </form>
</body>
</html>"""
        return auto_post_html
    else:
        return render_template_string(KEYCLOAK_LOGIN_HTML, error="Sai tên đăng nhập hoặc mật khẩu!", relay_state=relay_state), 401

@app.route('/realms/sso-lab/protocol/saml/descriptor')
def descriptor():
    with open(CERT_FILE, 'r') as cf:
        cert_data = cf.read().replace('-----BEGIN CERTIFICATE-----', '').replace('-----END CERTIFICATE-----', '').replace('\n', '')
    meta_xml = f"""<EntityDescriptor xmlns="urn:oasis:names:tc:SAML:2.0:metadata" entityID="http://172.20.0.10:8080/realms/sso-lab">
    <IDPSSODescriptor WantAuthnRequestsSigned="false" protocolSupportEnumeration="urn:oasis:names:tc:SAML:2.0:protocol">
        <KeyDescriptor use="signing">
            <ds:KeyInfo xmlns:ds="http://www.w3.org/2000/09/xmldsig#">
                <ds:X509Data>
                    <ds:X509Certificate>{cert_data}</ds:X509Certificate>
                </ds:X509Data>
            </ds:KeyInfo>
        </KeyDescriptor>
        <SingleSignOnService Binding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect" Location="http://172.20.0.10:8080/realms/sso-lab/protocol/saml"/>
        <SingleSignOnService Binding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST" Location="http://172.20.0.10:8080/realms/sso-lab/protocol/saml"/>
    </IDPSSODescriptor>
</EntityDescriptor>"""
    return Response(meta_xml, mimetype='application/xml')

if __name__ == '__main__':
    print("[*] Keycloak SAML IdP starting on 0.0.0.0:8080 (Realm: sso-lab)...", flush=True)
    app.run(host='0.0.0.0', port=8080)
