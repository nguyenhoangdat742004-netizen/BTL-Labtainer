#!/bin/bash
# Restart script for SSO Portal (Flask SP)
echo "[*] Đang khởi động lại dịch vụ Enterprise SSO Portal..."

NOW=$(date '+%Y-%m-%d %H:%M:%S')
echo "$NOW sso-server [SERVICE] SERVICE_RESTARTED with new configuration" | sudo tee -a /var/log/sso-portal/service.log > /dev/null

if systemctl is-system-running >/dev/null 2>&1 || [ -d /run/systemd/system ]; then
    sudo systemctl restart sso-portal
else
    sudo pkill -f "python3 /opt/sso-portal/app.py" 2>/dev/null || true
    sleep 1
    nohup python3 /opt/sso-portal/app.py >> /var/log/sso-portal/portal.log 2>&1 &
fi

sleep 2
echo "[THÀNH CÔNG] Dịch vụ SSO Portal đã được khởi động lại thành công trên Port 5000!"
echo "Nạp cấu hình mới từ: /opt/sso-portal/saml/settings.json"
