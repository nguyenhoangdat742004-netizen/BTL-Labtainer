#!/usr/bin/env python3
"""
Enterprise Cloud Service Provider (SP) - SAML 2.0 SSO Portal
saml-replay-attack lab
Chạy trên port 5000, nhận gói tin SAMLResponse tại /saml/acs.
"""

import os
import sys
import json
import base64
import datetime
from flask import Flask, request, redirect, session, render_template_string, Response
from lxml import etree

# Monkeypatch các curve ECDSA đã bị cryptography 43+ loại bỏ để tương thích với signxml
from cryptography.hazmat.primitives.asymmetric import ec
for curve in ['SECT163K1', 'SECT233K1', 'SECT233R1', 'SECT283R1', 'SECT409K1', 'SECT409R1', 'SECT571K1', 'SECP192R1', 'SECP224R1']:
    if not hasattr(ec, curve):
        setattr(ec, curve, ec.SECP256R1)

import signxml

app = Flask(__name__)
app.secret_key = 'SP_REPLAY_LAB_SECRET_KEY_2026'

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SAML_DIR = os.path.join(BASE_DIR, 'saml')
SETTINGS_FILE = os.path.join(SAML_DIR, 'settings.json')
IDP_CERT_FILE = os.path.join(SAML_DIR, 'idp_cert.crt')
CACHE_FILE = os.path.join(SAML_DIR, 'consumed_assertions.json')
HISTORY_FILE = os.path.join(SAML_DIR, 'assertion_history.json')

AUTH_LOG = '/var/log/sso-portal/auth.log'
SERVICE_LOG = '/var/log/sso-portal/service.log'

def write_auth_log(message):
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    line = f"{ts} sso-server {message}\n"
    os.makedirs(os.path.dirname(AUTH_LOG), exist_ok=True)
    with open(AUTH_LOG, 'a') as f:
        f.write(line)
        f.flush()
    print(line.strip(), flush=True)

def load_settings():
    if not os.path.exists(SETTINGS_FILE):
        return {"strict": False, "security": {"check_timestamps": False, "replay_cache": False}}
    try:
        with open(SETTINGS_FILE, 'r') as f:
            return json.load(f)
    except Exception as e:
        print(f"[-] Error loading settings.json: {e}", flush=True)
        return {"strict": False, "security": {"check_timestamps": False, "replay_cache": False}}

def load_json_set(filepath):
    if not os.path.exists(filepath):
        return set()
    try:
        with open(filepath, 'r') as f:
            data = json.load(f)
            return set(data)
    except Exception:
        return set()

def save_json_set(filepath, s):
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    try:
        with open(filepath, 'w') as f:
            json.dump(list(s), f, indent=2)
    except Exception as e:
        print(f"[-] Error saving {filepath}: {e}", flush=True)

# ==============================================================================
# GIAO DIỆN LIGHT THEME DOANH NGHIỆP HIỆN ĐẠI (BOOTSTRAP 5) - KHÔNG DÙNG F-STRING
# ==============================================================================
NAVBAR_HTML = """
<nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom shadow-sm px-4 py-3">
    <div class="container-fluid">
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold text-primary" href="/">
            <span class="fs-4">🏢</span>
            <span>Enterprise Cloud Portal</span>
        </a>
        <div class="d-flex align-items-center gap-3">
            <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-3 py-2 rounded-pill small">
                🛡️ SAML 2.0 SSO Enabled
            </span>
            <span class="badge bg-success-subtle text-success border border-success-subtle px-3 py-2 rounded-pill small">
                🔑 IdP: Keycloak (sso-lab)
            </span>
            {% if session.get('user') %}
            <a href="/logout" class="btn btn-outline-danger btn-sm px-3 fw-semibold">Đăng xuất</a>
            {% endif %}
        </div>
    </div>
</nav>
"""

LOGIN_PAGE = """<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cổng Dịch Vụ Doanh Nghiệp - Enterprise Service Provider</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; min-height: 100vh; }
        .card { border: 1px solid #e2e8f0; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,0.04); }
        .btn-sso { background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%); color: white; border: none; font-weight: 600; padding: 14px 28px; border-radius: 10px; transition: all 0.2s; }
        .btn-sso:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(37,99,235,0.3); color: white; }
        .status-badge { font-size: 11px; font-weight: 700; letter-spacing: 0.05em; }
    </style>
</head>
<body>
""" + NAVBAR_HTML + """
<div class="container py-5" style="max-width: 820px;">
    {% if error %}
    <div class="alert alert-danger shadow-sm border-0 d-flex align-items-center gap-2 mb-4">
        <span>⚠️</span>
        <div><strong>Lỗi xác thực:</strong> {{ error }}</div>
    </div>
    {% endif %}

    <div class="card p-4 p-md-5 bg-white mb-4">
        <div class="text-center mb-4">
            <div class="display-6 fw-bold text-dark mb-2">Cổng Quản Trị & Dịch Vụ Doanh Nghiệp</div>
            <p class="text-secondary">Hệ thống Service Provider (SP) tích hợp xác thực danh tính tập trung SAML 2.0 Web SSO.</p>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <div class="p-3 bg-light rounded-3 border text-center">
                    <div class="text-muted small fw-semibold text-uppercase status-badge">Giao thức</div>
                    <div class="fw-bold text-dark mt-1">SAML 2.0 Web SSO</div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-3 bg-light rounded-3 border text-center">
                    <div class="text-muted small fw-semibold text-uppercase status-badge">Identity Provider</div>
                    <div class="fw-bold text-primary mt-1">Keycloak (sso-lab)</div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-3 bg-light rounded-3 border text-center">
                    <div class="text-muted small fw-semibold text-uppercase status-badge">Điểm tiếp nhận (ACS)</div>
                    <div class="fw-bold text-success mt-1">/saml/acs (Port 5000)</div>
                </div>
            </div>
        </div>

        <div class="d-grid gap-2 mb-4">
            <a href="http://172.20.0.10:8080/realms/sso-lab/protocol/saml" class="btn btn-sso text-center fs-5">
                🔐 Đăng nhập qua Identity Provider (Keycloak SSO)
            </a>
        </div>

        <div class="p-3 rounded-3 bg-light border small text-muted">
            <div class="fw-bold text-dark mb-1">ℹ️ Thông tin kiểm thử an toàn thông tin:</div>
            <div>• Cấu hình bảo mật SAML: <code>/opt/sso-portal/saml/settings.json</code></div>
            <div>• Trạng thái hiện tại: <strong>Strict = {{ 'BẬT (Phòng thủ)' if strict else 'TẮT (Lỗ hổng Replay)' }}</strong> | <strong>Replay Cache = {{ 'BẬT' if replay_cache else 'TẮT' }}</strong></div>
            <div>• Sinh viên sử dụng <strong>Burp Suite (Proxy / Repeater)</strong> hoặc Form bên dưới để kiểm thử phát lại gói tin.</div>
        </div>

        <hr class="my-4">

        <div class="accordion" id="accordionSAML">
            <div class="accordion-item border rounded-3 overflow-hidden">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed bg-light fw-semibold text-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
                        🛠️ Kiểm thử gửi gói tin SAMLResponse trực tiếp (Red Team Testing)
                    </button>
                </h2>
                <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionSAML">
                    <div class="accordion-body bg-white">
                        <p class="small text-muted mb-2">Sinh viên có thể dán chuỗi Base64 của SAMLResponse đã bắt từ Burp Suite vào đây để kiểm thử gửi lại gói tin cũ.</p>
                        <form action="/saml/acs" method="POST">
                            <div class="mb-3">
                                <textarea name="SAMLResponse" class="form-control font-monospace small" rows="5" placeholder="Dán chuỗi Base64 của SAMLResponse tại đây..." required></textarea>
                            </div>
                            <button type="submit" class="btn btn-outline-primary fw-semibold btn-sm">Gửi vé xác thực (Submit Assertion)</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
"""

DASHBOARD_PAGE = """<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bảng Điều Khiển Nhân Viên - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        .kpi-card { background: white; border: 1px solid #e2e8f0; border-radius: 14px; padding: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.03); }
        .badge-verified { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; font-weight: 600; padding: 6px 14px; border-radius: 20px; }
        .badge-replay { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; font-weight: 600; padding: 6px 14px; border-radius: 20px; }
    </style>
</head>
<body>
""" + NAVBAR_HTML + """
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
            <h3 class="fw-bold text-dark mb-1">Bảng Điều Khiển Người Dùng (Employee Dashboard)</h3>
            <p class="text-secondary small mb-0">Phiên làm việc doanh nghiệp được cấp quyền qua vé xác thực SAML 2.0.</p>
        </div>
        {% if is_replay %}
        <span class="badge-replay">
            ⚠️ ĐĂNG NHẬP THÀNH CÔNG BẰNG GÓI TIN PHÁT LẠI (REPLAY ATTACK)
        </span>
        {% else %}
        <span class="badge-verified">
            ✅ Xác thực Hợp lệ từ IdP (Legitimate Session)
        </span>
        {% endif %}
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="kpi-card">
                <div class="text-muted small text-uppercase fw-semibold">Tài khoản xác thực</div>
                <div class="fs-4 fw-bold text-primary mt-1">{{ user }}</div>
                <div class="text-success small fw-medium mt-1">● SAML NameID verified</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="kpi-card">
                <div class="text-muted small text-uppercase fw-semibold">Vai trò hệ thống</div>
                <div class="fs-4 fw-bold text-dark mt-1">{{ role }}</div>
                <div class="text-muted small mt-1">Assigned by Keycloak</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="kpi-card">
                <div class="text-muted small text-uppercase fw-semibold">Phòng ban</div>
                <div class="fs-4 fw-bold text-success mt-1">{{ dept }}</div>
                <div class="text-muted small mt-1">Organizational Unit</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="kpi-card">
                <div class="text-muted small text-uppercase fw-semibold">Trạng thái phiên</div>
                <div class="fs-4 fw-bold text-success mt-1">Hoạt động</div>
                <div class="text-muted small mt-1">Active Session</div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card p-4 bg-white border rounded-4 shadow-sm h-100">
                <h5 class="fw-bold text-dark mb-3">🔍 Chi Tiết Vé Xác Thực SAML Assertion</h5>
                <table class="table table-bordered table-striped align-middle small">
                    <tbody>
                        <tr>
                            <th style="width: 30%;">Issuer (IdP):</th>
                            <td><code>{{ issuer }}</code></td>
                        </tr>
                        <tr>
                            <th>Assertion ID:</th>
                            <td><span class="badge bg-secondary font-monospace">{{ assertion_id }}</span></td>
                        </tr>
                        <tr>
                            <th>Subject (NameID):</th>
                            <td><span class="badge bg-primary px-2 py-1">{{ user }}</span></td>
                        </tr>
                        <tr>
                            <th>Email:</th>
                            <td>{{ email }}</td>
                        </tr>
                        <tr>
                            <th>Role Attribute:</th>
                            <td><span class="badge bg-info text-dark px-2 py-1">{{ role }}</span></td>
                        </tr>
                        <tr>
                            <th>Hiệu lực đến (NotOnOrAfter):</th>
                            <td><code>{{ not_on_or_after }}</code></td>
                        </tr>
                    </tbody>
                </table>

                {% if is_replay %}
                <div class="alert alert-danger py-2 small mb-0">
                    🚨 <strong>CẢNH BÁO AN NINH:</strong> Phiên đăng nhập này được tạo ra từ việc phát lại một Assertion ID đã dùng! Điều này chứng minh ứng dụng đang tồn tại lỗ hổng <strong>SAML Replay Attack</strong>!
                </div>
                {% else %}
                <div class="alert alert-info py-2 small mb-0">
                    💡 <strong>Ghi chú:</strong> Chữ ký số RSA-SHA256 của Assertion đã được Service Provider kiểm tra khớp với chứng chỉ IdP.
                </div>
                {% endif %}
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card p-4 bg-white border rounded-4 shadow-sm h-100">
                <h5 class="fw-bold text-dark mb-3">🚪 Thao Tác Phiên Làm Việc</h5>
                <p class="small text-secondary">
                    Thực hiện Đăng xuất để xóa session trên máy chủ, sau đó sử dụng Burp Suite Repeater để gửi lại gói tin SAMLResponse cũ nhằm kiểm thử lỗ hổng.
                </p>
                <div class="d-grid gap-2 mt-4">
                    <a href="/logout" class="btn btn-outline-danger fw-semibold py-2">
                        🚪 Đăng xuất (Sign Out)
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
"""

SECURITY_ERROR_PAGE = """<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>403 Forbidden - Từ Chối Xác Thực SAML</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        .card { border: 1px solid #fee2e2; border-radius: 16px; box-shadow: 0 10px 30px rgba(220,38,38,0.06); }
    </style>
</head>
<body>
""" + NAVBAR_HTML + """
<div class="container py-5" style="max-width: 680px;">
    <div class="card p-4 p-md-5 bg-white text-center">
        <div class="display-3 mb-3">🛡️</div>
        <h3 class="fw-bold text-danger mb-2">403 Forbidden: Từ Chối Gói Tin Phát Lại</h3>
        <h6 class="text-secondary mb-4">SAML REPLAY ATTACK BLOCKED BY DEFENSE POLICY</h6>

        <div class="alert alert-danger text-start small mb-4">
            <strong>Nguyên nhân từ chối:</strong><br>
            • {{ reason }}<br>
            • Assertion ID: <code class="font-monospace">{{ assertion_id }}</code><br>
            • Chính sách bảo mật <code>strict = true</code> và Bộ nhớ đệm <code>replay_cache = true</code> đã phát hiện gói tin này đã được sử dụng trước đó hoặc vi phạm mốc thời gian hiệu lực.
        </div>

        <div class="p-3 bg-light rounded text-start small text-muted mb-4">
            <div class="fw-bold text-dark mb-1">✅ KẾT QUẢ PHÒNG THỦ BLUE TEAM:</div>
            <div>Hệ thống Service Provider đã ngăn chặn thành công cuộc tấn công phát lại (Replay Attack)! Quyền truy cập bất hợp pháp đã bị chặn đứng hoàn toàn.</div>
        </div>

        <div>
            <a href="/" class="btn btn-outline-primary px-4 fw-semibold">Quay lại Trang Chủ</a>
        </div>
    </div>
</div>
</body>
</html>
"""

@app.route('/')
def index():
    if 'user' in session:
        return redirect('/dashboard')
    settings = load_settings()
    strict = settings.get('strict', False)
    sec = settings.get('security', {})
    replay_cache = sec.get('replay_cache', False)
    return render_template_string(LOGIN_PAGE, strict=strict, replay_cache=replay_cache)

@app.route('/saml/login')
def saml_login():
    return redirect('http://172.20.0.10:8080/realms/sso-lab/protocol/saml')

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect('/')
    return render_template_string(
        DASHBOARD_PAGE,
        user=session.get('user', 'employee'),
        role=session.get('role', 'IT Support Specialist'),
        dept=session.get('dept', 'Information Technology'),
        email=session.get('email', 'employee@enterprise.corp'),
        issuer=session.get('issuer', 'http://172.20.0.10:8080/realms/sso-lab'),
        assertion_id=session.get('assertion_id', 'UNKNOWN'),
        not_on_or_after=session.get('not_on_or_after', 'N/A'),
        is_replay=session.get('is_replay', False)
    )

@app.route('/saml/acs', methods=['POST'])
def acs():
    saml_b64 = request.form.get('SAMLResponse', '').strip()
    if not saml_b64:
        return render_template_string(LOGIN_PAGE, error="Không tìm thấy tham số SAMLResponse trong yêu cầu POST!"), 400

    try:
        # 1. Chuẩn hóa chuỗi Base64
        clean_b64 = saml_b64.replace(' ', '+')
        pad = len(clean_b64) % 4
        if pad:
            clean_b64 += '=' * (4 - pad)
        xml_bytes = base64.b64decode(clean_b64)

        # 2. Parse XML và xác thực chữ ký số bằng idp_cert.crt
        root = etree.fromstring(xml_bytes)
        with open(IDP_CERT_FILE, 'rb') as cf:
            cert_content = cf.read()
        
        verifier = signxml.XMLVerifier()
        verifier.verify(root, x509_cert=cert_content)

        # 3. Trích xuất thông tin Assertion
        assertion = root.find('.//{urn:oasis:names:tc:SAML:2.0:assertion}Assertion')
        assertion_id = assertion.get('ID', '') if assertion is not None else ''

        name_id_elem = root.find('.//{urn:oasis:names:tc:SAML:2.0:assertion}NameID')
        username = name_id_elem.text.strip() if name_id_elem is not None and name_id_elem.text else 'employee'

        # Trích xuất SubjectConfirmationData / Conditions (NotOnOrAfter)
        sc_data = root.find('.//{urn:oasis:names:tc:SAML:2.0:assertion}SubjectConfirmationData')
        not_on_or_after = sc_data.get('NotOnOrAfter', '') if sc_data is not None else ''
        if not not_on_or_after:
            cond_elem = root.find('.//{urn:oasis:names:tc:SAML:2.0:assertion}Conditions')
            not_on_or_after = cond_elem.get('NotOnOrAfter', '') if cond_elem is not None else ''

        # Trích xuất Attributes
        role = 'IT Support Specialist'
        email = f"{username}@enterprise.corp"
        dept = 'Information Technology'
        for attr in root.iter('{urn:oasis:names:tc:SAML:2.0:assertion}Attribute'):
            attr_name = attr.get('Name') or ''
            for val in attr.iter('{urn:oasis:names:tc:SAML:2.0:assertion}AttributeValue'):
                val_text = val.text.strip() if val.text else ''
                if attr_name.lower() == 'role':
                    role = val_text
                elif attr_name.lower() == 'email':
                    email = val_text
                elif attr_name.lower() == 'department':
                    dept = val_text

        # 4. Nạp cấu hình bảo mật từ settings.json
        settings = load_settings()
        strict = bool(settings.get('strict', False))
        sec = settings.get('security', {})
        replay_cache_enabled = bool(sec.get('replay_cache', False))
        check_timestamps_enabled = bool(sec.get('check_timestamps', False))

        consumed_cache = load_json_set(CACHE_FILE)
        history_set = load_json_set(HISTORY_FILE)

        # ======================================================================
        # KIỂM TRA CHÍNH SÁCH BẢO MẬT & PHÒNG THỦ REPLAY ATTACK
        # ======================================================================
        if strict or replay_cache_enabled:
            # CHẾ ĐỘ PHÒNG THỦ ĐÃ ĐƯỢC VÁ (BLUE TEAM):
            # 1. Kiểm tra xem Assertion ID đã từng được sử dụng chưa
            if assertion_id in consumed_cache:
                write_auth_log(f"[SECURITY_ALERT] REPLAY_ATTACK_BLOCKED: Assertion ID already consumed: user={username} assertion_id={assertion_id}")
                return render_template_string(
                    SECURITY_ERROR_PAGE,
                    reason=f"Phát hiện tấn công phát lại (Replay Attack)! Assertion ID '{assertion_id}' đã tồn tại trong bộ nhớ đệm xác thực.",
                    assertion_id=assertion_id
                ), 403

            # 2. Kiểm tra mốc thời gian NotOnOrAfter
            if check_timestamps_enabled and not_on_or_after:
                try:
                    expiry_time = datetime.datetime.strptime(not_on_or_after, '%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=datetime.timezone.utc)
                    now_utc = datetime.datetime.now(datetime.timezone.utc)
                    if now_utc > expiry_time:
                        write_auth_log(f"[SECURITY_ALERT] REPLAY_ATTACK_BLOCKED: Assertion expired (NotOnOrAfter violation): user={username} assertion_id={assertion_id}")
                        return render_template_string(
                            SECURITY_ERROR_PAGE,
                            reason=f"Vé xác thực SAML đã hết hạn vào lúc {not_on_or_after} (NotOnOrAfter).",
                            assertion_id=assertion_id
                        ), 403
                except Exception as ex:
                    print(f"[-] Timestamp check error: {ex}", flush=True)

            # Nếu hợp lệ: Lưu Assertion ID vào bộ nhớ đệm phòng thủ
            consumed_cache.add(assertion_id)
            save_json_set(CACHE_FILE, consumed_cache)

            # Thiết lập phiên hợp lệ
            session['user'] = username
            session['role'] = role
            session['email'] = email
            session['dept'] = dept
            session['assertion_id'] = assertion_id
            session['not_on_or_after'] = not_on_or_after
            session['is_replay'] = False
            session['issuer'] = 'http://172.20.0.10:8080/realms/sso-lab'

            write_auth_log(f"[AUTH] INITIAL_LOGIN_SUCCESS user={username} role={role} assertion_id={assertion_id}")
            return redirect('/dashboard')

        else:
            # CHẾ ĐỘ CẤU HÌNH LỖI (VULNERABLE STATE - strict=false, replay_cache=false):
            # Không kiểm tra cache, chấp nhận gói tin phát lại!
            is_replay_attack = False

            if assertion_id in history_set:
                # Gói tin này đã từng được gửi trước đó -> Sinh viên đang thực hiện Replay Attack thành công!
                is_replay_attack = True
                write_auth_log(f"[EXPLOIT] REPLAY_ATTACK_SUCCESS user={username} role={role} assertion_id={assertion_id} status=BYPASSED")
            else:
                # Lần đăng nhập hợp lệ đầu tiên
                history_set.add(assertion_id)
                save_json_set(HISTORY_FILE, history_set)
                # Cũng lưu vào consumed_cache để khi sinh viên vá và bật cache, gói tin cũ đã sẵn sàng bị chặn
                consumed_cache.add(assertion_id)
                save_json_set(CACHE_FILE, consumed_cache)
                write_auth_log(f"[AUTH] INITIAL_LOGIN_SUCCESS user={username} role={role} assertion_id={assertion_id}")

            session['user'] = username
            session['role'] = role
            session['email'] = email
            session['dept'] = dept
            session['assertion_id'] = assertion_id
            session['not_on_or_after'] = not_on_or_after
            session['is_replay'] = is_replay_attack
            session['issuer'] = 'http://172.20.0.10:8080/realms/sso-lab'

            return redirect('/dashboard')

    except Exception as e:
        error_msg = f"Chữ ký số hoặc cấu trúc SAML không hợp lệ: {str(e)}"
        print(f"[-] ACS Exception: {e}", flush=True)
        write_auth_log(f"[AUTH_ERROR] Verification failed: {str(e)[:50]}")
        return render_template_string(LOGIN_PAGE, error=error_msg), 400

@app.route('/logout')
def logout():
    user = session.get('user', 'employee')
    session.clear()
    write_auth_log(f"[AUTH] LOGOUT_SUCCESS user={user}")
    return redirect('/')

@app.route('/saml/metadata')
def metadata():
    meta = """<EntityDescriptor xmlns="urn:oasis:names:tc:SAML:2.0:metadata" entityID="http://172.20.0.10:5000/saml/metadata">
    <SPSSODescriptor protocolSupportEnumeration="urn:oasis:names:tc:SAML:2.0:protocol">
        <AssertionConsumerService Binding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST" Location="http://172.20.0.10:5000/saml/acs" index="1"/>
    </SPSSODescriptor>
</EntityDescriptor>"""
    return Response(meta, mimetype='application/xml')

if __name__ == '__main__':
    print("[*] Enterprise SAML Service Provider starting on 0.0.0.0:5000...", flush=True)
    app.run(host='0.0.0.0', port=5000)
