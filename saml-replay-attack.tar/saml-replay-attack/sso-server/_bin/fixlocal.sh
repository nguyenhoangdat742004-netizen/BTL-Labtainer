#!/bin/bash
# ==============================================================================
# fixlocal.sh for sso-server (saml-replay-attack)
# Chạy tự động khi sso-server khởi động để chuẩn bị môi trường dịch vụ
# ==============================================================================

# 1. Cấu hình /etc/hosts
grep -q "$(hostname)" /etc/hosts 2>/dev/null || echo "127.0.0.1 $(hostname)" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "sso.lab" /etc/hosts 2>/dev/null || echo "172.20.0.10 sso.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "idp.lab" /etc/hosts 2>/dev/null || echo "172.20.0.10 idp.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "student-pc" /etc/hosts 2>/dev/null || echo "172.20.0.20 student-pc" | sudo tee -a /etc/hosts >/dev/null 2>&1

# 2. Khởi tạo thư mục và file log
sudo mkdir -p /var/log/sso-portal
sudo touch /var/log/sso-portal/auth.log /var/log/sso-portal/service.log /var/log/sso-portal/portal.log /var/log/sso-portal/idp.log
sudo chmod 777 /var/log/sso-portal
sudo chmod 666 /var/log/sso-portal/*.log
sudo chown -R ubuntu:ubuntu /opt/keycloak-idp /opt/sso-portal /var/log/sso-portal 2>/dev/null || true

# 3. Tạo script restart_portal.sh trong home của user ubuntu
cp /opt/sso-portal/restart_portal.sh /home/ubuntu/restart_portal.sh
chmod +x /home/ubuntu/restart_portal.sh /opt/sso-portal/restart_portal.sh
chown ubuntu:ubuntu /home/ubuntu/restart_portal.sh

# 4. Tạo script kiểm tra trạng thái check_status.sh
cat << 'EOF_STATUS' > /home/ubuntu/check_status.sh
#!/bin/bash
echo "=== KIỂM TRA TRẠNG THÁI HỆ THỐNG SSO VÀ CẤU HÌNH BẢO MẬT ==="
echo "1. Tiến trình đang chạy:"
ps aux | grep -E "keycloak-idp/app.py|sso-portal/app.py" | grep -v grep

echo ""
echo "2. Trạng thái dịch vụ Systemd:"
systemctl status keycloak-idp sso-portal --no-pager 2>/dev/null || echo "Systemd chưa active"

echo ""
echo "3. Cấu hình tệp /opt/sso-portal/saml/settings.json hiện tại:"
cat /opt/sso-portal/saml/settings.json

echo ""
echo "4. Nhật ký xác thực gần nhất (/var/log/sso-portal/auth.log):"
tail -n 10 /var/log/sso-portal/auth.log 2>/dev/null || echo "[Trống]"
EOF_STATUS
chmod +x /home/ubuntu/check_status.sh
chown ubuntu:ubuntu /home/ubuntu/check_status.sh

# 5. Hướng dẫn nhanh cho sinh viên khi truy cập sso-server
cat << 'EOF_BLUE' > /home/ubuntu/HUONG_DAN_BLUE_TEAM.txt
================================================================================
KỊCH BẢN BLUE TEAM: VÁ LỖ HỔNG SAML REPLAY ATTACK (sso-server)
================================================================================
Nhiệm vụ của sinh viên (DevSecOps):
1. Chỉnh sửa tệp cấu hình SAML:
   nano /opt/sso-portal/saml/settings.json

   - Đổi "strict": false thành "strict": true
   - Đổi "replay_cache": false thành "replay_cache": true
   - Đổi "check_timestamps": false thành "check_timestamps": true

2. Khởi động lại dịch vụ Flask SP để nạp cấu hình mới:
   ./restart_portal.sh

3. Kiểm tra trạng thái:
   ./check_status.sh

4. Quay lại Burp Suite Repeater trên student-pc, gửi lại gói tin SAMLResponse cũ.
   Hệ thống sẽ từ chối với mã lỗi 403 Forbidden và ghi log REPLAY_ATTACK_BLOCKED.
================================================================================
EOF_BLUE
chown ubuntu:ubuntu /home/ubuntu/HUONG_DAN_BLUE_TEAM.txt

# 6. Khởi động các dịch vụ qua Systemd
sudo systemctl daemon-reload 2>/dev/null || true
sudo systemctl enable keycloak-idp sso-portal 2>/dev/null || true
sudo systemctl restart keycloak-idp sso-portal 2>/dev/null || true

# Fallback nếu systemd chưa kịp khởi động
if ! pgrep -f "/opt/sso-portal/app.py" >/dev/null 2>&1; then
    nohup python3 /opt/keycloak-idp/app.py >> /var/log/sso-portal/idp.log 2>&1 &
    nohup python3 /opt/sso-portal/app.py >> /var/log/sso-portal/portal.log 2>&1 &
fi

echo "[THÀNH CÔNG] Máy chủ sso-server đã khởi động IdP (Port 8080) và SP Portal (Port 5000)!"
