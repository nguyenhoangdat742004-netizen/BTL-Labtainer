# Labtainers: Kiểm thử và Vô hiệu hóa tính năng XSLT Transform (`saml-xslt-config-verification`)

## 1. Kiến trúc Hệ thống (3 Container trên mạng `172.20.0.0/24`)
- **`ldap-idp` (`172.20.0.10`)**: Máy chủ cấp phát SAML 2.0 (Identity Provider).
- **`sp-app` (`172.20.0.20`)**: Máy chủ Web Service Provider chạy kiến trúc 2 lớp:
  - **Lớp ngoài**: Nginx tích hợp ModSecurity WAF (`/etc/modsecurity/modsecurity_custom.conf`, mặc định ở chế độ `DetectionOnly`).
  - **Lớp trong**: Flask App sử dụng thư viện XML (`/opt/lab/xml_validator.py`, mặc định đang bật cờ `enable_xslt_transform = True` cho phép phân giải `<ds:Transform>` bằng XSLT).
- **`zeek-monitor` (`172.20.0.30`)**: Máy chủ giám sát mạng Blue Team, chạy Zeek IDS ngầm và ghi log lưu lượng HTTP vào `/var/log/zeek/http.log`.

## 2. Các Tệp Quan Trọng Trong Bài Lab
- Trên **`sp-app` (`172.20.0.20`)**:
  - `/opt/lab/verify_xslt_config.py`: Script Python kiểm thử cấu hình XSLT Transform trên SP-App.
  - `/etc/modsecurity/modsecurity_custom.conf`: File cấu hình ModSecurity Custom Rule (mở bằng `labedit /etc/modsecurity/modsecurity_custom.conf`).
  - `/opt/lab/xml_validator.py`: Module xác thực XML của Flask App (mở bằng `labedit /opt/lab/xml_validator.py` để đổi `enable_xslt_transform = False`).
  - `/opt/lab/sp_app.py`: Mã nguồn ứng dụng Flask SP-App.
- Trên **`zeek-monitor` (`172.20.0.30`)**:
  - `/var/log/zeek/http.log`: Nhật ký lưu lượng mạng HTTP chuẩn Zeek TSV.
  - Hỗ trợ các lệnh phân tích: `cat`, `grep`, `zeek-cut`, `zeekctl`.

## 3. Tiêu chí Nghiệm thu (`checkwork`)
| Mục tiêu (`goals.config`) | Biến kết quả (`results.config`) | Tệp kiểm tra | Ý nghĩa |
| :--- | :--- | :--- | :--- |
| `1_modsecurity_rule_configured` | `_waf_secrule` & (`_waf_ns_xsl` \| `_waf_alg_xslt`) | `sp-app:/etc/modsecurity/modsecurity_custom.conf` | Thêm ModSecurity Custom Rule chặn Namespace `http://www.w3.org/1999/XSL/Transform` hoặc thuật toán `http://www.w3.org/TR/1999/REC-xslt-19991116`. |
| `2_flask_xslt_disabled` | `_xslt_disabled_lower` \| `_xslt_disabled_upper` | `sp-app:/opt/lab/xml_validator.py` | Vô hiệu hóa tính năng XSLT trong mã nguồn Flask (`enable_xslt_transform = False`). |
| `3_xslt_verification_passed` | `_verify_blocked_audit` \| `_verify_blocked_waf` \| `_verify_stdout_safe` | `sp-app:/var/log/sp-portal/audit.log`, `modsec_audit.log`, `python3.stdout` | Chạy lại `verify_xslt_config.py` xác nhận hệ thống an toàn (WAF chặn 403 hoặc Flask từ chối xử lý XSLT). |
