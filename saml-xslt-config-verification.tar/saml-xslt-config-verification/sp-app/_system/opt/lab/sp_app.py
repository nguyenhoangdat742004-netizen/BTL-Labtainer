#!/usr/bin/env python3
"""
Enterprise Workspace Portal (Service Provider - Kiến trúc 2 lớp:
- Lớp ngoài: Nginx + ModSecurity WAF (/etc/modsecurity/modsecurity_custom.conf)
- Lớp trong: Flask App + Thư viện XML (/opt/lab/xml_validator.py)
Lab: saml-xslt-config-verification (sp-app: 172.20.0.20)
"""
import os
import re
import json
import base64
import socket
import threading
import datetime
import urllib.parse
from flask import Flask, request, redirect, session, render_template_string, jsonify, Response
from lxml import etree

app = Flask(__name__)
app.secret_key = 'SP_APP_SAML_XSLT_VERIFICATION_2026'

AUDIT_LOG = '/var/log/sp-portal/audit.log'
MODSEC_AUDIT_LOG = '/var/log/nginx/modsec_audit.log'
MODSEC_CONF = '/etc/modsecurity/modsecurity_custom.conf'
VALIDATOR_FILE = '/opt/lab/xml_validator.py'
STATE_FILE = '/var/log/sp-portal/current_session.json'
IDP_SAML_URL = 'http://172.20.0.10/sso/saml'
ZEEK_MONITOR_IP = '172.20.0.30'
ZEEK_UDP_PORT = 9999

EMPLOYEES = [
    {"uid": "student", "name": "Nguyễn Văn Student", "dept": "Kỹ thuật & Vận hành", "role": "User", "email": "student@enterprise.corp"},
    {"uid": "alice", "name": "Trần Thị Alice", "dept": "Nhân sự & Hành chính", "role": "User", "email": "alice@enterprise.corp"},
    {"uid": "bob", "name": "Lê Văn Bob", "dept": "Tài chính & Kế toán", "role": "User", "email": "bob@enterprise.corp"},
    {"uid": "ldap-admin", "name": "Phạm Minh Admin", "dept": "Quản trị Hệ thống & Bảo mật", "role": "DomainAdmins", "email": "ldap-admin@enterprise.corp"}
]

USER_PROFILES = {emp["uid"]: emp for emp in EMPLOYEES}


def write_audit_log(msg):
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    os.makedirs(os.path.dirname(AUDIT_LOG), exist_ok=True)
    with open(AUDIT_LOG, 'a') as f:
        f.write(f"{ts} sp-app {msg}\n")
        f.flush()


def write_modsec_log(src_ip, uri, action, rule_id="9001001", matched_pattern="XSLT Transform"):
    ts = datetime.datetime.now().strftime('%d/%b/%Y:%H:%M:%S +0000')
    os.makedirs(os.path.dirname(MODSEC_AUDIT_LOG), exist_ok=True)
    with open(MODSEC_AUDIT_LOG, 'a') as f:
        if action == "BLOCKED":
            f.write(
                f"[{ts}] [client {src_ip}] ModSecurity: Access denied with code 403 (phase 2). "
                f"Pattern match \"{matched_pattern}\" at ARGS:SAMLResponse. "
                f"[file \"/etc/modsecurity/modsecurity_custom.conf\"] [id \"{rule_id}\"] "
                f"[msg \"SAML XSLT Transform Blocked by WAF\"] [uri \"{uri}\"]\n"
            )
        else:
            f.write(
                f"[{ts}] [client {src_ip}] ModSecurity: Warning. DetectionOnly mode active. "
                f"Pattern match \"{matched_pattern}\" at ARGS:SAMLResponse. "
                f"[file \"/etc/modsecurity/modsecurity_custom.conf\"] [uri \"{uri}\"]\n"
            )
        f.flush()


def forward_telemetry_to_zeek(src_ip, method, uri, user_agent, req_len, status_code, resp_len, xslt_detected):
    """Đồng bộ siêu dữ liệu HTTP sang zeek-monitor (172.20.0.30) để ghi nhận vào /var/log/zeek/http.log."""
    payload = {
        "ts": datetime.datetime.now(datetime.timezone.utc).timestamp(),
        "id.orig_h": src_ip or "172.20.0.20",
        "id.orig_p": 54321,
        "id.resp_h": "172.20.0.20",
        "id.resp_p": 80,
        "method": method,
        "host": "172.20.0.20",
        "uri": uri,
        "user_agent": user_agent or "python-requests/2.22.0",
        "request_body_len": req_len,
        "response_body_len": resp_len,
        "status_code": status_code,
        "status_msg": "OK" if status_code == 200 else ("Forbidden" if status_code == 403 else "Moved Temporarily"),
        "xslt_probe": bool(xslt_detected)
    }
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(json.dumps(payload).encode('utf-8'), (ZEEK_MONITOR_IP, ZEEK_UDP_PORT))
        sock.close()
    except Exception:
        pass


def inspect_modsecurity_waf(raw_body_str, decoded_saml_str):
    """
    Kiểm tra cấu hình /etc/modsecurity/modsecurity_custom.conf (Lớp 1 - Nginx ModSecurity WAF).
    Trả về (waf_mode, has_xslt_rule, is_blocked, matched_pattern)
    """
    if not os.path.exists(MODSEC_CONF):
        return "DetectionOnly", False, False, ""

    try:
        with open(MODSEC_CONF, 'r') as f:
            lines = f.readlines()
    except Exception:
        return "DetectionOnly", False, False, ""

    active_lines = [line.strip() for line in lines if line.strip() and not line.strip().startswith('#')]
    active_content = "\n".join(active_lines)

    # Kiểm tra SecRuleEngine
    waf_mode = "DetectionOnly"
    if re.search(r'SecRuleEngine\s+On\b', active_content, re.IGNORECASE):
        waf_mode = "On"
    elif re.search(r'SecRuleEngine\s+DetectionOnly\b', active_content, re.IGNORECASE):
        waf_mode = "DetectionOnly"

    # Kiểm tra SecRule chặn Namespace hoặc Algorithm XSLT
    has_secrule = bool(re.search(r'SecRule\b', active_content, re.IGNORECASE))
    has_ns_xsl = "http://www.w3.org/1999/XSL/Transform" in active_content
    has_alg_xslt = "http://www.w3.org/TR/1999/REC-xslt-19991116" in active_content
    has_xslt_rule = has_secrule and (has_ns_xsl or has_alg_xslt)

    # Nếu sinh viên đã thêm SecRule có deny/drop/block mà quên đổi dòng SecRuleEngine ở trên,
    # hoặc đã đổi SecRuleEngine On, WAF sẽ chặn các gói tin khớp mẫu XSLT.
    has_deny_action = bool(re.search(r'\b(deny|drop|block)\b', active_content, re.IGNORECASE))

    combined_payload = f"{raw_body_str}\n{decoded_saml_str}"
    matched_pattern = ""
    if has_ns_xsl and "http://www.w3.org/1999/XSL/Transform" in combined_payload:
        matched_pattern = "http://www.w3.org/1999/XSL/Transform"
    elif has_alg_xslt and "http://www.w3.org/TR/1999/REC-xslt-19991116" in combined_payload:
        matched_pattern = "http://www.w3.org/TR/1999/REC-xslt-19991116"

    if has_xslt_rule and matched_pattern and (waf_mode == "On" or has_deny_action):
        return "On", True, True, matched_pattern

    return waf_mode, has_xslt_rule, False, matched_pattern


def check_validator_xslt_status():
    """Đọc trực tiếp /opt/lab/xml_validator.py để lấy trạng thái cờ enable_xslt_transform."""
    if not os.path.exists(VALIDATOR_FILE):
        return True
    try:
        with open(VALIDATOR_FILE, 'r') as f:
            code = f.read()
        ns = {}
        exec(code, ns)
        if 'is_xslt_enabled' in ns:
            return bool(ns['is_xslt_enabled']())
        if 'enable_xslt_transform' in ns:
            return bool(ns['enable_xslt_transform'])
        if 'ENABLE_XSLT_TRANSFORM' in ns:
            return bool(ns['ENABLE_XSLT_TRANSFORM'])
    except Exception:
        pass
    return True


def execute_validator_transform(xml_bytes):
    """Gọi hàm process_saml_transforms trong /opt/lab/xml_validator.py."""
    if os.path.exists(VALIDATOR_FILE):
        try:
            with open(VALIDATOR_FILE, 'r') as f:
                code = f.read()
            ns = {}
            exec(code, ns)
            if 'process_saml_transforms' in ns:
                return ns['process_saml_transforms'](xml_bytes)
        except Exception:
            pass
    xslt_on = check_validator_xslt_status()
    if xslt_on:
        return True, "<WARNING>XSLT_IS_ENABLED</WARNING>", "XSLT_EXECUTED_FALLBACK"
    return False, "REJECTED: XSLT Transform is disabled.", "XSLT_DISABLED"


def load_shared_session():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, 'r') as f:
                return json.load(f)
        except Exception:
            pass
    return {
        "user": "student",
        "name": "Nguyễn Văn Student",
        "role": "User",
        "dept": "Kỹ thuật & Vận hành",
        "email": "student@enterprise.corp"
    }


def save_shared_session(data):
    os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
    with open(STATE_FILE, 'w') as f:
        json.dump(data, f)


def clear_shared_session():
    if os.path.exists(STATE_FILE):
        try:
            os.remove(STATE_FILE)
        except Exception:
            pass


PORTAL_HTML = """<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enterprise SAML SP-App (Nginx WAF + Flask XML)</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; color: #0f172a; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; min-height: 100vh; display: flex; flex-direction: column; }
        .navbar-light-sp { background: #ffffff; border-bottom: 1px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0,0,0,0.03); }
        .card-light { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; box-shadow: 0 4px 14px rgba(15,23,42,0.04); }
        .badge-safe { background: #ecfdf5; color: #059669; border: 1px solid #a7f3d0; font-weight: 700; }
        .badge-risk { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; font-weight: 700; }
        footer { margin-top: auto; background: #ffffff; border-top: 1px solid #e2e8f0; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light-sp py-3 px-4 mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold text-primary d-flex align-items-center gap-2" href="/">
            <span>🛡️</span>
            <span>Enterprise SP-App (SAML 2.0 &amp; XSLT Security Dashboard)</span>
        </a>
        <div class="d-flex align-items-center gap-3">
            {% if current_user %}
            <span class="badge bg-light text-dark border px-3 py-2">
                👤 <strong>{{ current_user.name }}</strong> (<code>{{ current_user.user }}</code>)
            </span>
            <a href="{{ idp_url }}" class="btn btn-outline-primary btn-sm px-3">Đổi tài khoản SSO</a>
            <a href="/logout" class="btn btn-outline-danger btn-sm px-3">Đăng xuất</a>
            {% else %}
            <a href="{{ idp_url }}" class="btn btn-primary btn-sm px-3">Đăng nhập SAML SSO</a>
            {% endif %}
        </div>
    </div>
</nav>

<main class="container pb-5">
    <div class="row g-4 mb-4">
        <div class="col-md-6">
            <div class="card-light p-4 h-100">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h6 class="fw-bold mb-0">Lớp 1: Nginx + ModSecurity WAF</h6>
                    {% if has_xslt_rule and waf_mode == 'On' %}
                    <span class="badge badge-safe px-3 py-1">ĐÃ BẬT CHẶN XSLT (ACTIVE)</span>
                    {% else %}
                    <span class="badge badge-risk px-3 py-1">CHẾ ĐỘ DETECTION ONLY</span>
                    {% endif %}
                </div>
                <p class="small text-secondary mb-2">Tệp cấu hình: <code>/etc/modsecurity/modsecurity_custom.conf</code></p>
                <div class="small bg-light p-2 rounded border">
                    Trạng thái Engine: <strong>{{ waf_mode }}</strong> |
                    Rule chặn XSLT: <strong>{{ 'Đã cấu hình' if has_xslt_rule else 'Chưa cấu hình' }}</strong>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card-light p-4 h-100">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h6 class="fw-bold mb-0">Lớp 2: Flask App XML Validator</h6>
                    {% if not xslt_enabled %}
                    <span class="badge badge-safe px-3 py-1">ĐÃ TẮT XSLT (SAFE)</span>
                    {% else %}
                    <span class="badge badge-risk px-3 py-1">XSLT ĐANG BẬT (VULNERABLE)</span>
                    {% endif %}
                </div>
                <p class="small text-secondary mb-2">Tệp cấu hình: <code>/opt/lab/xml_validator.py</code></p>
                <div class="small bg-light p-2 rounded border">
                    Cờ cấu hình: <code>enable_xslt_transform = {{ xslt_enabled }}</code>
                </div>
            </div>
        </div>
    </div>

    <div class="card-light p-4">
        <h6 class="fw-bold mb-3">Thông tin Hệ thống &amp; Phiên làm việc SAML 2.0</h6>
        <table class="table table-bordered align-middle mb-0">
            <tbody>
                <tr>
                    <th class="bg-light" style="width: 30%;">SAML ACS Endpoint</th>
                    <td><code>http://172.20.0.20/saml/acs</code> (Nhận gói tin POST <code>SAMLResponse</code>)</td>
                </tr>
                <tr>
                    <th class="bg-light">Máy chủ Cấp phát SAML (IdP)</th>
                    <td><code>http://172.20.0.10/sso/saml</code> (<code>ldap-idp</code>)</td>
                </tr>
                <tr>
                    <th class="bg-light">Máy chủ Giám sát Blue Team</th>
                    <td><code>172.20.0.30</code> (<code>zeek-monitor</code> - Ghi log tại <code>/var/log/zeek/http.log</code>)</td>
                </tr>
                <tr>
                    <th class="bg-light">Script Kiểm thử Cấu hình XSLT</th>
                    <td><code>python3 /opt/lab/verify_xslt_config.py</code></td>
                </tr>
            </tbody>
        </table>
    </div>
</main>

<footer class="py-3 text-center text-secondary small">
    <div class="container">
        Enterprise Service Provider (172.20.0.20) | Lab: saml-xslt-config-verification
    </div>
</footer>
</body>
</html>"""


@app.route('/')
@app.route('/login')
def index():
    if session.get('logged_out'):
        current_user = None
    else:
        current_user = load_shared_session()
    waf_mode, has_xslt_rule, _, _ = inspect_modsecurity_waf("", "")
    xslt_enabled = check_validator_xslt_status()
    return render_template_string(
        PORTAL_HTML,
        current_user=current_user,
        idp_url=IDP_SAML_URL,
        waf_mode=waf_mode,
        has_xslt_rule=has_xslt_rule,
        xslt_enabled=xslt_enabled
    ), 200


@app.route('/logout')
def logout():
    session['logged_out'] = True
    clear_shared_session()
    return redirect('/login')


@app.route('/saml/acs', methods=['GET', 'POST'])
def saml_acs():
    src_ip = request.headers.get('X-Forwarded-For', request.remote_addr) or '172.20.0.20'
    user_agent = request.headers.get('User-Agent', 'python-requests/2.22.0')
    raw_body = request.get_data(as_text=True) or ''
    req_len = len(raw_body.encode('utf-8'))

    b64_saml = request.form.get('SAMLResponse') or request.args.get('SAMLResponse') or ''
    decoded_xml_bytes = b''
    decoded_xml_str = ''
    if b64_saml:
        try:
            decoded_xml_bytes = base64.b64decode(b64_saml)
            decoded_xml_str = decoded_xml_bytes.decode('utf-8', errors='ignore')
        except Exception:
            decoded_xml_str = b64_saml
            decoded_xml_bytes = b64_saml.encode('utf-8', errors='ignore')

    has_xslt_indicator = (
        "http://www.w3.org/TR/1999/REC-xslt-19991116" in decoded_xml_str
        or "http://www.w3.org/1999/XSL/Transform" in decoded_xml_str
        or "http://www.w3.org/TR/1999/REC-xslt-19991116" in raw_body
        or "http://www.w3.org/1999/XSL/Transform" in raw_body
    )

    # 1. Kiểm tra Lớp ngoài: Nginx + ModSecurity WAF (/etc/modsecurity/modsecurity_custom.conf)
    waf_mode, has_xslt_rule, is_waf_blocked, matched_pattern = inspect_modsecurity_waf(raw_body, decoded_xml_str)
    if has_xslt_indicator:
        if is_waf_blocked:
            write_modsec_log(src_ip, "/saml/acs", "BLOCKED", matched_pattern=matched_pattern)
            write_audit_log(f"[XSLT_BLOCKED_SAFE] [MODSECURITY_WAF_403] srcip={src_ip} matched={matched_pattern}")
            resp_body = (
                "<html><head><title>403 Forbidden</title></head>"
                "<body><center><h1>403 Forbidden</h1></center>"
                "<hr><center>nginx / ModSecurity WAF: SAML XSLT Transform Blocked</center></body></html>"
            )
            forward_telemetry_to_zeek(src_ip, request.method, "/saml/acs", user_agent, req_len, 403, len(resp_body), True)
            return Response(resp_body, status=403, mimetype='text/html')
        else:
            write_modsec_log(src_ip, "/saml/acs", "DETECTED", matched_pattern=matched_pattern or "XSLT_Transform")

    # 2. Kiểm tra Lớp trong: Flask App + XML Validator (/opt/lab/xml_validator.py)
    if has_xslt_indicator:
        allowed, transform_output, reason = execute_validator_transform(decoded_xml_bytes)
        if not allowed:
            write_audit_log(f"[XSLT_BLOCKED_SAFE] [FLASK_VALIDATOR_403] srcip={src_ip} reason={reason}")
            resp_json = jsonify({
                "status": "REJECTED",
                "error": "XSLT Transform is disabled in /opt/lab/xml_validator.py",
                "reason": reason
            })
            forward_telemetry_to_zeek(src_ip, request.method, "/saml/acs", user_agent, req_len, 403, 128, True)
            return resp_json, 403
        else:
            write_audit_log(f"[XSLT_VULNERABLE_ENABLED] srcip={src_ip} reason={reason}")
            resp_text = f"<!-- SAML ACS Response -->\n{transform_output}\n"
            forward_telemetry_to_zeek(src_ip, request.method, "/saml/acs", user_agent, req_len, 200, len(resp_text), True)
            return Response(resp_text, status=200, mimetype='application/xml')

    # 3. Xử lý đăng nhập SAML thông thường (không chứa XSLT)
    signed_subject = 'student'
    if decoded_xml_bytes:
        try:
            root = etree.fromstring(decoded_xml_bytes)
            ns = {'saml': 'urn:oasis:names:tc:SAML:2.0:assertion'}
            nid = root.xpath('//saml:Subject/saml:NameID', namespaces=ns)
            if nid and nid[0].text:
                signed_subject = nid[0].text.strip()
        except Exception:
            pass

    profile = USER_PROFILES.get(signed_subject, USER_PROFILES['student'])
    user_state = {
        "user": signed_subject,
        "name": profile["name"],
        "role": profile["role"],
        "dept": profile["dept"],
        "email": profile["email"]
    }
    session.pop('logged_out', None)
    save_shared_session(user_state)
    write_audit_log(f"[SAML_SSO_LOGIN] srcip={src_ip} user={signed_subject} role={user_state['role']}")
    forward_telemetry_to_zeek(src_ip, request.method, "/saml/acs", user_agent, req_len, 302, 0, False)
    return redirect('/')


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, use_reloader=False)
