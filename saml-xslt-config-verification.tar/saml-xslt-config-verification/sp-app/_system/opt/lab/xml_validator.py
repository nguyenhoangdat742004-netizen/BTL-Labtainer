#!/usr/bin/env python3
"""
Module Cấu hình & Xác thực Chữ ký SAML XML (/opt/lab/xml_validator.py)
Sử dụng thư viện XML (lxml / xmlsec) để phân tích và kiểm tra các phép biến đổi <ds:Transform>.
Sinh viên sử dụng lệnh `labedit /opt/lab/xml_validator.py` để khắc phục lỗ hổng cấu hình XSLT.
"""
from lxml import etree

# [LỖ HỔNG CẤU HÌNH - CẦN KHẮC PHỤC]
# Cờ cho phép phân giải thẻ <ds:Transform> bằng XSLT (http://www.w3.org/TR/1999/REC-xslt-19991116)
# hoặc Namespace XSLT (http://www.w3.org/1999/XSL/Transform) đang được bật (True).
# Điều này vi phạm tiêu chuẩn an toàn SAML 2.0 do XSLT có thể dẫn đến lỗi xử lý XML hoặc RCE/XXE.
# Nhiệm vụ: Hãy đổi giá trị cờ bên dưới thành False để vô hiệu hóa tính năng XSLT Transform!
enable_xslt_transform = True


def is_xslt_enabled():
    """Kiểm tra trạng thái cờ cho phép XSLT Transform."""
    return bool(globals().get('enable_xslt_transform', False) and globals().get('ENABLE_XSLT_TRANSFORM', True))


def process_saml_transforms(xml_bytes):
    """
    Phân tích gói tin SAML XML và xử lý thẻ <ds:Transform> nếu có.
    Trả về tuple: (allowed: bool, output_text: str, status_reason: str)
    """
    xml_text = xml_bytes.decode('utf-8', errors='ignore')
    has_xslt = (
        "http://www.w3.org/TR/1999/REC-xslt-19991116" in xml_text
        or "http://www.w3.org/1999/XSL/Transform" in xml_text
        or "xsl:stylesheet" in xml_text
    )

    if not has_xslt:
        return True, "STANDARD_XMLDSIG_OK", "NO_XSLT"

    if not is_xslt_enabled():
        return False, "REJECTED: XSLT Transform is disabled by XML Validator policy.", "XSLT_DISABLED_BY_VALIDATOR"

    # Khi enable_xslt_transform = True: Thực thi biến đổi XSLT trên tài liệu XML
    try:
        parser = etree.XMLParser(recover=True)
        root = etree.fromstring(xml_bytes, parser=parser)
        ns = {'xsl': 'http://www.w3.org/1999/XSL/Transform'}
        stylesheets = root.xpath('//xsl:stylesheet', namespaces=ns)
        if stylesheets:
            transform = etree.XSLT(stylesheets[0])
            result_tree = transform(root)
            return True, str(result_tree), "XSLT_EXECUTED"
    except Exception:
        pass

    return True, "<WARNING>XSLT_IS_ENABLED</WARNING>", "XSLT_EXECUTED_FALLBACK"
