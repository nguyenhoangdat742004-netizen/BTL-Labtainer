#!/bin/bash
# fixlocal.sh for sp-app (172.20.0.20)
grep -q "ldap-idp" /etc/hosts 2>/dev/null || echo "172.20.0.10 ldap-idp idp.lab ldap.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "sp-app" /etc/hosts 2>/dev/null || echo "172.20.0.20 sp-app sp.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "zeek-monitor" /etc/hosts 2>/dev/null || echo "172.20.0.30 zeek-monitor zeek.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1

sudo mkdir -p /tmp/.X11-unix
if [ -d /var/tmp/.X11-unix ]; then
    for sock in /var/tmp/.X11-unix/*; do
        if [ -e "$sock" ]; then
            base=$(basename "$sock")
            sudo ln -sf "$sock" "/tmp/.X11-unix/$base" 2>/dev/null || true
        fi
    done
fi
sudo chmod 1777 /tmp/.X11-unix 2>/dev/null || true

mkdir -p /home/ubuntu/Desktop
ln -sf /opt/lab/verify_xslt_config.py /home/ubuntu/verify_xslt_config.py 2>/dev/null || true
ln -sf /opt/lab/xml_validator.py /home/ubuntu/xml_validator.py 2>/dev/null || true
ln -sf /etc/modsecurity/modsecurity_custom.conf /home/ubuntu/modsecurity_custom.conf 2>/dev/null || true
ln -sf /opt/lab/rule_modsec_mau.txt /home/ubuntu/rule_modsec_mau.txt 2>/dev/null || true
ln -sf /opt/lab /home/ubuntu/lab 2>/dev/null || true

ln -sf /opt/lab/verify_xslt_config.py /home/ubuntu/Desktop/verify_xslt_config.py 2>/dev/null || true
ln -sf /opt/lab/xml_validator.py /home/ubuntu/Desktop/xml_validator.py 2>/dev/null || true
ln -sf /opt/lab/rule_modsec_mau.txt /home/ubuntu/Desktop/rule_modsec_mau.txt 2>/dev/null || true

sudo chown -R ubuntu:ubuntu /home/ubuntu /opt/lab 2>/dev/null || true
sudo chmod -R 777 /opt/lab /etc/modsecurity 2>/dev/null || true
sudo chmod +x /opt/lab/*.py /usr/local/bin/labedit /etc/rc.local 2>/dev/null || true
sudo /etc/rc.local
echo "[OK] sp-app (172.20.0.20) đã sẵn sàng! Chạy 'python3 /opt/lab/verify_xslt_config.py' để kiểm thử hoặc dùng 'labedit' để cấu hình phòng thủ."
