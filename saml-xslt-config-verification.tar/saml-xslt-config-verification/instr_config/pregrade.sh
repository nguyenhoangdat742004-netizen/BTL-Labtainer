#!/bin/bash
# Pregrade script for saml-xslt-config-verification
homedir=$1
destdir=$2
cd $homedir/$destdir 2>/dev/null || true
