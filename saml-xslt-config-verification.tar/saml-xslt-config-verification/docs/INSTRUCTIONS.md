# HƯỚNG DẪN THỰC HÀNH: KIỂM THỬ VÀ VÔ HIỆU HÓA TÍNH NĂNG XSLT TRANSFORM TRONG SAML XML (`saml-xslt-config-verification`)

---

## 1. KIẾN TRÚC HỆ THỐNG (3 CONTAINER TRÊN MẠNG `172.20.0.0/24`)

1. **`ldap-idp` (`172.20.0.10`)**:
   - Đóng vai trò máy chủ cấp phát SAML 2.0 (Identity Provider) tại `http://172.20.0.10/sso/saml`.
2. **`sp-app` (`172.20.0.20`)**:
   - Máy chủ Web Service Provider chạy kiến trúc 2 lớp:
     - **Lớp ngoài**: **Nginx** tích hợp **ModSecurity WAF** (`/etc/modsecurity/modsecurity_custom.conf`), ban đầu đang để chế độ `DetectionOnly`.
     - **Lớp trong**: **Flask App** sử dụng thư viện XML (`/opt/lab/xml_validator.py`). Lỗ hổng cấu hình ở đây là thư viện XML đang cho phép phân giải thẻ `<ds:Transform>` bằng XSLT (`enable_xslt_transform = True`).
3. **`zeek-monitor` (`172.20.0.30`)**:
   - Máy chủ giám sát mạng **Blue Team**. Chạy dịch vụ **Zeek IDS** ngầm, bắt gói tin mạng và ghi log lưu lượng HTTP vào `/var/log/zeek/http.log`.

---

## 2. CÁC GIAI ĐOẠN THỰC HÀNH CHI TIẾT

### GIAI ĐOẠN 1 & 2: KIỂM THỬ CẤU HÌNH XSLT TRÊN `sp-app` (`172.20.0.20`)

Tại cửa sổ terminal của **`sp-app` (`172.20.0.20`)**, bạn có thể kiểm tra nội dung script kiểm thử `/opt/lab/verify_xslt_config.py` và chạy script:

```bash
cat /opt/lab/verify_xslt_config.py
python3 /opt/lab/verify_xslt_config.py
```

**Kết quả ban đầu:**
```text
[*] Đang kiểm tra cấu hình XSLT Transform trên SP-App...
[!] CẢNH BÁO: SP-App đang cho phép xử lý XSLT (Rủi ro cấu hình).
```

Bạn cũng có thể mở trình duyệt trên `sp-app` để quan sát bảng trạng thái bảo mật 2 lớp:
```bash
firefox http://172.20.0.20 &
```

---

### GIAI ĐOẠN 3: PHÂN TÍCH MẠNG BẰNG ZEEK TRÊN `zeek-monitor` (`172.20.0.30`)

Chuyển sang terminal của máy **`zeek-monitor` (`172.20.0.30`)**, phân tích tệp `/var/log/zeek/http.log`:

```bash
cat /var/log/zeek/http.log
grep "/saml/acs" /var/log/zeek/http.log
cat /var/log/zeek/http.log | zeek-cut ts id.orig_h id.resp_h method host uri status_code user_agent
```

Bạn sẽ quan sát thấy các request `POST` liên tục gửi đến `/saml/acs` trên máy `172.20.0.20`.

---

### GIAI ĐOẠN 4: THIẾT LẬP WAF VÀ KHẮC PHỤC MÃ NGUỒN (NHIỆM VỤ SINH VIÊN)

Quay lại terminal của **`sp-app` (`172.20.0.20`)**, thực hiện 2 lớp bảo vệ bằng lệnh `labedit`:

#### 1. Cấu hình ModSecurity WAF (`1_modsecurity_rule_configured`)

Mở tệp `/etc/modsecurity/modsecurity_custom.conf` bằng lệnh `labedit`:

```bash
labedit /etc/modsecurity/modsecurity_custom.conf
```

*(Có thể xem mẫu tại `cat ~/rule_modsec_mau.txt`)*. Cập nhật chế độ `SecRuleEngine On` và thêm `SecRule` chặn Namespace `http://www.w3.org/1999/XSL/Transform` hoặc thuật toán `http://www.w3.org/TR/1999/REC-xslt-19991116` trong Request Body:

```apache
SecRuleEngine On

SecRule REQUEST_BODY|ARGS:SAMLResponse "@rx (http://www.w3.org/1999/XSL/Transform|http://www.w3.org/TR/1999/REC-xslt-19991116)" \
    "id:9001001,phase:2,t:none,t:urlDecodeUni,t:base64Decode,deny,status:403,log,msg:'SAML XSLT Transform Detected and Blocked'"
```

Lưu tệp (`Ctrl+O`, `Enter`, `Ctrl+X`).

#### 2. Khắc phục mã nguồn Flask (`2_flask_xslt_disabled`)

Mở tệp `/opt/lab/xml_validator.py` bằng lệnh `labedit`:

```bash
labedit /opt/lab/xml_validator.py
```

Tìm dòng cấu hình cờ `enable_xslt_transform` và đổi giá trị từ `True` sang `False`:

```python
enable_xslt_transform = False
```

Lưu tệp (`Ctrl+O`, `Enter`, `Ctrl+X`).

#### 3. Kiểm thử lại cấu hình sau khi khắc phục (`3_xslt_verification_passed`)

Chạy lại script kiểm thử trên `sp-app`:

```bash
python3 /opt/lab/verify_xslt_config.py
```

**Kết quả sau khi phòng thủ 2 lớp:**
```text
[*] Đang kiểm tra cấu hình XSLT Transform trên SP-App...
[-] Hệ thống an toàn: Tính năng XSLT đã bị chặn.
```

---

## 3. KIỂM TRA KẾT QUẢ TỰ ĐỘNG (`checkwork`)

Tại terminal trên máy Host, gõ lệnh:

```bash
checkwork
```

Kết quả đạt đủ 3/3 tiêu chí nghiệm thu (`Y`):

```text
Labname saml-xslt-config-verification

Student: <email>
 Y -  1_modsecurity_rule_configured
 Y -  2_flask_xslt_disabled
 Y -  3_xslt_verification_passed
```
