#!/bin/bash
# fixlocal.sh for zeek-monitor (172.20.0.30)
grep -q "ldap-idp" /etc/hosts 2>/dev/null || echo "172.20.0.10 ldap-idp idp.lab ldap.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "sp-app" /etc/hosts 2>/dev/null || echo "172.20.0.20 sp-app sp.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "zeek-monitor" /etc/hosts 2>/dev/null || echo "172.20.0.30 zeek-monitor zeek.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1

mkdir -p /home/ubuntu/Desktop /var/log/zeek
ln -sf /var/log/zeek/http.log /home/ubuntu/http.log 2>/dev/null || true
ln -sf /var/log/zeek/http.log /home/ubuntu/Desktop/http.log 2>/dev/null || true

cat << 'EOF_ZEEK' > /home/ubuntu/Desktop/HUONG_DAN_ZEEK.txt
================================================================================
HƯỚNG DẪN PHÂN TÍCH MẠNG BẰNG ZEEK (BLUE TEAM - 172.20.0.30)
================================================================================
1. Xem toàn bộ nhật ký HTTP do Zeek IDS ghi nhận:
   cat /var/log/zeek/http.log

2. Lọc các request POST gửi liên tục đến endpoint /saml/acs:
   grep "/saml/acs" /var/log/zeek/http.log

3. Trích xuất các trường quan trọng bằng công cụ zeek-cut:
   cat /var/log/zeek/http.log | zeek-cut ts id.orig_h id.resp_h method host uri status_code user_agent

4. Theo dõi thời gian thực khi chạy verify_xslt_config.py bên máy sp-app:
   tail -f /var/log/zeek/http.log
================================================================================
EOF_ZEEK

sudo chown -R ubuntu:ubuntu /home/ubuntu 2>/dev/null || true
sudo chmod -R 777 /var/log/zeek 2>/dev/null || true
sudo chmod +x /usr/local/bin/zeek_monitor_daemon.py /usr/local/bin/zeek-cut /usr/local/bin/zeekctl /etc/rc.local 2>/dev/null || true
sudo /etc/rc.local
echo "[OK] Máy chủ zeek-monitor (172.20.0.30) đã sẵn sàng! Phân tích log tại /var/log/zeek/http.log."
