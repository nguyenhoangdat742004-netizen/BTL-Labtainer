import numpy as np

bits = np.loadtxt("recovered_bits.txt", dtype=int)

chars = []

for i in range(0, len(bits), 8):

    byte = bits[i:i+8]

    byte_str = ''.join(map(str, byte))

    chars.append(chr(int(byte_str, 2)))

message = ''.join(chars)

print("Recovered Message:")
print(message)

with open("recovered_message.txt", "w") as f:
    f.write(message)

print("Recovered message saved!")