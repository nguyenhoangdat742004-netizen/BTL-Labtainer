#!/usr/bin/env python3
import requests

# [HỌC VIÊN CÓ THỂ SỬA ĐỔI ĐƯỜNG DẪN HOẶC THAM SỐ PROBE TẠI ĐÂY]
ACS_URL = "http://172.20.0.20/saml/acs"

def verify_xml_parser_config():
    print("[*] Đang kiểm tra cấu hình trình phân tích XML trên SP-App...")
    try:
        response = requests.get(ACS_URL, params={"verify_schema": "strict_single_assertion"})
        if response.status_code == 200 and "multiple_assertions_allowed" in response.text:
            print("[+] [CẢNH BÁO]: SP-App chưa chặn cấu hình đa khối Assertion.")
        else:
            print("[-] Cấu hình an toàn: SP-App yêu cầu khớp tuyệt đối Reference ID.")
    except Exception as e:
        print(f"[-] Lỗi kết nối: {e}")

if __name__ == "__main__":
    verify_xml_parser_config()
