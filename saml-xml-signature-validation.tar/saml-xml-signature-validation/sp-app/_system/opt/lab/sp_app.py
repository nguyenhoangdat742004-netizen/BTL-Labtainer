#!/usr/bin/env python3
"""
Enterprise Workspace Portal (Service Provider - Light Theme, Port 80 & Port 5000)
Lab: saml-xml-signature-validation (sp-app: 172.20.0.20)
"""
import os
import json
import base64
import threading
import datetime
from flask import Flask, request, redirect, session, render_template_string, jsonify
from lxml import etree

app = Flask(__name__)
app.secret_key = 'SP_APP_ENTERPRISE_PORTAL_LIGHT_2026'

AUDIT_LOG = '/var/log/sp-portal/audit.log'
APP_JSON_LOG = '/var/log/sp-portal/app.json'
STATE_FILE = '/var/log/sp-portal/current_session.json'
VALIDATOR_FILE = '/opt/lab/xml_validator.py'
IDP_SAML_URL = 'http://172.20.0.10/sso/saml'

EMPLOYEES = [
    {"uid": "student", "name": "Nguyễn Văn Student", "dept": "Kỹ thuật & Vận hành", "role": "User", "email": "student@enterprise.corp"},
    {"uid": "alice", "name": "Trần Thị Alice", "dept": "Nhân sự & Hành chính", "role": "User", "email": "alice@enterprise.corp"},
    {"uid": "bob", "name": "Lê Văn Bob", "dept": "Tài chính & Kế toán", "role": "User", "email": "bob@enterprise.corp"},
    {"uid": "ldap-admin", "name": "Phạm Minh Admin", "dept": "Quản trị Hệ thống & Bảo mật", "role": "DomainAdmins", "email": "ldap-admin@enterprise.corp"}
]

USER_PROFILES = {emp["uid"]: emp for emp in EMPLOYEES}

def check_strict_validator():
    if not os.path.exists(VALIDATOR_FILE):
        return False
    try:
        with open(VALIDATOR_FILE, 'r') as f:
            code = f.read()
        ns = {}
        exec(code, ns)
        if 'is_strict_mode_enabled' in ns:
            return bool(ns['is_strict_mode_enabled']())
        return bool(ns.get('STRICT_SINGLE_ASSERTION', False) or ns.get('ENFORCE_REFERENCE_ID', False))
    except Exception:
        return False

def load_shared_session():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, 'r') as f:
                return json.load(f)
        except Exception:
            pass
    return {
        "user": "student",
        "name": "Nguyễn Văn Student",
        "role": "User",
        "dept": "Kỹ thuật & Vận hành",
        "email": "student@enterprise.corp"
    }

def save_shared_session(data):
    os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
    with open(STATE_FILE, 'w') as f:
        json.dump(data, f)

def clear_shared_session():
    if os.path.exists(STATE_FILE):
        try:
            os.remove(STATE_FILE)
        except Exception:
            pass

def write_audit_log(msg):
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    os.makedirs(os.path.dirname(AUDIT_LOG), exist_ok=True)
    with open(AUDIT_LOG, 'a') as f:
        f.write(f"{ts} sp-app {msg}\n")
        f.flush()

def write_json_log(data_dict):
    os.makedirs(os.path.dirname(APP_JSON_LOG), exist_ok=True)
    with open(APP_JSON_LOG, 'a') as f:
        f.write(json.dumps(data_dict) + '\n')
        f.flush()

PORTAL_HTML = """<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enterprise Workspace Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; color: #0f172a; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; min-height: 100vh; display: flex; flex-direction: column; }
        .navbar-light-sp { background: #ffffff; border-bottom: 1px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0,0,0,0.03); }
        .card-light { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; box-shadow: 0 4px 14px rgba(15,23,42,0.04); }
        .badge-admin { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; font-weight: 700; }
        .badge-user { background: #eff6ff; color: #2563eb; border: 1px solid #bfdbfe; font-weight: 600; }
        .nav-pills .nav-link { color: #475569; font-weight: 500; border-radius: 8px; }
        .nav-pills .nav-link.active { background-color: #2563eb; color: #ffffff; }
        footer { margin-top: auto; background: #ffffff; border-top: 1px solid #e2e8f0; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light-sp py-3 px-4 mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold text-primary d-flex align-items-center gap-2" href="/">
            <span>🏢</span>
            <span>Enterprise Workspace Portal</span>
        </a>
        <div class="d-flex align-items-center gap-3">
            {% if current_user %}
            <span class="badge bg-light text-dark border px-3 py-2">
                👤 <strong>{{ current_user.name }}</strong>
                ({% if current_user.role == 'DomainAdmins' %}<span class="text-danger fw-bold">DomainAdmins</span>{% else %}<span class="text-primary">{{ current_user.role }}</span>{% endif %})
            </span>
            <a href="{{ idp_url }}" class="btn btn-outline-primary btn-sm px-3">Đổi tài khoản SSO</a>
            <a href="/logout" class="btn btn-outline-danger btn-sm px-3">Đăng xuất</a>
            {% else %}
            <a href="{{ idp_url }}" class="btn btn-primary btn-sm px-3">Đăng nhập SAML SSO</a>
            {% endif %}
        </div>
    </div>
</nav>

<main class="container pb-5">
    {% if current_user %}
    <div class="card-light p-4 mb-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
                <h3 class="fw-bold mb-1">Xin chào, {{ current_user.name }}</h3>
                <p class="text-secondary mb-0">
                    Tài khoản: <code>{{ current_user.user }}</code> |
                    Email: <code>{{ current_user.email }}</code> |
                    Phòng ban: <strong>{{ current_user.dept }}</strong>
                </p>
            </div>
            <div>
                {% if current_user.role == 'DomainAdmins' %}
                <span class="badge badge-admin px-3 py-2 fs-6">🔓 QUẢN TRỊ VIÊN HỆ THỐNG (DOMAIN ADMINS)</span>
                {% else %}
                <span class="badge badge-user px-3 py-2 fs-6">🔒 NHÂN VIÊN TIÊU CHUẨN (USER)</span>
                {% endif %}
            </div>
        </div>
    </div>

    <ul class="nav nav-pills gap-2 mb-4 bg-white p-2 rounded-3 border">
        <li class="nav-item">
            <a class="nav-link {% if tab == 'dashboard' %}active{% endif %}" href="/?tab=dashboard">🏠 Trang chủ &amp; Hồ sơ cá nhân</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {% if tab == 'directory' %}active{% endif %}" href="/?tab=directory">👥 Danh bạ Nhân sự</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {% if tab == 'admin' %}active{% endif %}" href="/?tab=admin">🛡️ Quản trị Hệ thống (Admin Console)</a>
        </li>
    </ul>

    {% if tab == 'dashboard' %}
    <div class="row g-4">
        <div class="col-lg-6">
            <div class="card-light p-4 h-100">
                <h6 class="fw-bold mb-3">Thông tin Tài khoản &amp; Phiên làm việc SSO</h6>
                <table class="table table-bordered align-middle mb-0">
                    <tbody>
                        <tr>
                            <th class="bg-light" style="width: 38%;">Họ và tên</th>
                            <td>{{ current_user.name }}</td>
                        </tr>
                        <tr>
                            <th class="bg-light">Tài khoản (UID)</th>
                            <td><code>{{ current_user.user }}</code></td>
                        </tr>
                        <tr>
                            <th class="bg-light">Email công ty</th>
                            <td>{{ current_user.email }}</td>
                        </tr>
                        <tr>
                            <th class="bg-light">Phòng ban</th>
                            <td>{{ current_user.dept }}</td>
                        </tr>
                        <tr>
                            <th class="bg-light">Nhóm phân quyền</th>
                            <td>
                                {% if current_user.role == 'DomainAdmins' %}
                                <span class="badge badge-admin">DomainAdmins (Toàn quyền quản trị)</span>
                                {% else %}
                                <span class="badge badge-user">User (Nhân viên)</span>
                                {% endif %}
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card-light p-4 h-100">
                <h6 class="fw-bold mb-3">Bảng tin &amp; Tiện ích Nội bộ</h6>
                <div class="border rounded-3 p-3 mb-3 bg-light">
                    <div class="fw-semibold text-primary mb-1">📌 Thông báo Vận hành Hệ thống</div>
                    <div class="small text-secondary">
                        Cổng thông tin nội bộ sử dụng xác thực tập trung SAML 2.0 SSO kết nối với máy chủ danh bạ OpenLDAP doanh nghiệp (<code>172.20.0.10</code>).
                    </div>
                </div>
                <div class="border rounded-3 p-3 bg-light">
                    <div class="fw-semibold text-primary mb-1">🔐 Phân quyền Truy cập</div>
                    <div class="small text-secondary">
                        Nhân viên thuộc nhóm <code>User</code> có quyền xem thông tin cá nhân và danh bạ nội bộ. Khu vực <strong>Quản trị Hệ thống (Admin Console)</strong> chỉ mở cho tài khoản thuộc nhóm <code>DomainAdmins</code>.
                    </div>
                </div>
            </div>
        </div>
    </div>
    {% elif tab == 'directory' %}
    <div class="card-light p-4">
        <h6 class="fw-bold mb-3">Danh bạ Nhân sự Doanh nghiệp (OpenLDAP Directory)</h6>
        <table class="table table-hover table-bordered align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Tài khoản (UID)</th>
                    <th>Họ và tên</th>
                    <th>Phòng ban</th>
                    <th>Email</th>
                    <th>Nhóm quyền</th>
                </tr>
            </thead>
            <tbody>
                {% for emp in employees %}
                <tr>
                    <td><code>{{ emp.uid }}</code></td>
                    <td class="fw-semibold">{{ emp.name }}</td>
                    <td>{{ emp.dept }}</td>
                    <td>{{ emp.email }}</td>
                    <td>
                        <span class="badge {% if emp.role == 'DomainAdmins' %}badge-admin{% else %}badge-user{% endif %}">
                            {{ emp.role }}
                        </span>
                    </td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
    </div>
    {% elif tab == 'admin' %}
    <div class="card-light p-4">
        <h5 class="fw-bold mb-3">🛡️ Bảng Điều Khiển Quản Trị Hệ Thống (Domain Admin Console)</h5>
        {% if current_user.role == 'DomainAdmins' %}
        <div class="alert alert-success small">
            <strong>XÁC THỰC QUYỀN DOMAIN ADMINS THÀNH CÔNG!</strong> Bạn đang truy cập bảng điều khiển quản trị cấp cao với tài khoản <code>{{ current_user.user }}</code>.
        </div>
        <div class="row g-3">
            <div class="col-md-4">
                <div class="border rounded-3 p-3 bg-light h-100">
                    <div class="fw-bold text-primary mb-1">Quản lý Máy chủ Miền (LDAP)</div>
                    <div class="small text-secondary">Máy chủ: <code>172.20.0.10:389</code><br>Miền gốc: <code>dc=enterprise,dc=corp</code></div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="border rounded-3 p-3 bg-light h-100">
                    <div class="fw-bold text-primary mb-1">Khóa Bảo mật &amp; Chứng chỉ</div>
                    <div class="small text-secondary">Mã quản trị: <code>CORP-DOMAIN-ADMIN-KEY-2026</code><br>Chứng chỉ: <code>RSA-SHA256 Active</code></div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="border rounded-3 p-3 bg-light h-100">
                    <div class="fw-bold text-primary mb-1">Giám sát An ninh (SIEM)</div>
                    <div class="small text-secondary">Máy chủ Wazuh: <code>172.20.0.100</code><br>Chế độ: <code>Active Response Enabled</code></div>
                </div>
            </div>
        </div>
        {% else %}
        <div class="alert alert-warning mb-0">
            <strong>🔒 403 Forbidden - Từ chối truy cập:</strong> Tài khoản <code>{{ current_user.user }}</code> (Nhóm quyền: <code>{{ current_user.role }}</code>) không có quyền truy cập khu vực Quản trị Hệ thống! Khu vực này chỉ dành cho nhóm <code>DomainAdmins</code>.
        </div>
        {% endif %}
    </div>
    {% endif %}

    {% else %}
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="card-light p-5 text-center my-4">
                <div class="fs-1 mb-2">🏢</div>
                <h3 class="fw-bold mb-2">Cổng Thông Tin Nội Bộ Doanh Nghiệp</h3>
                <p class="text-secondary mb-4">
                    Vui lòng đăng nhập qua cổng xác thực tập trung SAML 2.0 SSO để truy cập hệ thống làm việc.
                </p>
                <a href="{{ idp_url }}" class="btn btn-primary px-4 py-2 fw-semibold">
                    Đăng nhập qua SAML SSO
                </a>
            </div>
        </div>
    </div>
    {% endif %}
</main>

<footer class="py-3 text-center text-secondary small">
    <div class="container">
        Enterprise Workspace Portal (172.20.0.20) | Hệ thống Cổng thông tin Nội bộ Doanh nghiệp
    </div>
</footer>
</body>
</html>"""

@app.route('/')
@app.route('/login')
def index():
    tab = request.args.get('tab', 'dashboard')
    if session.get('logged_out'):
        current_user = None
    else:
        current_user = load_shared_session()
    return render_template_string(
        PORTAL_HTML,
        current_user=current_user,
        tab=tab,
        employees=EMPLOYEES,
        idp_url=IDP_SAML_URL
    ), 200

@app.route('/logout')
def logout():
    session['logged_out'] = True
    clear_shared_session()
    return redirect('/login')

@app.route('/saml/acs', methods=['GET', 'POST'])
def saml_acs():
    src_ip = request.headers.get('X-Forwarded-For', request.remote_addr)
    now_iso = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
    strict_mode = check_strict_validator()

    if request.method == 'GET' and not request.args.get('SAMLResponse'):
        verify_schema = request.args.get('verify_schema', 'strict_single_assertion')
        if strict_mode:
            write_audit_log(f"[XML_PARSER_PROBE_SUCCESS] [XML_PARSER_PATCHED] srcip={src_ip} verify_schema={verify_schema} status=strict_reference_id_enforced")
            return jsonify({
                "service": "sp-app",
                "endpoint": "/saml/acs",
                "verify_schema": verify_schema,
                "parser_mode": "strict_reference_id_enforced",
                "reference_id_validation": "enforced",
                "status": "SAFE"
            }), 200
        else:
            write_audit_log(f"[XML_PARSER_PROBE_SUCCESS] srcip={src_ip} verify_schema={verify_schema} status=multiple_assertions_allowed")
            return jsonify({
                "service": "sp-app",
                "endpoint": "/saml/acs",
                "verify_schema": verify_schema,
                "parser_mode": "multiple_assertions_allowed",
                "reference_id_validation": "disabled",
                "status": "WARNING_MULTIPLE_ASSERTIONS_ALLOWED"
            }), 200

    test_mode = request.form.get('test_mode', '')
    signed_subject = request.form.get('signed_subject', 'student')
    secondary_subject = request.form.get('secondary_subject', '')
    secondary_role = request.form.get('secondary_role', '')
    b64_saml = request.args.get('SAMLResponse') or request.form.get('SAMLResponse', '')

    if b64_saml and not secondary_subject:
        try:
            xml_bytes = base64.b64decode(b64_saml)
            root = etree.fromstring(xml_bytes)
            ns = {'saml': 'urn:oasis:names:tc:SAML:2.0:assertion'}
            assertions = root.xpath('//saml:Assertion', namespaces=ns)
            if len(assertions) >= 1:
                nid1 = assertions[0].xpath('.//saml:Subject/saml:NameID', namespaces=ns)
                if nid1 and nid1[0].text:
                    signed_subject = nid1[0].text.strip()
            if len(assertions) > 1:
                test_mode = 'multi_assertion_check'
                nid2 = assertions[-1].xpath('.//saml:Subject/saml:NameID', namespaces=ns)
                role2 = assertions[-1].xpath('.//saml:Attribute[@Name="Role"]/saml:AttributeValue', namespaces=ns)
                secondary_subject = nid2[0].text.strip() if (nid2 and nid2[0].text) else 'ldap-admin'
                secondary_role = role2[0].text.strip() if (role2 and role2[0].text) else 'DomainAdmins'
        except Exception:
            pass

    if test_mode or secondary_subject or secondary_role:
        sec_subj = secondary_subject or 'ldap-admin'
        sec_role = secondary_role or 'DomainAdmins'

        write_audit_log(
            f"[XML_INTEGRITY_TEST_EXECUTED] srcip={src_ip} test_mode={test_mode} signed_subject={signed_subject} secondary_subject={sec_subj} secondary_role={sec_role} strict_mode={strict_mode}"
        )
        write_json_log({
            "timestamp": now_iso,
            "srcip": src_ip,
            "service": "sp-app",
            "endpoint": "/saml/acs",
            "signed_subject": signed_subject,
            "secondary_subject": sec_subj,
            "secondary_role": sec_role,
            "event_type": "XMLSignatureMismatch|MultipleAssertionsDetected|ReferenceIDMismatch",
            "message": f"Critical SAML 2.0 Alert: MultipleAssertionsDetected and ReferenceIDMismatch (signed_subject={signed_subject}, secondary_subject={sec_subj}, secondary_role={sec_role})"
        })

        if strict_mode:
            return jsonify({
                "status": "REJECTED",
                "error": "ReferenceIDMismatch: MultipleAssertionsDetected blocked by strict XML validator",
                "signed_subject": signed_subject
            }), 403

        profile = USER_PROFILES.get(sec_subj, {
            "name": "Phạm Minh Admin",
            "dept": "Quản trị Hệ thống & Bảo mật",
            "email": f"{sec_subj}@enterprise.corp"
        })
        user_state = {
            "user": sec_subj,
            "name": profile["name"],
            "role": sec_role,
            "dept": profile["dept"],
            "email": profile["email"]
        }
        session.pop('logged_out', None)
        save_shared_session(user_state)
        return jsonify({
            "status": "ACCEPTED_SECONDARY_ASSERTION",
            "active_user": sec_subj,
            "granted_role": sec_role,
            "signed_subject": signed_subject,
            "assertion_blocks": 2
        }), 200

    profile = USER_PROFILES.get(signed_subject, USER_PROFILES['student'])
    user_state = {
        "user": signed_subject,
        "name": profile["name"],
        "role": profile["role"],
        "dept": profile["dept"],
        "email": profile["email"]
    }
    session.pop('logged_out', None)
    save_shared_session(user_state)
    write_audit_log(f"[SAML_SSO_LOGIN] srcip={src_ip} user={signed_subject} role={user_state['role']}")
    return redirect('/')

if __name__ == '__main__':
    threading.Thread(target=lambda: app.run(host='0.0.0.0', port=5000, use_reloader=False), daemon=True).start()
    app.run(host='0.0.0.0', port=80, use_reloader=False)
