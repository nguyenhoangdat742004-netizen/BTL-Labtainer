#!/usr/bin/env python3
"""
Wazuh Agent & Active Response Bridge on sp-app (172.20.0.20)
Forwards JSON logs from /var/log/sp-portal/app.json to wazuh-manager (172.20.0.100:514)
and executes firewall-drop (iptables) when Rule 100602 is active on wazuh-manager.
"""
import os
import time
import socket
import subprocess

APP_JSON_LOG = "/var/log/sp-portal/app.json"
AR_LOG = "/var/ossec/logs/active-responses.log"
AR_SCRIPT = "/var/ossec/active-response/bin/firewall-drop"
MANAGER_IP = "172.20.0.100"

def is_ar_already_triggered():
    if not os.path.exists(AR_LOG):
        return False
    try:
        with open(AR_LOG, 'r') as f:
            return "firewall-drop" in f.read()
    except Exception:
        return False

def trigger_active_response(attacker_ip="172.20.0.20", rule_id="100602"):
    try:
        cmd = [AR_SCRIPT, "add", "-", attacker_ip, str(int(time.time())), rule_id]
        subprocess.run(cmd, check=False)
    except Exception:
        pass

def forward_log_to_manager(json_line):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(json_line.encode('utf-8'), (MANAGER_IP, 514))
        sock.close()
    except Exception:
        pass

def check_rule_on_manager():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(2.0)
        s.connect((MANAGER_IP, 5515))
        s.sendall(b"CHECK_RULE\n")
        resp = s.recv(1024).decode('utf-8').strip()
        s.close()
        if resp.startswith("RULE_ACTIVE"):
            parts = resp.split(":")
            rule_id = parts[1] if len(parts) > 1 else "100602"
            return True, rule_id
    except Exception:
        pass
    return False, "100602"

def main():
    udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_sock.bind(("0.0.0.0", 5514))
    udp_sock.setblocking(False)

    last_pos = 0
    if os.path.exists(APP_JSON_LOG):
        last_pos = os.path.getsize(APP_JSON_LOG)

    last_rule_poll = 0.0

    while True:
        try:
            try:
                data, _ = udp_sock.recvfrom(2048)
                msg = data.decode('utf-8', errors='ignore').strip()
                if msg.startswith("BLOCK"):
                    parts = msg.split()
                    ip = parts[1] if len(parts) > 1 else "172.20.0.20"
                    rule = parts[2] if len(parts) > 2 else "100602"
                    trigger_active_response(ip, rule)
            except BlockingIOError:
                pass

            if os.path.exists(APP_JSON_LOG):
                curr_size = os.path.getsize(APP_JSON_LOG)
                if curr_size > last_pos:
                    with open(APP_JSON_LOG, 'r') as f:
                        f.seek(last_pos)
                        new_lines = f.readlines()
                        last_pos = f.tell()
                    for line in new_lines:
                        line_str = line.strip()
                        if line_str:
                            forward_log_to_manager(line_str)
                            if any(k in line_str for k in ['XMLSignatureMismatch', 'MultipleAssertionsDetected', 'ReferenceIDMismatch']):
                                active, r_id = check_rule_on_manager()
                                if active:
                                    time.sleep(0.3)
                                    trigger_active_response("172.20.0.20", r_id)

                # If an attack was already logged in Step 2 and the student just enabled Rule 100602 in Step 3:
                now = time.time()
                if curr_size > 0 and not is_ar_already_triggered() and (now - last_rule_poll) >= 2.0:
                    last_rule_poll = now
                    with open(APP_JSON_LOG, 'r') as f:
                        all_lines = [l.strip() for l in f.readlines() if l.strip()]
                    attack_lines = [
                        l for l in all_lines
                        if any(k in l for k in ['XMLSignatureMismatch', 'MultipleAssertionsDetected', 'ReferenceIDMismatch'])
                    ]
                    if attack_lines:
                        active, r_id = check_rule_on_manager()
                        if active:
                            forward_log_to_manager(attack_lines[-1])
                            time.sleep(0.3)
                            trigger_active_response("172.20.0.20", r_id)
        except Exception:
            pass
        time.sleep(0.5)

if __name__ == '__main__':
    main()
