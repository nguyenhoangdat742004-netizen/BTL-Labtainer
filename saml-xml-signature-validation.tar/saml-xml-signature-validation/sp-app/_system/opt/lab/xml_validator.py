#!/usr/bin/env python3
"""
Module Cấu hình & Xác thực Cấu trúc Chữ ký XML (/opt/lab/xml_validator.py)
Học viên có thể dùng lệnh `labedit /opt/lab/xml_validator.py` hoặc `nano /opt/lab/xml_validator.py`
để chỉnh sửa trực tiếp logic kiểm tra chữ ký XML trên SP-App.
"""

# [HỌC VIÊN CÓ THỂ SỬA ĐỔI CẤU HÌNH VÁ LỖI (PATCH/FIX) TẠI ĐÂY]
# Khi STRICT_SINGLE_ASSERTION = False: SP-App cho phép gói tin SAML chứa nhiều khối <saml:Assertion>
# và lấy thông tin định danh từ khối Assertion phụ (lỗ hổng XML Signature Wrapping).
# Đổi thành True để bắt buộc chỉ chấp nhận duy nhất 1 khối <saml:Assertion> đã ký số.
STRICT_SINGLE_ASSERTION = False

# Khi ENFORCE_REFERENCE_ID = False: SP-App không đối chiếu thuộc tính ID của <saml:Assertion>
# với giá trị <ds:Reference URI="#..."> trong chữ ký XML.
# Đổi thành True để bắt buộc khớp tuyệt đối Reference ID.
ENFORCE_REFERENCE_ID = False


def is_strict_mode_enabled():
    return bool(STRICT_SINGLE_ASSERTION or ENFORCE_REFERENCE_ID)
