#!/bin/bash
# fixlocal.sh for sp-app (172.20.0.20)
grep -q "ldap-idp" /etc/hosts 2>/dev/null || echo "172.20.0.10 ldap-idp idp.lab ldap.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "sp-app" /etc/hosts 2>/dev/null || echo "172.20.0.20 sp-app sp.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "wazuh-manager" /etc/hosts 2>/dev/null || echo "172.20.0.100 wazuh-manager wazuh.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1

sudo mkdir -p /tmp/.X11-unix
if [ -d /var/tmp/.X11-unix ]; then
    for sock in /var/tmp/.X11-unix/*; do
        if [ -e "$sock" ]; then
            base=$(basename "$sock")
            sudo ln -sf "$sock" "/tmp/.X11-unix/$base" 2>/dev/null || true
        fi
    done
fi
sudo chmod 1777 /tmp/.X11-unix 2>/dev/null || true

mkdir -p /home/ubuntu/Desktop
ln -sf /opt/lab/check_saml_parser.py /home/ubuntu/check_saml_parser.py 2>/dev/null || true
ln -sf /opt/lab/verify_xml_integrity.py /home/ubuntu/verify_xml_integrity.py 2>/dev/null || true
ln -sf /opt/lab/xml_validator.py /home/ubuntu/xml_validator.py 2>/dev/null || true
ln -sf /opt/lab /home/ubuntu/lab 2>/dev/null || true
ln -sf /opt/lab/check_saml_parser.py /home/ubuntu/Desktop/check_saml_parser.py 2>/dev/null || true
ln -sf /opt/lab/verify_xml_integrity.py /home/ubuntu/Desktop/verify_xml_integrity.py 2>/dev/null || true

sudo chown -R ubuntu:ubuntu /home/ubuntu /opt/lab 2>/dev/null || true
sudo chmod -R 777 /opt/lab 2>/dev/null || true
sudo chmod +x /opt/lab/*.py /usr/local/bin/labedit /var/ossec/active-response/bin/firewall-drop /etc/rc.local 2>/dev/null || true
sudo /etc/rc.local
echo "[OK] sp-app (172.20.0.20) đã sẵn sàng! Các script thực hành nằm tại /opt/lab/ (có thể sửa bằng lệnh labedit hoặc nano)."
