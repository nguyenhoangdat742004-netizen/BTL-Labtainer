# Labtainers: Kiểm thử và Vá lỗi Cấu trúc Chữ ký XML (XML Signature Validation) trong SSO SAML 2.0 (`saml-xml-signature-validation`)

## 1. Tổng quan Kiến trúc & Sơ đồ Mạng (Tối giản 3 Container - `172.20.0.0/24`)
- **`ldap-idp` (`172.20.0.10`)**: Chạy dịch vụ OpenLDAP tích hợp OpenID/SAML 2.0 IdP cơ bản (Giao diện nền sáng **Light Theme**), lưu trữ tài khoản `student` (nhóm `User`) và `ldap-admin` (nhóm `DomainAdmins`).
- **`sp-app` (`172.20.0.20`)**: Ứng dụng Web Service Provider (Flask, giao diện nền sáng **Light Theme**), nhận gói SAML Response tại `http://172.20.0.20/saml/acs`. Chứa các file script Python tại thư mục `/opt/lab/` để học viên trực tiếp chỉnh sửa logic kiểm tra (`labedit` hoặc `nano`).
- **`wazuh-manager` (`172.20.0.100`)**: Thu thập log JSON, phân tích cảnh báo và thực thi Active Response (`firewall-drop`). Chứa file `/var/ossec/etc/rules/local_rules.xml` (ban đầu chưa cấu hình Rule `100602`, có mẫu tại `/home/ubuntu/rule_mau.txt`) và `/var/ossec/etc/ossec.conf`.

## 2. Các Tệp Mã nguồn & Cấu hình Dễ Truy Cập
- Trên **`sp-app` (`172.20.0.20`)**:
  - `/opt/lab/check_saml_parser.py`: Script kiểm tra cấu hình trình phân tích XML trên SP-App.
  - `/opt/lab/verify_xml_integrity.py`: Script mô phỏng kiểm thử gói tin SAML đa khối Assertion (`multi_assertion_check`).
  - `/opt/lab/xml_validator.py`: Module xác thực chữ ký XML & Reference ID (học viên có thể sửa `STRICT_SINGLE_ASSERTION = True` và `ENFORCE_REFERENCE_ID = True` để vá lỗi).
  - `/opt/lab/sp_app.py`: Mã nguồn ứng dụng Flask SP-App (Light Theme).
- Trên **`wazuh-manager` (`172.20.0.100`)**:
  - `/home/ubuntu/rule_mau.txt`: File mẫu Rule `100602` để học viên tham khảo/dán vào `local_rules.xml`.
  - `/var/ossec/etc/rules/local_rules.xml`: Cấu hình Wazuh Rule `100602` (level 12).
  - `/var/ossec/etc/ossec.conf`: Cấu hình Active Response `firewall-drop` (timeout 600s).

## 3. 5 Tiêu chí Đánh giá (`checkwork`)
| Mục tiêu (`goals.config`) | Biến kết quả (`results.config`) | Tệp kiểm tra | Ý nghĩa |
| :--- | :--- | :--- | :--- |
| `1_xml_parser_probed` | `_xml_parser_probed` | `sp-app:/var/log/sp-portal/audit.log` | Thực thi `/opt/lab/check_saml_parser.py` kiểm tra cấu hình trình phân tích XML. |
| `2_xml_integrity_tested` | `_xml_integrity_tested` | `sp-app:/var/log/sp-portal/app.json` | Thực thi `/opt/lab/verify_xml_integrity.py` kiểm thử gói tin đa khối Assertion (`MultipleAssertionsDetected`). |
| `3_wazuh_rule_configured` | `_wazuh_rule` | `wazuh-manager:/var/ossec/etc/rules/local_rules.xml` | Cấu hình Rule `100602` trong `/var/ossec/etc/rules/local_rules.xml`. |
| `4_active_response_triggered` | `_active_response` | `sp-app:/var/ossec/logs/active-responses.log` | Kích hoạt Active Response (`firewall-drop`) trên `sp-app`. |
| `5_siem_alert_logged` | `_siem_alert` | `wazuh-manager:/var/ossec/logs/alerts/alerts.log` | Ghi nhận cảnh báo Rule `100602` trong `/var/ossec/logs/alerts/alerts.log`. |

Xem hướng dẫn chi tiết từng bước tại [docs/INSTRUCTIONS.md](docs/INSTRUCTIONS.md).
