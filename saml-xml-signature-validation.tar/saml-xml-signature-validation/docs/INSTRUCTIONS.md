# HƯỚNG DẪN THỰC HÀNH: KIỂM THỬ VÀ PHÒNG THỦ LỖI XÁC THỰC CHỮ KÝ XML (XML SIGNATURE VALIDATION) TRONG SSO SAML 2.0 (`saml-xml-signature-validation`)

---

## 1. TỔNG QUAN KIẾN TRÚC & SƠ ĐỒ MẠNG (`172.20.0.0/24`)

Mô hình bài thực hành gồm **03 container**:

1. **`ldap-idp` (`172.20.0.10`)**:
   - Chạy dịch vụ **OpenLDAP** tích hợp cổng đăng nhập tập trung **SAML 2.0 Single Sign-On** tại `http://172.20.0.10/sso/saml`.
   - Lưu trữ tài khoản nhân viên `student` (nhóm `User`) và quản trị viên `ldap-admin` (nhóm `DomainAdmins`).
2. **`sp-app` (`172.20.0.20`)**:
   - Cổng thông tin nội bộ doanh nghiệp **Enterprise Workspace Portal** tại `http://172.20.0.20`, nhận gói SAML Response qua endpoint `http://172.20.0.20/saml/acs`.
   - Chứa các file script Python tại thư mục `/opt/lab/`.
3. **`wazuh-manager` (`172.20.0.100`)**:
   - Máy chủ SIEM thu thập nhật ký, phân tích cảnh báo và kích hoạt Active Response (`firewall-drop` chặn IP qua `iptables`).
   - Chứa file `/var/ossec/etc/rules/local_rules.xml` và mẫu Rule tại `/home/ubuntu/rule_mau.txt`.

---

## 2. CÁC BƯỚC THỰC HÀNH CHI TIẾT

### BƯỚC 1: QUAN SÁT TRANG WEB BÌNH THƯỜNG & DÒ CẤU HÌNH XML PARSER (`1_xml_parser_probed`)

Khởi động bài lab từ máy Host:

```bash
labtainer saml-xml-signature-validation
```

Tại cửa sổ terminal của **`sp-app` (`172.20.0.20`)**, mở trình duyệt Firefox để xem trang Cổng thông tin nội bộ doanh nghiệp:

```bash
firefox http://172.20.0.20 &
```

- Bạn sẽ thấy trang web đang đăng nhập với tài khoản nhân viên **`Nguyễn Văn Student` (`User`)**.
- Khi bấm sang tab **Quản trị Hệ thống (Admin Console)**, hệ thống báo **`403 Forbidden - Từ chối truy cập`** vì chỉ nhóm `DomainAdmins` mới được phép vào.

Tiếp theo, kiểm tra và chạy script dò cấu hình trình phân tích XML trên `sp-app`:

```bash
python3 /opt/lab/check_saml_parser.py
```

**Kết quả:** Hiển thị `[+] [CẢNH BÁO]: SP-App chưa chặn cấu hình đa khối Assertion.` *(Hoàn thành tiêu chí 1: `1_xml_parser_probed`)*.

---

### BƯỚC 2: KHAI THÁC LỖ HỔNG ĐA KHỐI ASSERTION CHIẾM QUYỀN QUẢN TRỊ (`2_xml_integrity_tested`)

Trên terminal của **`sp-app` (`172.20.0.20`)**, thực thi script gửi gói tin SAML đính kèm khối Assertion phụ (`ldap-admin` - `DomainAdmins`):

```bash
python3 /opt/lab/verify_xml_integrity.py
```

**Kết quả:** Hiển thị `[+] Ghi nhận: SP-App phản hồi dữ liệu khối Assertion phụ thành công.` *(Hoàn thành tiêu chí 2: `2_xml_integrity_tested`)*.

Quay lại cửa sổ trình duyệt **Firefox** (`http://172.20.0.20`) và bấm **F5 (Tải lại trang)**:
- Giao diện trang web lập tức chuyển sang tài khoản **`Phạm Minh Admin` (`QUẢN TRỊ VIÊN HỆ THỐNG - DOMAIN ADMINS`)**!
- Bấm vào tab **Quản trị Hệ thống (Admin Console)**: Bạn đã truy cập được toàn bộ bảng điều khiển quản trị cấp cao của doanh nghiệp!

---

### BƯỚC 3: CẤU HÌNH RULE PHÒNG THỦ TRÊN WAZUH SIEM (`3_wazuh_rule_configured`)

Chuyển sang cửa sổ terminal của **`wazuh-manager` (`172.20.0.100`)**:

1. Xem đoạn mẫu Rule `100602` đã được chuẩn bị sẵn:

   ```bash
   cat ~/rule_mau.txt
   ```

2. Mở tệp `/var/ossec/etc/rules/local_rules.xml`:

   ```bash
   labedit /var/ossec/etc/rules/local_rules.xml
   ```

   Dán nội dung Rule `100602` vào trong tệp:

   ```xml
   <group name="sso,saml,ldap,">
     <rule id="100602" level="12">
       <decoded_as>json</decoded_as>
       <match>XMLSignatureMismatch|MultipleAssertionsDetected|ReferenceIDMismatch</match>
       <description>Critical SAML 2.0 Alert: Unverified XML Assertion Block or Reference ID Mismatch Detected</description>
       <group>xml_validation,identity_verification,</group>
     </rule>
   </group>
   ```

3. Khởi động lại dịch vụ Wazuh Manager để áp dụng Rule:

   ```bash
   sudo systemctl restart wazuh-manager
   ```

   *(Hoàn thành tiêu chí 3: `3_wazuh_rule_configured`)*.

---

### BƯỚC 4: XÁC MINH ACTIVE RESPONSE CHẶN TRUY CẬP WEB & KIỂM TRA LOG SIEM (`4_active_response_triggered` & `5_siem_alert_logged`)

Ngay khi Rule `100602` được áp dụng, Wazuh phát hiện sự kiện giả mạo cấu trúc Assertion và kích hoạt **Active Response (`firewall-drop`)**, thực thi lệnh `iptables` chặn truy cập cổng Web (`http://172.20.0.20`).

1. **Kiểm tra trên `sp-app` (`172.20.0.20`)**:
   - Mở lại trình duyệt hoặc bấm **F5** trên cửa sổ Firefox:
     ```bash
     firefox http://172.20.0.20 &
     ```
     **Kết quả:** Trình duyệt báo **`Unable to connect` (Không thể kết nối đến máy chủ tại `172.20.0.20`)** — trang web đã bị tường lửa chặn hoàn toàn!
   - Nếu chạy lại script `python3 /opt/lab/verify_xml_integrity.py`, kết nối cũng bị từ chối ngay lập tức (`Connection refused`).
   *(Hoàn thành tiêu chí 4: `4_active_response_triggered`)*.

2. **Kiểm tra nhật ký cảnh báo trên `wazuh-manager` (`172.20.0.100`)**:
   ```bash
   cat /var/ossec/logs/alerts/alerts.log
   cat /var/ossec/logs/active-responses.log
   ```
   *(Hoàn thành tiêu chí 5: `5_siem_alert_logged`)*.

---

## 3. KIỂM TRA KẾT QUẢ TỰ ĐỘNG (`checkwork`)

Tại terminal trên máy Host, gõ lệnh:

```bash
checkwork
```

Kết quả đạt đủ 5/5 tiêu chí (`Y`):

```text
Labname saml-xml-signature-validation

Student: <email>
 Y -  1_xml_parser_probed
 Y -  2_xml_integrity_tested
 Y -  3_wazuh_rule_configured
 Y -  4_active_response_triggered
 Y -  5_siem_alert_logged
```
