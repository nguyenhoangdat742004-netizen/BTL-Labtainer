#!/bin/bash
# fixlocal.sh for wazuh-manager (172.20.0.100)
grep -q "ldap-idp" /etc/hosts 2>/dev/null || echo "172.20.0.10 ldap-idp idp.lab ldap.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "sp-app" /etc/hosts 2>/dev/null || echo "172.20.0.20 sp-app sp.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "wazuh-manager" /etc/hosts 2>/dev/null || echo "172.20.0.100 wazuh-manager wazuh.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1

mkdir -p /home/ubuntu/Desktop /opt/lab
ln -sf /var/ossec/etc/rules/local_rules.xml /home/ubuntu/local_rules.xml 2>/dev/null || true
ln -sf /var/ossec/etc/ossec.conf /home/ubuntu/ossec.conf 2>/dev/null || true
ln -sf /var/ossec/etc/rules/local_rules.xml /opt/lab/local_rules.xml 2>/dev/null || true
ln -sf /var/ossec/etc/ossec.conf /opt/lab/ossec.conf 2>/dev/null || true

cat << 'EOF_RULE' > /home/ubuntu/rule_mau.txt
<group name="sso,saml,ldap,">
  <rule id="100602" level="12">
    <decoded_as>json</decoded_as>
    <match>XMLSignatureMismatch|MultipleAssertionsDetected|ReferenceIDMismatch</match>
    <description>Critical SAML 2.0 Alert: Unverified XML Assertion Block or Reference ID Mismatch Detected</description>
    <group>xml_validation,identity_verification,</group>
  </rule>
</group>
EOF_RULE
cp -f /home/ubuntu/rule_mau.txt /home/ubuntu/Desktop/rule_mau.txt
cp -f /home/ubuntu/rule_mau.txt /opt/lab/rule_mau.txt

cat << 'EOF_GUIDE' > /home/ubuntu/Desktop/HUONG_DAN_WAZUH.txt
================================================================================
HƯỚNG DẪN TRÊN WAZUH-MANAGER (172.20.0.100)
================================================================================
1. Xem mẫu Rule chuẩn bị sẵn:
   cat ~/rule_mau.txt

2. Mở tệp /var/ossec/etc/rules/local_rules.xml để dán/cấu hình Rule 100602:
   labedit /var/ossec/etc/rules/local_rules.xml
   (hoặc: sudo nano /var/ossec/etc/rules/local_rules.xml)

3. Kiểm tra cấu hình Active Response (firewall-drop):
   labedit /var/ossec/etc/ossec.conf
   (hoặc: sudo nano /var/ossec/etc/ossec.conf)

4. Khởi động lại dịch vụ Wazuh Manager để áp dụng Rule:
   sudo systemctl restart wazuh-manager
   (hoặc: sudo /var/ossec/bin/wazuh-control restart)

5. Kiểm tra nhật ký cảnh báo & Active Response:
   cat /var/ossec/logs/alerts/alerts.log
   cat /var/ossec/logs/active-responses.log
================================================================================
EOF_GUIDE

sudo chown -R ubuntu:ubuntu /home/ubuntu /opt/lab 2>/dev/null || true
sudo chmod 666 /var/ossec/etc/rules/local_rules.xml /var/ossec/etc/ossec.conf 2>/dev/null || true
sudo chmod +x /var/ossec/bin/wazuh-control /var/ossec/bin/wazuh-logtest /var/ossec/active-response/bin/firewall-drop /usr/local/bin/wazuh_manager_daemon.py /usr/local/bin/labedit /etc/rc.local 2>/dev/null || true
sudo /etc/rc.local
echo "[OK] Máy chủ wazuh-manager (172.20.0.100) đã sẵn sàng! Xem ~/rule_mau.txt và cấu hình /var/ossec/etc/rules/local_rules.xml."
