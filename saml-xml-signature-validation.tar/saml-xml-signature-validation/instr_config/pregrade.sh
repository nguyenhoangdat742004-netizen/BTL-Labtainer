#!/bin/bash
# Pregrade script for saml-xml-signature-validation
homedir=$1
destdir=$2
cd $homedir/$destdir 2>/dev/null || true
