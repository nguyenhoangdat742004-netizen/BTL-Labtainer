#!/bin/bash
# fixlocal.sh for ldap-idp (172.20.0.10)
grep -q "ldap-idp" /etc/hosts 2>/dev/null || echo "172.20.0.10 ldap-idp idp.lab ldap.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "sp-app" /etc/hosts 2>/dev/null || echo "172.20.0.20 sp-app sp.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "wazuh-manager" /etc/hosts 2>/dev/null || echo "172.20.0.100 wazuh-manager wazuh.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1

sudo chmod +x /opt/ldap-idp/app.py /opt/lab/*.py /usr/local/bin/labedit /etc/rc.local 2>/dev/null || true
sudo /etc/rc.local
echo "[OK] ldap-idp (172.20.0.10) started OpenLDAP (:389) and SAML 2.0 IdP (:80, Light Theme)."
