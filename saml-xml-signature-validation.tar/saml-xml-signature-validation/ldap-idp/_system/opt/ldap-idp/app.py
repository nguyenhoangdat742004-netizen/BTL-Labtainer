#!/usr/bin/env python3
"""
OpenLDAP Directory & SAML 2.0 Single Sign-On Identity Provider (ldap-idp: 172.20.0.10)
Lab: saml-xml-signature-validation (Light Theme)
"""
import os
import uuid
import base64
import socket
import urllib.parse
import threading
import datetime
from flask import Flask, request, redirect, render_template_string, jsonify, Response
from lxml import etree

from cryptography.hazmat.primitives.asymmetric import ec
for curve in ['SECT163K1', 'SECT233K1', 'SECT233R1', 'SECT283R1', 'SECT409K1', 'SECT409R1', 'SECT571K1', 'SECP192R1', 'SECP224R1']:
    if not hasattr(ec, curve):
        setattr(ec, curve, ec.SECP256R1)

import signxml

app = Flask(__name__)
app.secret_key = 'LDAP_IDP_SAML_XML_SIGNATURE_2026'

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
KEY_FILE = os.path.join(BASE_DIR, 'keys', 'idp_private.key')
CERT_FILE = os.path.join(BASE_DIR, 'keys', 'idp_cert.crt')
SP_ACS_URL = 'http://172.20.0.20/saml/acs'

LDAP_USERS = {
    'student': {
        'uid': 'student',
        'cn': 'Nguyễn Văn Student',
        'password': 'student123',
        'dn': 'uid=student,ou=Users,dc=enterprise,dc=corp',
        'group': 'User',
        'email': 'student@enterprise.corp',
        'dept': 'Kỹ thuật & Vận hành'
    },
    'ldap-admin': {
        'uid': 'ldap-admin',
        'cn': 'Phạm Minh Admin',
        'password': 'Admin@LDAP2026',
        'dn': 'uid=ldap-admin,ou=DomainAdmins,dc=enterprise,dc=corp',
        'group': 'DomainAdmins',
        'email': 'ldap-admin@enterprise.corp',
        'dept': 'Quản trị Hệ thống & Bảo mật'
    }
}

def generate_signed_saml_response(username, group, email, dept, secondary_subject=None, secondary_role=None):
    now = datetime.datetime.now(datetime.timezone.utc)
    issue_instant = now.strftime('%Y-%m-%dT%H:%M:%SZ')
    not_before = (now - datetime.timedelta(minutes=5)).strftime('%Y-%m-%dT%H:%M:%SZ')
    not_on_or_after = (now + datetime.timedelta(minutes=15)).strftime('%Y-%m-%dT%H:%M:%SZ')

    response_id = f"ID_RESP_{uuid.uuid4().hex[:12]}"
    assertion_id = f"ID_ASSERT_SIGNED_{uuid.uuid4().hex[:12]}"

    assertion_xml = f"""<saml:Assertion xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion"
                    ID="{assertion_id}"
                    Version="2.0"
                    IssueInstant="{issue_instant}">
        <saml:Issuer>http://172.20.0.10/sso/saml</saml:Issuer>
        <saml:Subject>
            <saml:NameID Format="urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified">{username}</saml:NameID>
            <saml:SubjectConfirmation Method="urn:oasis:names:tc:SAML:2.0:cm:bearer">
                <saml:SubjectConfirmationData NotOnOrAfter="{not_on_or_after}"
                                              Recipient="{SP_ACS_URL}"/>
            </saml:SubjectConfirmation>
        </saml:Subject>
        <saml:Conditions NotBefore="{not_before}" NotOnOrAfter="{not_on_or_after}">
            <saml:AudienceRestriction>
                <saml:Audience>http://172.20.0.20/saml/metadata</saml:Audience>
            </saml:AudienceRestriction>
        </saml:Conditions>
        <saml:AuthnStatement AuthnInstant="{issue_instant}">
            <saml:AuthnContext>
                <saml:AuthnContextClassRef>urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport</saml:AuthnContextClassRef>
            </saml:AuthnContext>
        </saml:AuthnStatement>
        <saml:AttributeStatement>
            <saml:Attribute Name="Role">
                <saml:AttributeValue>{group}</saml:AttributeValue>
            </saml:Attribute>
            <saml:Attribute Name="Email">
                <saml:AttributeValue>{email}</saml:AttributeValue>
            </saml:Attribute>
            <saml:Attribute Name="Department">
                <saml:AttributeValue>{dept}</saml:AttributeValue>
            </saml:Attribute>
        </saml:AttributeStatement>
    </saml:Assertion>"""

    assertion_el = etree.fromstring(assertion_xml.encode('utf-8'))
    with open(KEY_FILE, 'rb') as kf, open(CERT_FILE, 'rb') as cf:
        signer = signxml.XMLSigner(
            method=signxml.methods.enveloped,
            signature_algorithm='rsa-sha256',
            digest_algorithm='sha256'
        )
        signed_assertion_el = signer.sign(assertion_el, key=kf.read(), cert=cf.read(), reference_uri=assertion_id)

    signed_assertion_str = etree.tostring(signed_assertion_el, encoding='unicode')

    secondary_block = ""
    if secondary_subject and secondary_role:
        unsigned_id = f"ID_ASSERT_UNSIGNED_{uuid.uuid4().hex[:12]}"
        secondary_block = f"""
    <saml:Assertion xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion"
                    ID="{unsigned_id}"
                    Version="2.0"
                    IssueInstant="{issue_instant}">
        <saml:Issuer>http://172.20.0.10/sso/saml</saml:Issuer>
        <saml:Subject>
            <saml:NameID Format="urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified">{secondary_subject}</saml:NameID>
        </saml:Subject>
        <saml:AttributeStatement>
            <saml:Attribute Name="Role">
                <saml:AttributeValue>{secondary_role}</saml:AttributeValue>
            </saml:Attribute>
            <saml:Attribute Name="Email">
                <saml:AttributeValue>{secondary_subject}@enterprise.corp</saml:AttributeValue>
            </saml:Attribute>
        </saml:AttributeStatement>
    </saml:Assertion>"""

    resp_xml = f"""<samlp:Response xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol"
                xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion"
                ID="{response_id}"
                Version="2.0"
                IssueInstant="{issue_instant}"
                Destination="{SP_ACS_URL}">
    <saml:Issuer>http://172.20.0.10/sso/saml</saml:Issuer>
    <samlp:Status>
        <samlp:StatusCode Value="urn:oasis:names:tc:SAML:2.0:status:Success"/>
    </samlp:Status>
    {signed_assertion_str}{secondary_block}
</samlp:Response>"""

    return base64.b64encode(resp_xml.encode('utf-8')).decode('utf-8'), assertion_id

IDP_HTML = """<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Enterprise Single Sign-On (SAML 2.0)</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; color: #0f172a; font-family: system-ui, -apple-system, sans-serif; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .idp-card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 16px; box-shadow: 0 8px 24px rgba(15,23,42,0.05); max-width: 440px; width: 100%; padding: 36px; }
    </style>
</head>
<body>
<div class="idp-card">
    <div class="text-center mb-4">
        <div class="fs-1 mb-2">🔑</div>
        <h5 class="fw-bold mb-1">Cổng Đăng Nhập Tập Trung (SSO)</h5>
        <p class="text-secondary small mb-0">Hệ thống Xác thực Doanh nghiệp (OpenLDAP &amp; SAML 2.0)</p>
    </div>
    {% if error %}
    <div class="alert alert-danger py-2 small">{{ error }}</div>
    {% endif %}
    <form method="POST" action="/sso/saml">
        <div class="mb-3">
            <label class="form-label small fw-semibold">Tài khoản nhân viên</label>
            <input type="text" name="username" class="form-control" value="student" required>
        </div>
        <div class="mb-3">
            <label class="form-label small fw-semibold">Mật khẩu</label>
            <input type="password" name="password" class="form-control" value="student123" required>
        </div>
        <button type="submit" class="btn btn-primary w-100 fw-semibold py-2">Đăng nhập</button>
    </form>
    <div class="mt-3 pt-3 border-top text-center">
        <a href="http://172.20.0.20" class="small text-decoration-none">← Quay lại Enterprise Workspace Portal</a>
    </div>
</div>
</body>
</html>"""

@app.route('/')
@app.route('/sso/saml', methods=['GET', 'POST'])
def sso_saml():
    if request.method == 'GET':
        return render_template_string(IDP_HTML)

    username = request.form.get('username', 'student').strip()
    password = request.form.get('password', '').strip()
    user_obj = LDAP_USERS.get(username)
    if not user_obj or user_obj['password'] != password:
        return render_template_string(IDP_HTML, error="Sai tài khoản hoặc mật khẩu!"), 401

    b64_saml, _ = generate_signed_saml_response(
        username=user_obj['uid'],
        group=user_obj['group'],
        email=user_obj['email'],
        dept=user_obj['dept']
    )
    encoded_saml = urllib.parse.quote(b64_saml)
    return redirect(f"{SP_ACS_URL}?SAMLResponse={encoded_saml}", code=302)

@app.route('/api/ldap/users')
def api_ldap_users():
    return jsonify({
        "ldap_host": "172.20.0.10:389",
        "base_dn": "dc=enterprise,dc=corp",
        "accounts": [
            {"uid": u["uid"], "cn": u["cn"], "group": u["group"], "dn": u["dn"], "email": u["email"], "dept": u["dept"]}
            for u in LDAP_USERS.values()
        ]
    }), 200

@app.route('/api/saml/generate', methods=['POST'])
def api_saml_generate():
    signed_subject = request.form.get('signed_subject', 'student')
    secondary_subject = request.form.get('secondary_subject')
    secondary_role = request.form.get('secondary_role')
    u = LDAP_USERS.get(signed_subject, LDAP_USERS['student'])
    b64_saml, assertion_id = generate_signed_saml_response(
        username=u['uid'],
        group=u['group'],
        email=u['email'],
        dept=u['dept'],
        secondary_subject=secondary_subject,
        secondary_role=secondary_role
    )
    return jsonify({"SAMLResponse": b64_saml, "signed_assertion_id": assertion_id}), 200

@app.route('/saml/metadata')
def saml_metadata():
    with open(CERT_FILE, 'r') as f:
        cert_pem = "".join([line.strip() for line in f if "BEGIN" not in line and "END" not in line])
    xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<EntityDescriptor xmlns="urn:oasis:names:tc:SAML:2.0:metadata" entityID="http://172.20.0.10/sso/saml">
  <IDPSSODescriptor protocolSupportEnumeration="urn:oasis:names:tc:SAML:2.0:protocol">
    <KeyDescriptor use="signing">
      <KeyInfo xmlns="http://www.w3.org/2000/09/xmldsig#">
        <X509Data><X509Certificate>{cert_pem}</X509Certificate></KeyInfo>
    </KeyDescriptor>
    <SingleSignOnService Binding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST" Location="http://172.20.0.10/sso/saml"/>
  </IDPSSODescriptor>
</EntityDescriptor>"""
    return Response(xml, mimetype='application/xml')

def ldap_tcp_listener():
    try:
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(('0.0.0.0', 389))
        srv.listen(5)
        while True:
            conn, _ = srv.accept()
            conn.close()
    except Exception:
        pass

if __name__ == '__main__':
    threading.Thread(target=ldap_tcp_listener, daemon=True).start()
    threading.Thread(target=lambda: app.run(host='0.0.0.0', port=8080, use_reloader=False), daemon=True).start()
    app.run(host='0.0.0.0', port=80, use_reloader=False)
