#!/bin/bash
echo "127.0.0.1 $(hostname)" | sudo tee -a /etc/hosts >/dev/null
# 1. Dam bao quyen so huu cho user ubuntu
sudo chown -R ubuntu:ubuntu /opt/sso-lab 2>/dev/null || true

# 2. Xoa cac file log cu tu luc build image va reset file luat WAF
sudo truncate -s 0 /var/log/apache2/flask_error.log 2>/dev/null || true
sudo truncate -s 0 /var/log/apache2/flask_access.log 2>/dev/null || true
sudo truncate -s 0 /var/log/apache2/modsec_audit.log 2>/dev/null || true
sudo truncate -s 0 /var/log/apache2/error.log 2>/dev/null || true
sudo truncate -s 0 /opt/sso-lab/employee_portal/flask.log 2>/dev/null || true
sudo chown ubuntu:ubuntu /opt/sso-lab/employee_portal/flask.log 2>/dev/null || true
sudo chmod 755 /var/log/apache2 2>/dev/null || true
sudo usermod -a -G adm ubuntu 2>/dev/null || true
sudo chmod 666 /var/log/apache2/flask_access.log /var/log/apache2/flask_error.log 2>/dev/null || true
sudo chown ubuntu:ubuntu /var/log/apache2/flask_access.log 2>/dev/null || true

# Cau hinh luat WAF phong thu SAML NameID Injection vao saml_rules.conf
sudo python3 -c '
rule = """SecRule REQUEST_URI "@rx ^/saml/acs" \\
    "id:100001,\\
    phase:2,\\
    deny,\\
    status:403,\\
    log,\\
    msg:\x27Blocked SAML admin NameID injection\x27,\\
    chain"
    SecRule REQUEST_METHOD "@streq POST" "chain"
    SecRule ARGS:SAMLResponse "@rx <(?:saml2?:|saml:)?NameID[^>]*>\\s*admin\\s*</(?:saml2?:|saml:)?NameID>" "t:base64Decode"
"""
with open("/etc/modsecurity/saml_rules.conf", "w") as f:
    f.write(rule)
'

# Dam bao SecRuleEngine o che do DetectionOnly khi moi bat dau lab
sudo sed -i 's/^SecRuleEngine On/SecRuleEngine DetectionOnly/' /etc/modsecurity/modsecurity.conf 2>/dev/null || true

# 3. Tao script khoi dong cho sinh vien
cat << 'EOF' > /home/ubuntu/start_sso.sh
#!/bin/bash
grep -q "$(hostname)" /etc/hosts 2>/dev/null || echo "127.0.0.1 $(hostname)" | sudo tee -a /etc/hosts >/dev/null 2>&1
echo "[+] Đang khởi động Keycloak và OpenLDAP..."
cd /opt/sso-lab
sudo chown -R ubuntu:ubuntu /opt/sso-lab 2>/dev/null || true
sudo docker rm -f openldap phpldapadmin keycloak 2>/dev/null || true
sudo docker-compose down 2>/dev/null || true
sudo docker-compose up -d
echo "[+] Đợi dịch vụ sẵn sàng (15s)..."
sleep 15
echo "[+] Đang khởi động Web Flask (Backend Cổng 5000)..."
sudo chmod 755 /var/log/apache2 2>/dev/null || true
sudo chmod 666 /var/log/apache2/flask_access.log /var/log/apache2/flask_error.log 2>/dev/null || true
cd /opt/sso-lab/employee_portal
sudo pkill -f "python3 app.py" 2>/dev/null || true
nohup python3 app.py >> flask.log 2>&1 &
sleep 2
echo "[+] Đang khởi động ModSecurity WAF trên Apache (Cổng 5001)..."
sudo service apache2 restart
sleep 2
echo "XONG! Chuyển sang máy student-pc, mở trình duyệt truy cập http://172.20.0.10:5001"
EOF

chmod +x /home/ubuntu/start_sso.sh
chown ubuntu:ubuntu /home/ubuntu/start_sso.sh 2>/dev/null || true

# 4. Tao script ho tro bat phong thu WAF cho sinh vien
cat << 'EOF_DEFENSE' > /home/ubuntu/enable_defense.sh
#!/bin/bash
# Script ho tro bat ModSecurity va nap luat phong thu SAML NameID Injection

echo "[+] 1. Kich hoat SecRuleEngine On trong /etc/modsecurity/modsecurity.conf..."
sudo sed -i "s/^SecRuleEngine DetectionOnly/SecRuleEngine On/" /etc/modsecurity/modsecurity.conf

echo "[+] 2. Cap nhat luat WAF vao /etc/modsecurity/saml_rules.conf..."
sudo python3 -c '
rule = """SecRule REQUEST_URI "@rx ^/saml/acs" \\
    "id:100001,\\
    phase:2,\\
    deny,\\
    status:403,\\
    log,\\
    msg:\x27Blocked SAML admin NameID injection\x27,\\
    chain"
    SecRule REQUEST_METHOD "@streq POST" "chain"
    SecRule ARGS:SAMLResponse "@rx <(?:saml2?:|saml:)?NameID[^>]*>\\s*admin\\s*</(?:saml2?:|saml:)?NameID>" "t:base64Decode"
"""
with open("/etc/modsecurity/saml_rules.conf", "w") as f:
    f.write(rule)
'

echo "[+] 3. Kiem tra va khoi dong lai Apache Web Server..."
sudo apachectl configtest && sudo service apache2 restart

echo "[+] XONG! ModSecurity da duoc bat o che do Blocking va da nap luat chan SAML Admin Injection."
EOF_DEFENSE

chmod +x /home/ubuntu/enable_defense.sh
chown ubuntu:ubuntu /home/ubuntu/enable_defense.sh 2>/dev/null || true

# 5. Tu dong chay start_sso.sh khi container khoi dong
/home/ubuntu/start_sso.sh > /home/ubuntu/autostart.log 2>&1 &
