#!/bin/bash
grep -q "$(hostname)" /etc/hosts 2>/dev/null || echo "127.0.0.1 $(hostname)" | sudo tee -a /etc/hosts >/dev/null 2>&1
echo "[+] Đang khởi động Keycloak và OpenLDAP..."
cd /opt/sso-lab
sudo chown -R ubuntu:ubuntu /opt/sso-lab 2>/dev/null || true
sudo docker rm -f openldap phpldapadmin keycloak 2>/dev/null || true
sudo docker-compose down 2>/dev/null || true
sudo docker-compose up -d
echo "[+] Đợi dịch vụ sẵn sàng (15s)..."
sleep 15
echo "[+] Đang khởi động Web Flask (Backend Cổng 5000)..."
sudo chmod 755 /var/log/apache2 2>/dev/null || true
sudo chmod 666 /var/log/apache2/flask_access.log /var/log/apache2/flask_error.log 2>/dev/null || true
cd /opt/sso-lab/employee_portal
sudo pkill -f "python3 app.py" 2>/dev/null || true
nohup python3 app.py >> flask.log 2>&1 &
sleep 2
echo "[+] Đang khởi động ModSecurity WAF trên Apache (Cổng 5001)..."
sudo service apache2 restart
sleep 2
echo "XONG! Chuyển sang máy student-pc, mở trình duyệt truy cập http://172.20.0.10:5001"
