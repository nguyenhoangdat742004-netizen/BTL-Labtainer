import os
import base64
import xml.etree.ElementTree as ET
from flask import Flask, request, redirect, session
from onelogin.saml2.auth import OneLogin_Saml2_Auth
from urllib.parse import urlparse

app = Flask(__name__)
app.secret_key = 'SSO_LAB_SECRET_KEY'

# ==============================================================================
# CẤU HÌNH TRẠNG THÁI BÀI LAB (CHỌN CHẾ ĐỘ DEMO):
# False: Chế độ xác thực linh hoạt (Bypass kiểm tra chữ ký số)
# True : Kiểm tra chữ ký số nghiêm ngặt
# ==============================================================================
ENABLE_SIGNATURE_CHECK = False

# Đường dẫn tới thư mục chứa settings.json
app.config['SAML_PATH'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'saml')

# Hàm chuẩn bị request từ Flask để thư viện SAML hiểu được
def prepare_flask_request(req):
    url_data = urlparse(req.url)
    return {
        'https': 'on' if req.scheme == 'https' else 'off',
        'http_host': req.host,
        'server_port': url_data.port,
        'script_name': req.path,
        'get_data': req.args.copy(),
        'post_data': req.form.copy()
    }

# Hàm khởi tạo SAML Auth
def init_saml_auth(req):
    return OneLogin_Saml2_Auth(req, custom_base_path=app.config['SAML_PATH'])

# CSS chung hiện đại chuẩn doanh nghiệp
BASE_STYLE = """
<style>
    :root {
        --primary: #2563eb;
        --primary-hover: #1d4ed8;
        --gray-50: #f8fafc;
        --gray-100: #f1f5f9;
        --gray-200: #e2e8f0;
        --gray-300: #cbd5e1;
        --gray-500: #64748b;
        --gray-600: #475569;
        --gray-700: #334155;
        --gray-900: #0f172a;
    }
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    body {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        background: linear-gradient(135deg, #f0f4f9 0%, #e2e8f0 100%);
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 32px 16px;
        color: var(--gray-900);
    }
    .wrapper {
        width: 100%;
        max-width: 760px;
    }
    .card {
        background: #ffffff;
        border-radius: 18px;
        box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04);
        border: 1px solid var(--gray-200);
        overflow: hidden;
        animation: fadeIn 0.35s ease-out;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    .card-header {
        padding: 24px 32px;
        border-bottom: 1px solid var(--gray-100);
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: #ffffff;
        flex-wrap: wrap;
        gap: 16px;
    }
    .brand {
        display: flex;
        align-items: center;
        gap: 16px;
    }
    .brand-icon {
        width: 50px;
        height: 50px;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
    }
    .icon-admin {
        background: linear-gradient(135deg, #4f46e5 0%, #3730a3 100%);
        color: #ffffff;
        box-shadow: 0 4px 12px rgba(79, 70, 229, 0.25);
    }
    .icon-employee {
        background: linear-gradient(135deg, #059669 0%, #065f46 100%);
        color: #ffffff;
        box-shadow: 0 4px 12px rgba(5, 150, 105, 0.25);
    }
    .icon-portal {
        background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
        color: #ffffff;
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.25);
    }
    .brand-title {
        font-size: 20px;
        font-weight: 700;
        color: var(--gray-900);
        line-height: 1.25;
    }
    .brand-subtitle {
        font-size: 13px;
        color: var(--gray-500);
        margin-top: 3px;
    }
    .pill {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 14px;
        border-radius: 9999px;
        font-size: 12px;
        font-weight: 600;
    }
    .pill-green {
        background: #ecfdf5;
        color: #065f46;
        border: 1px solid #a7f3d0;
    }
    .pill-indigo {
        background: #eef2ff;
        color: #3730a3;
        border: 1px solid #c7d2fe;
    }
    .status-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #10b981;
    }
    .card-body {
        padding: 32px;
    }
    .welcome-text {
        font-size: 15px;
        color: var(--gray-600);
        line-height: 1.6;
        margin-bottom: 24px;
    }
    .stat-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 16px;
        margin-bottom: 24px;
    }
    .stat-card {
        background: var(--gray-50);
        border: 1px solid var(--gray-200);
        border-radius: 12px;
        padding: 16px;
    }
    .stat-label {
        font-size: 11px;
        font-weight: 700;
        color: var(--gray-500);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 6px;
    }
    .stat-value {
        font-size: 15px;
        font-weight: 600;
        color: var(--gray-900);
    }
    .section-title {
        font-size: 13px;
        font-weight: 700;
        color: var(--gray-700);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 12px;
    }
    .table-box {
        border: 1px solid var(--gray-200);
        border-radius: 12px;
        overflow: hidden;
        margin-bottom: 24px;
    }
    .data-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 14px;
    }
    .data-table th {
        background: var(--gray-50);
        padding: 12px 18px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: var(--gray-500);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        border-bottom: 1px solid var(--gray-200);
    }
    .data-table td {
        padding: 12px 18px;
        border-bottom: 1px solid var(--gray-100);
        color: var(--gray-700);
    }
    .data-table tr:last-child td {
        border-bottom: none;
    }
    .code-val {
        background: var(--gray-100);
        padding: 4px 10px;
        border-radius: 6px;
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size: 13px;
        color: var(--gray-900);
        border: 1px solid var(--gray-200);
    }
    .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 13px 24px;
        border-radius: 10px;
        font-size: 15px;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
        transition: all 0.2s ease;
        border: none;
    }
    .btn-login {
        width: 100%;
        background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
        color: #ffffff;
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.25);
    }
    .btn-login:hover {
        background: linear-gradient(135deg, #1d4ed8 0%, #1e40af 100%);
        box-shadow: 0 6px 16px rgba(37, 99, 235, 0.35);
        transform: translateY(-1px);
    }
    .btn-logout {
        background: #ffffff;
        color: #475569;
        border: 1px solid var(--gray-300);
    }
    .btn-logout:hover {
        background: #f8fafc;
        color: #0f172a;
        border-color: var(--gray-500);
    }
    .card-footer {
        padding: 16px 32px;
        background: var(--gray-50);
        border-top: 1px solid var(--gray-100);
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        color: var(--gray-500);
        flex-wrap: wrap;
        gap: 8px;
    }
    .subtle-footer {
        text-align: center;
        margin-top: 20px;
        font-size: 13px;
        color: var(--gray-500);
    }
</style>
"""

def render_attributes_table(attrs):
    if not attrs:
        return '<p style="color: var(--gray-500); font-style: italic; padding: 12px;">Không có thuộc tính mở rộng trong phiên.</p>'
    rows = []
    for k, v in attrs.items():
        val_str = ", ".join(str(x) for x in v) if isinstance(v, list) else str(v)
        rows.append(f"""
            <tr>
                <td style="font-weight: 600; width: 35%;">{k}</td>
                <td><span class="code-val">{val_str}</span></td>
            </tr>
        """)
    return f"""
    <div class="table-box">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Thuộc tính</th>
                    <th>Giá trị xác thực</th>
                </tr>
            </thead>
            <tbody>
                {''.join(rows)}
            </tbody>
        </table>
    </div>
    """

# Route 1: Trang chủ
@app.route('/')
def index():
    if 'samlNameId' in session:
        user = session['samlNameId']
        is_admin = (user.lower() == 'admin')
        attrs_html = render_attributes_table(session.get('samlUserdata', {}))
        
        if is_admin:
            # Giao diện dành riêng cho Quản trị viên
            return f"""<!DOCTYPE html>
            <html lang="vi">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Cổng Quản Trị Hệ Thống - Admin Dashboard</title>
                {BASE_STYLE}
            </head>
            <body>
                <div class="wrapper">
                    <div class="card">
                        <div class="card-header">
                            <div class="brand">
                                <div class="brand-icon icon-admin">👑</div>
                                <div>
                                    <div class="brand-title">Cổng Quản Trị Hệ Thống</div>
                                    <div class="brand-subtitle">Không gian làm việc Quản trị viên (Admin Dashboard)</div>
                                </div>
                            </div>
                            <div class="pill pill-indigo">
                                <span class="status-dot"></span>
                                Phiên Quản trị viên
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="stat-grid">
                                <div class="stat-card">
                                    <div class="stat-label">Tài khoản xác thực</div>
                                    <div class="stat-value" style="color: #4f46e5;">{user}</div>
                                </div>
                                <div class="stat-card">
                                    <div class="stat-label">Quyền hạn hệ thống</div>
                                    <div class="stat-value">Administrator (Toàn quyền)</div>
                                </div>
                                <div class="stat-card">
                                    <div class="stat-label">Trạng thái phiên</div>
                                    <div class="stat-value" style="color: #059669;">Đã xác thực SSO</div>
                                </div>
                            </div>
                            
                            <div class="section-title">Dữ liệu xác thực từ Keycloak / LDAP:</div>
                            {attrs_html}
                            
                            <div style="display: flex; justify-content: flex-end; margin-top: 8px;">
                                <a href="/logout" class="btn btn-logout">🚪 Đăng xuất (Sign Out)</a>
                            </div>
                        </div>
                        <div class="card-footer">
                            <span>Tài khoản: <b>{user}</b></span>
                            <span>Giao thức: SAML 2.0 Web SSO</span>
                        </div>
                    </div>
                    <div class="subtle-footer">
                        Hệ thống Quản lý Danh tính và Phân quyền Doanh nghiệp
                    </div>
                </div>
            </body>
            </html>"""
        else:
            # Giao diện nhân viên thông thường
            return f"""<!DOCTYPE html>
            <html lang="vi">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Cổng Thông Tin Nhân Viên - Employee Portal</title>
                {BASE_STYLE}
            </head>
            <body>
                <div class="wrapper">
                    <div class="card">
                        <div class="card-header">
                            <div class="brand">
                                <div class="brand-icon icon-employee">👤</div>
                                <div>
                                    <div class="brand-title">Cổng Thông Tin Nhân Viên</div>
                                    <div class="brand-subtitle">Trang thông tin dịch vụ nội bộ (Employee Portal)</div>
                                </div>
                            </div>
                            <div class="pill pill-green">
                                <span class="status-dot"></span>
                                Nhân viên nội bộ
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="stat-grid">
                                <div class="stat-card">
                                    <div class="stat-label">Tài khoản xác thực</div>
                                    <div class="stat-value" style="color: #059669;">{user}</div>
                                </div>
                                <div class="stat-card">
                                    <div class="stat-label">Quyền hạn</div>
                                    <div class="stat-value">Employee (Nhân viên)</div>
                                </div>
                                <div class="stat-card">
                                    <div class="stat-label">Trạng thái phiên</div>
                                    <div class="stat-value" style="color: #059669;">Đã xác thực SSO</div>
                                </div>
                            </div>
                            
                            <div class="section-title">Dữ liệu xác thực từ Keycloak / LDAP:</div>
                            {attrs_html}
                            
                            <div style="display: flex; justify-content: flex-end; margin-top: 8px;">
                                <a href="/logout" class="btn btn-logout">🚪 Đăng xuất (Sign Out)</a>
                            </div>
                        </div>
                        <div class="card-footer">
                            <span>Tài khoản: <b>{user}</b></span>
                            <span>Giao thức: SAML 2.0 Web SSO</span>
                        </div>
                    </div>
                    <div class="subtle-footer">
                        Cổng dịch vụ nhân viên • Doanh nghiệp
                    </div>
                </div>
            </body>
            </html>"""
    
    # Trạng thái khi chưa đăng nhập
    return f"""<!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cổng Thông Tin Doanh Nghiệp - SSO Portal</title>
        {BASE_STYLE}
    </head>
    <body>
        <div class="wrapper">
            <div class="card">
                <div class="card-header">
                    <div class="brand">
                        <div class="brand-icon icon-portal">🏢</div>
                        <div>
                            <div class="brand-title">Cổng Thông Tin Doanh Nghiệp</div>
                            <div class="brand-subtitle">Hệ thống dịch vụ nội bộ (SSO Employee Portal)</div>
                        </div>
                    </div>
                    <div class="pill pill-green">
                        <span class="status-dot"></span>
                        Đang hoạt động
                    </div>
                </div>
                <div class="card-body">
                    <p class="welcome-text">
                        Hệ thống tích hợp giải pháp đăng nhập một lần (Single Sign-On) qua giao thức tiêu chuẩn SAML 2.0. Đăng nhập an toàn để sử dụng các dịch vụ và tài nguyên doanh nghiệp.
                    </p>
                    <div class="stat-grid">
                        <div class="stat-card">
                            <div class="stat-label">Phương thức xác thực</div>
                            <div class="stat-value">SAML 2.0 Web SSO</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-label">Identity Provider (IdP)</div>
                            <div class="stat-value">Keycloak (sso-lab)</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-label">Trạng thái hệ thống</div>
                            <div class="stat-value" style="color: #059669;">Sẵn sàng kết nối</div>
                        </div>
                    </div>
                    <a href="/saml/login" class="btn btn-login">
                        🔐 Đăng nhập qua SSO (Keycloak)
                    </a>
                </div>
                <div class="card-footer">
                    <span>Phiên bản: SSO Portal v2.4</span>
                    <span>Service Provider (ACS): /saml/acs</span>
                </div>
            </div>
            <div class="subtle-footer">
                Hệ thống Quản lý Danh tính Doanh nghiệp • SAML 2.0
            </div>
        </div>
    </body>
    </html>"""

# Route 2: Chuyển hướng người dùng sang Keycloak để đăng nhập
@app.route('/saml/login')
def login():
    req = prepare_flask_request(request)
    auth = init_saml_auth(req)
    return redirect(auth.login())

# Route 3: Nơi nhận SAML Response (Assertion Consumer Service - ACS)
@app.route('/saml/acs', methods=['POST'])
def acs():
    req = prepare_flask_request(request)
    auth = init_saml_auth(req)
    
    if not ENABLE_SIGNATURE_CHECK:
        # Trích xuất thông tin người dùng từ SAMLResponse
        # Bỏ qua bước kiểm tra chữ ký số khi ENABLE_SIGNATURE_CHECK = False
        saml_b64 = request.form.get('SAMLResponse', '')
        if not saml_b64:
            return "Lỗi: Không tìm thấy SAMLResponse!", 400

        try:
            # Tự động làm sạch chuỗi Base64:
            # 1. Đổi khoảng trắng ngược lại thành '+' (khắc phục lỗi application/x-www-form-urlencoded chuyển '+' thành ' ')
            clean_b64 = saml_b64.strip().replace(' ', '+')
            # 2. Bổ sung padding '=' nếu bị thiếu khi copy-paste
            missing_padding = len(clean_b64) % 4
            if missing_padding:
                clean_b64 += '=' * (4 - missing_padding)

            xml_data = base64.b64decode(clean_b64)
            # Loại bỏ Byte Order Mark (BOM) nếu có
            if xml_data.startswith(b'\xef\xbb\xbf'):
                xml_data = xml_data[3:]

            root = ET.fromstring(xml_data)
            
            # Trích xuất trường NameID từ XML mà không xác thực chữ ký số
            ns = {
                'saml': 'urn:oasis:names:tc:SAML:2.0:assertion',
                'saml2': 'urn:oasis:names:tc:SAML:2.0:assertion'
            }
            name_id_elem = root.find('.//{urn:oasis:names:tc:SAML:2.0:assertion}NameID')
            if name_id_elem is None:
                name_id_elem = root.find('.//saml:NameID', ns)
            if name_id_elem is None:
                name_id_elem = root.find('.//saml2:NameID', ns)
            if name_id_elem is None:
                for elem in root.iter():
                    if elem.tag.endswith('NameID') or elem.tag == 'NameID':
                        name_id_elem = elem
                        break

            if name_id_elem is not None and name_id_elem.text:
                username = name_id_elem.text.strip()
                session['samlNameId'] = username
                session['samlUserdata'] = {
                    'username': [username],
                    'role': ['admin'] if username.lower() == 'admin' else ['employee']
                }
                print(f"[AUTH] User {username} logged in successfully", flush=True)
                try:
                    with open('/opt/sso-lab/employee_portal/flask.log', 'a') as f:
                        f.write(f"[AUTH] User {username} logged in successfully\n")
                except Exception:
                    pass
                try:
                    with open('/var/log/apache2/flask_access.log', 'a') as f:
                        f.write(f"127.0.0.1 - {username} [AUTH] User {username} logged in successfully HTTP/1.1 200\n")
                except Exception:
                    pass
                return redirect('/')
            else:
                return "Lỗi SAML: Không tìm thấy trường NameID trong Assertion!", 400
        except Exception as e:
            return f"Lỗi xử lý SAML XML: {str(e)}", 400

    else:
        # KỊCH BẢN PHÒNG THỦ: Kiểm tra chữ ký số nghiêm ngặt
        auth.process_response()
        errors = auth.get_errors()

        if not errors:
            if auth.is_authenticated():
                session['samlUserdata'] = auth.get_attributes()
                session['samlNameId'] = auth.get_nameid()
                print(f"[AUTH] User {session['samlNameId']} logged in successfully", flush=True)
                try:
                    with open('/opt/sso-lab/employee_portal/flask.log', 'a') as f:
                        f.write(f"[AUTH] User {session['samlNameId']} logged in successfully\n")
                except Exception:
                    pass
                return redirect('/')
            else:
                return "Xác thực thất bại!", 401
        else:
            reason = auth.get_last_error_reason()
            return f"""<!DOCTYPE html>
            <html lang="vi">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Lỗi Xác Thực SAML</title>
                {BASE_STYLE}
            </head>
            <body>
                <div class="wrapper">
                    <div class="card">
                        <div class="card-header">
                            <div class="brand">
                                <div class="brand-icon" style="background: #fee2e2; color: #dc2626;">⚠️</div>
                                <div>
                                    <div class="brand-title">Lỗi Xác Thực SAML</div>
                                    <div class="brand-subtitle">Không thể hoàn tất xác thực đăng nhập</div>
                                </div>
                            </div>
                            <div class="pill" style="background: #fef2f2; color: #dc2626; border: 1px solid #fecaca;">
                                Lỗi phiên
                            </div>
                        </div>
                        <div class="card-body">
                            <p class="welcome-text">
                                Hệ thống từ chối đăng nhập do gói tin SAMLResponse không hợp lệ hoặc chữ ký số không chính xác.
                            </p>
                            <div class="stat-card" style="margin-bottom: 20px; border-color: #fecaca; background: #fff5f5;">
                                <div class="stat-label" style="color: #b91c1c;">Mã lỗi SAML:</div>
                                <div style="margin-top: 4px;"><span class="code-val" style="color: #dc2626;">{', '.join(errors)}</span></div>
                                <div class="stat-label" style="margin-top: 12px; color: #b91c1c;">Chi tiết:</div>
                                <div style="font-size: 14px; color: #7f1d1d; margin-top: 4px;">{reason}</div>
                            </div>
                            <a href="/saml/login" class="btn btn-login" style="background: #475569;">
                                🔄 Thử đăng nhập lại
                            </a>
                        </div>
                        <div class="card-footer">
                            <span>Mã trạng thái: 403 Forbidden</span>
                            <span>Dịch vụ xác thực SAML 2.0</span>
                        </div>
                    </div>
                </div>
            </body>
            </html>""", 403

# Route 4: Cung cấp Metadata cho IdP
@app.route('/saml/metadata')
def metadata():
    req = prepare_flask_request(request)
    auth = init_saml_auth(req)
    settings = auth.get_settings()
    metadata = settings.get_sp_metadata()
    errors = settings.validate_metadata(metadata)
    if len(errors) == 0:
        return metadata, 200, {'Content-Type': 'text/xml'}
    else:
        return ', '.join(errors), 500

# Route 5: Đăng xuất (xóa session) để thuận tiện cho việc demo nhiều lần
@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)
