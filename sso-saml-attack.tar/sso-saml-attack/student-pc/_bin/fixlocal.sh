#!/bin/bash
#
#  This script will be run after parameterization has completed, e.g., 
#  use this to compile source code that has been parameterized.
#  The container user password will be passed as the first argument,
#  (the user ID is the second parameter)
#  If this script is to use sudo and the sudoers for the lab
#  does not permit nopassword, then use:
#  echo $1 | sudo -S the-command
#
#  If you issue commands herein to start services, and those services
#  have unit files prescribing their being started after the
#  waitparam.service, then first create the flag directory that
#  waitparam sleeps on:
#
#   PERMLOCKDIR=/var/labtainer/did_param
#   echo $1 | sudo -S mkdir -p "$PERMLOCKDIR"

grep -q "$(hostname)" /etc/hosts 2>/dev/null || echo "127.0.0.1 $(hostname)" | sudo tee -a /etc/hosts >/dev/null 2>&1

# Fix burpsuite wrapper script so install4j does not fail on symlink resolution
sudo rm -f /usr/local/bin/burpsuite /usr/bin/burpsuite /usr/local/bin/burp /usr/bin/burp
sudo tee /usr/local/bin/burpsuite > /dev/null << 'EOF'
#!/bin/bash
exec /usr/local/BurpSuiteCommunity/BurpSuiteCommunity "$@"
EOF
sudo chmod 755 /usr/local/bin/burpsuite
sudo cp -a /usr/local/bin/burpsuite /usr/bin/burpsuite
sudo cp -a /usr/local/bin/burpsuite /usr/local/bin/burp
# Ensure X11 socket is accessible
if [ -d /var/tmp/.X11-unix ]; then
    sudo mkdir -p /tmp/.X11-unix 2>/dev/null || mkdir -p /tmp/.X11-unix
    sudo ln -sf /var/tmp/.X11-unix/* /tmp/.X11-unix/ 2>/dev/null || true
fi

