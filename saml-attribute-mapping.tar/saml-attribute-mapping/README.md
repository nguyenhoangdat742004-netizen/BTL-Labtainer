# Labtainers: Kiểm thử Cấu hình và Phòng thủ Lỗi Ánh xạ Thuộc tính trong SSO SAML 2.0 (`saml-attribute-mapping`)

## 1. Kiến trúc 3 Container (`172.20.0.0/24`)
- **`sp-server` (`172.20.0.10`)**: Tích hợp OpenLDAP + Keycloak SAML IdP (`Port 8080`) + Service Provider Web Portal (`Port 5000`, **Giao diện nền sáng Light Theme**) + Wazuh Agent / `iptables`.
- **`wazuh-manager` (`172.20.0.30`)**: Máy chủ SIEM Wazuh (`/var/ossec/etc/rules/local_rules.xml`, áp dụng rule bằng `sudo systemctl restart wazuh-manager` hoặc `sudo /var/ossec/bin/wazuh-control restart`, xem cảnh báo tại `/var/ossec/logs/alerts/alerts.log`).
- **`student-pc` (`172.20.0.20`)**: Máy trạm thực hành chứa `~/code_mau.txt`, `check_sso_config.py`, `simulate_sso_flow.py` và trình duyệt Firefox.

## 2. 5 Tiêu chí Đánh giá (`checkwork` - 5 mục tương ứng trong `goals.config` & `results.config`)
| Mục tiêu | Biến kết quả (`results.config`) | Ý nghĩa |
| :--- | :--- | :--- |
| `1_config_probed` | `_config_probed` | Chạy `check_sso_config.py` dò thành công cấu hình SAML Mapper. |
| `2_role_override_success` | `_role_override` | Chạy `simulate_sso_flow.py` leo thang quyền `Administrator` và truy cập Web. |
| `3_wazuh_rule_configured` | `_wazuh_rule` | Thêm Rule `100601` vào `/var/ossec/etc/rules/local_rules.xml` và khởi động lại `wazuh-manager`. |
| `4_active_response_triggered` | `_active_response` | Tấn công lại, Wazuh kích hoạt `firewall-drop` chặn IP `172.20.0.20` (không vào được web nữa). |
| `5_siem_alert_logged` | `_siem_alert` | Hệ thống ghi nhận cảnh báo Rule `100601` trong `/var/ossec/logs/alerts/alerts.log`. |

Xem hướng dẫn từng bước chi tiết tại [docs/INSTRUCTIONS.md](docs/INSTRUCTIONS.md).
