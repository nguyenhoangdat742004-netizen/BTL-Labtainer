#!/bin/bash
# fixlocal.sh for sp-server (172.20.0.10)
grep -q "sp.lab" /etc/hosts 2>/dev/null || echo "172.20.0.10 sp-server sp.lab idp.lab ldap.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "student-pc" /etc/hosts 2>/dev/null || echo "172.20.0.20 student-pc" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "wazuh-manager" /etc/hosts 2>/dev/null || echo "172.20.0.30 wazuh-manager wazuh.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1

sudo chmod +x /var/ossec/active-response/bin/firewall-drop /opt/keycloak-idp/app.py /opt/sp-portal/app.py /opt/sp-portal/ar_bridge.py /etc/rc.local 2>/dev/null || true
sudo /etc/rc.local
echo "[OK] sp-server started Keycloak IdP (:8080), SP Portal (:5000, Light Theme) and Wazuh Agent."
