#!/usr/bin/env python3
"""
Keycloak SAML 2.0 Identity Provider (IdP) with OpenLDAP Federation
Lab: saml-attribute-mapping (sp-server: 172.20.0.10, Port 8080 & Port 80)
"""
import os
import json
import uuid
import base64
import urllib.parse
import threading
import datetime
from flask import Flask, request, redirect, render_template_string, jsonify
from lxml import etree

from cryptography.hazmat.primitives.asymmetric import ec
for curve in ['SECT163K1', 'SECT233K1', 'SECT233R1', 'SECT283R1', 'SECT409K1', 'SECT409R1', 'SECT571K1', 'SECP192R1', 'SECP224R1']:
    if not hasattr(ec, curve):
        setattr(ec, curve, ec.SECP256R1)

import signxml

app = Flask(__name__)
app.secret_key = 'KEYCLOAK_IDP_SAML_ATTRIBUTE_MAPPING'

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
KEY_FILE = os.path.join(BASE_DIR, 'keys', 'idp_private.key')
CERT_FILE = os.path.join(BASE_DIR, 'keys', 'idp_cert.crt')

AUDIT_LOG = '/var/log/sp-portal/audit.log'
APP_JSON_LOG = '/var/log/sp-portal/app.json'
SP_ACS_URL = 'http://172.20.0.10:5000/saml/acs'

LDAP_USERS = {
    'student': {
        'password': 'student123',
        'dn': 'uid=student,ou=users,dc=enterprise,dc=corp',
        'role': 'User',
        'email': 'student@enterprise.corp',
        'dept': 'QA and Security Audit'
    },
    'alice': {
        'password': 'Alice@123',
        'dn': 'uid=alice,ou=users,dc=enterprise,dc=corp',
        'role': 'User',
        'email': 'alice@enterprise.corp',
        'dept': 'Human Resources'
    },
    'admin': {
        'password': 'Admin@Enterprise2026',
        'dn': 'uid=admin,ou=users,dc=enterprise,dc=corp',
        'role': 'Administrator',
        'email': 'admin@enterprise.corp',
        'dept': 'IT Security Operations'
    }
}

def write_audit_log(msg):
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    os.makedirs(os.path.dirname(AUDIT_LOG), exist_ok=True)
    with open(AUDIT_LOG, 'a') as f:
        f.write(f"{ts} keycloak-idp {msg}\n")
        f.flush()

def write_json_log(data_dict):
    os.makedirs(os.path.dirname(APP_JSON_LOG), exist_ok=True)
    with open(APP_JSON_LOG, 'a') as f:
        f.write(json.dumps(data_dict) + '\n')
        f.flush()

def generate_signed_saml_response(username, role, email, dept):
    now = datetime.datetime.now(datetime.timezone.utc)
    issue_instant = now.strftime('%Y-%m-%dT%H:%M:%SZ')
    not_before = (now - datetime.timedelta(minutes=5)).strftime('%Y-%m-%dT%H:%M:%SZ')
    not_on_or_after = (now + datetime.timedelta(minutes=15)).strftime('%Y-%m-%dT%H:%M:%SZ')

    response_id = f"ID_{uuid.uuid4().hex}"
    assertion_id = f"ID_{uuid.uuid4().hex}"

    xml_template = f"""<samlp:Response xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol"
                xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion"
                ID="{response_id}"
                Version="2.0"
                IssueInstant="{issue_instant}"
                Destination="{SP_ACS_URL}">
    <saml:Issuer>http://172.20.0.10:8080/realms/EnterpriseRealm</saml:Issuer>
    <samlp:Status>
        <samlp:StatusCode Value="urn:oasis:names:tc:SAML:2.0:status:Success"/>
    </samlp:Status>
    <saml:Assertion xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion"
                    ID="{assertion_id}"
                    Version="2.0"
                    IssueInstant="{issue_instant}">
        <saml:Issuer>http://172.20.0.10:8080/realms/EnterpriseRealm</saml:Issuer>
        <saml:Subject>
            <saml:NameID Format="urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified">{username}</saml:NameID>
            <saml:SubjectConfirmation Method="urn:oasis:names:tc:SAML:2.0:cm:bearer">
                <saml:SubjectConfirmationData NotOnOrAfter="{not_on_or_after}"
                                              Recipient="{SP_ACS_URL}"/>
            </saml:SubjectConfirmation>
        </saml:Subject>
        <saml:Conditions NotBefore="{not_before}" NotOnOrAfter="{not_on_or_after}">
            <saml:AudienceRestriction>
                <saml:Audience>http://172.20.0.10:5000/saml/metadata</saml:Audience>
            </saml:AudienceRestriction>
        </saml:Conditions>
        <saml:AuthnStatement AuthnInstant="{issue_instant}">
            <saml:AuthnContext>
                <saml:AuthnContextClassRef>urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport</saml:AuthnContextClassRef>
            </saml:AuthnContext>
        </saml:AuthnStatement>
        <saml:AttributeStatement>
            <saml:Attribute Name="Role">
                <saml:AttributeValue>{role}</saml:AttributeValue>
            </saml:Attribute>
            <saml:Attribute Name="Email">
                <saml:AttributeValue>{email}</saml:AttributeValue>
            </saml:Attribute>
            <saml:Attribute Name="Department">
                <saml:AttributeValue>{dept}</saml:AttributeValue>
            </saml:Attribute>
        </saml:AttributeStatement>
    </saml:Assertion>
</samlp:Response>"""

    root = etree.fromstring(xml_template.encode('utf-8'))
    with open(KEY_FILE, 'rb') as kf, open(CERT_FILE, 'rb') as cf:
        signer = signxml.XMLSigner(
            method=signxml.methods.enveloped,
            signature_algorithm='rsa-sha256',
            digest_algorithm='sha256'
        )
        signed_root = signer.sign(root, key=kf.read(), cert=cf.read())

    signed_xml = etree.tostring(signed_root, encoding='utf-8')
    return base64.b64encode(signed_xml).decode('utf-8'), assertion_id

KEYCLOAK_LOGIN_HTML = """<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Keycloak IdP - EnterpriseRealm SAML 2.0</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; color: #0f172a; font-family: system-ui, -apple-system, sans-serif; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .kc-card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 16px; box-shadow: 0 8px 24px rgba(15,23,42,0.05); max-width: 460px; width: 100%; padding: 36px; }
    </style>
</head>
<body>
<div class="kc-card">
    <div class="text-center mb-4">
        <div class="fs-1 mb-2">🛡️</div>
        <h5 class="fw-bold mb-1">Keycloak Identity Provider</h5>
        <p class="text-secondary small mb-2">Tích hợp OpenLDAP User Federation (<code>dc=enterprise,dc=corp</code>)</p>
        <span class="badge bg-primary-subtle text-primary border border-primary-subtle">Realm: EnterpriseRealm</span>
    </div>
    {% if error %}
    <div class="alert alert-danger py-2 small">{{ error }}</div>
    {% endif %}
    <form method="POST" action="/realms/EnterpriseRealm/protocol/saml">
        <div class="mb-3">
            <label class="form-label small fw-semibold">Tài khoản OpenLDAP</label>
            <input type="text" name="username" class="form-control" value="student" required>
        </div>
        <div class="mb-3">
            <label class="form-label small fw-semibold">Mật khẩu</label>
            <input type="password" name="password" class="form-control" value="student123" required>
        </div>
        <button type="submit" class="btn btn-primary w-100 fw-semibold py-2">Đăng nhập SAML SSO</button>
    </form>
    <div class="mt-3 pt-3 border-top text-center">
        <a href="http://172.20.0.10:5000" class="small text-decoration-none">← Quay lại Cổng Dịch Vụ (Service Provider :5000)</a>
    </div>
</div>
</body>
</html>"""

@app.route('/')
def index():
    return redirect('/realms/EnterpriseRealm/protocol/saml')

@app.route('/realms/EnterpriseRealm/protocol/saml', methods=['GET', 'POST'])
def saml_protocol():
    src_ip = request.headers.get('X-Forwarded-For', request.remote_addr)
    now_iso = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')

    if request.method == 'GET':
        probe = request.args.get('probe', '')
        if probe == 'attributes.role':
            write_audit_log(f"[CONFIG_PROBE_SUCCESS] srcip={src_ip} probe={probe} status=DYNAMIC_MAPPER_ENABLED")
            return jsonify({
                "realm": "EnterpriseRealm",
                "protocol": "saml",
                "mapper": "client-attribute-mapper",
                "probe_parameter": probe,
                "dynamic_mapping_allowed": True,
                "status": "MISCONFIGURATION_DETECTED"
            }), 200
        return render_template_string(KEYCLOAK_LOGIN_HTML)

    username = request.form.get('username', '').strip()
    password = request.form.get('password', '').strip()
    override_role = request.form.get('attributes.role', '').strip()

    user_obj = LDAP_USERS.get(username)
    if not user_obj or user_obj['password'] != password:
        return render_template_string(KEYCLOAK_LOGIN_HTML, error="Sai tài khoản hoặc mật khẩu OpenLDAP!"), 401

    ldap_role = user_obj['role']
    mapped_role = override_role if override_role else ldap_role

    if override_role and override_role != ldap_role:
        write_audit_log(
            f"[ROLE_OVERRIDE_SUCCESS] srcip={src_ip} user={username} ldap_role={ldap_role} mapped_role={mapped_role}"
        )
        write_json_log({
            "timestamp": now_iso,
            "srcip": src_ip,
            "component": "keycloak-idp",
            "realm": "EnterpriseRealm",
            "user": username,
            "ldap_dn": user_obj['dn'],
            "ldap_role": ldap_role,
            "mapped_role": mapped_role,
            "event_type": "AttributeMismatch|RoleOverride|UnauthorizedAttributeModification",
            "message": f"Critical SSO Federation: AttributeMismatch and RoleOverride for user '{username}' (LDAP role '{ldap_role}' overridden to '{mapped_role}' via attributes.role)"
        })

    saml_b64, _ = generate_signed_saml_response(
        username=username,
        role=mapped_role,
        email=user_obj['email'],
        dept=user_obj['dept']
    )
    encoded_saml = urllib.parse.quote(saml_b64)
    return redirect(f"{SP_ACS_URL}?SAMLResponse={encoded_saml}&client_ip={src_ip}", code=302)

if __name__ == '__main__':
    threading.Thread(target=lambda: app.run(host='0.0.0.0', port=80, use_reloader=False), daemon=True).start()
    app.run(host='0.0.0.0', port=8080, use_reloader=False)
