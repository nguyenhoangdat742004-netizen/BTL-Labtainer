#!/usr/bin/env python3
"""
Enterprise Cloud Service Provider (SP) Portal - Light Theme (Port 5000)
Lab: saml-attribute-mapping (sp-server: 172.20.0.10)
"""
import os
import json
import base64
import datetime
from flask import Flask, request, redirect, session, render_template_string, jsonify
from lxml import etree

app = Flask(__name__)
app.secret_key = 'SP_PORTAL_LIGHT_THEME_2026'

AUDIT_LOG = '/var/log/sp-portal/audit.log'
APP_JSON_LOG = '/var/log/sp-portal/app.json'
STATE_FILE = '/var/log/sp-portal/current_session.json'
IDP_SAML_URL = 'http://172.20.0.10:8080/realms/EnterpriseRealm/protocol/saml'

EMPLOYEES = [
    {"uid": "student", "name": "Nguyen Van Student", "dept": "QA and Security Audit", "ldap_role": "User", "email": "student@enterprise.corp"},
    {"uid": "alice", "name": "Tran Thi Alice", "dept": "Human Resources", "ldap_role": "User", "email": "alice@enterprise.corp"},
    {"uid": "bob", "name": "Le Van Bob", "dept": "Finance and Accounting", "ldap_role": "User", "email": "bob@enterprise.corp"},
    {"uid": "admin", "name": "Pham Minh Admin", "dept": "IT Security Operations", "ldap_role": "Administrator", "email": "admin@enterprise.corp"}
]

def load_shared_session():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, 'r') as f:
                return json.load(f)
        except Exception:
            pass
    return None

def save_shared_session(data):
    os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
    with open(STATE_FILE, 'w') as f:
        json.dump(data, f)

def clear_shared_session():
    if os.path.exists(STATE_FILE):
        try:
            os.remove(STATE_FILE)
        except Exception:
            pass

def write_audit_log(msg):
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    os.makedirs(os.path.dirname(AUDIT_LOG), exist_ok=True)
    with open(AUDIT_LOG, 'a') as f:
        f.write(f"{ts} sp-server {msg}\n")
        f.flush()

PORTAL_HTML = """<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enterprise Cloud Portal - Service Provider (Light Theme)</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; color: #0f172a; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; min-height: 100vh; display: flex; flex-direction: column; }
        .navbar-light-sp { background: #ffffff; border-bottom: 1px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0,0,0,0.03); }
        .card-light { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; box-shadow: 0 4px 14px rgba(15,23,42,0.04); }
        .badge-admin { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; font-weight: 700; }
        .badge-user { background: #eff6ff; color: #2563eb; border: 1px solid #bfdbfe; font-weight: 600; }
        .nav-pills .nav-link { color: #475569; font-weight: 500; border-radius: 8px; }
        .nav-pills .nav-link.active { background-color: #2563eb; color: #ffffff; }
        footer { margin-top: auto; background: #ffffff; border-top: 1px solid #e2e8f0; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light-sp py-3 px-4 mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold text-primary d-flex align-items-center gap-2" href="/">
            <span>☁️</span>
            <span>Enterprise Cloud Portal (SP)</span>
        </a>
        <div class="d-flex align-items-center gap-3">
            {% if current_user %}
            <span class="badge bg-light text-dark border px-3 py-2">
                👤 <strong>{{ current_user.user }}</strong>
                ({% if current_user.role == 'Administrator' %}<span class="text-danger fw-bold">Administrator</span>{% else %}<span class="text-primary">{{ current_user.role }}</span>{% endif %})
            </span>
            <a href="/logout" class="btn btn-outline-danger btn-sm px-3">Đăng xuất</a>
            {% else %}
            <a href="{{ idp_url }}" class="btn btn-primary btn-sm px-3">Đăng nhập SAML SSO</a>
            {% endif %}
        </div>
    </div>
</nav>

<main class="container pb-5">
    {% if current_user %}
    <!-- Banner trạng thái đăng nhập -->
    <div class="card-light p-4 mb-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
                <h3 class="fw-bold mb-1">Welcome, {{ current_user.role }}</h3>
                <p class="text-secondary mb-0">
                    Tài khoản xác thực SAML: <code>{{ current_user.user }}</code> | Email: <code>{{ current_user.email }}</code> | Phòng ban: <code>{{ current_user.dept }}</code>
                </p>
            </div>
            <div>
                {% if current_user.role == 'Administrator' %}
                <span class="badge badge-admin px-3 py-2 fs-6">🔓 QUYỀN QUẢN TRỊ TỐI CAO (ADMINISTRATOR)</span>
                {% else %}
                <span class="badge badge-user px-3 py-2 fs-6">🔒 QUYỀN NGƯỜI DÙNG CHUẨN (USER)</span>
                {% endif %}
            </div>
        </div>
    </div>

    <!-- Thanh điều hướng các chức năng trên Web -->
    <ul class="nav nav-pills gap-2 mb-4 bg-white p-2 rounded-3 border">
        <li class="nav-item">
            <a class="nav-link {% if tab == 'dashboard' %}active{% endif %}" href="/?tab=dashboard">📊 Bảng điều khiển &amp; Thuộc tính SAML</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {% if tab == 'directory' %}active{% endif %}" href="/?tab=directory">👥 Danh bạ Nhân sự (OpenLDAP)</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {% if tab == 'admin' %}active{% endif %}" href="/?tab=admin">🛡️ Bảng Quản trị Đặc quyền (Admin Console)</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {% if tab == 'logs' %}active{% endif %}" href="/?tab=logs">📜 Nhật ký Kiểm toán SSO</a>
        </li>
    </ul>

    {% if tab == 'dashboard' %}
    <div class="row g-4">
        <div class="col-lg-7">
            <div class="card-light p-4 h-100">
                <h6 class="fw-bold mb-3">Chi tiết Ánh xạ Thuộc tính SAML 2.0 (SAML Assertion Attributes)</h6>
                <table class="table table-bordered align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Tên Thuộc tính</th>
                            <th>Giá trị gốc (OpenLDAP)</th>
                            <th>Giá trị SAML nhận được</th>
                            <th>Trạng thái</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><code>saml:NameID</code></td>
                            <td><code>{{ current_user.user }}</code></td>
                            <td class="fw-semibold"><code>{{ current_user.user }}</code></td>
                            <td><span class="badge bg-success-subtle text-success">Khớp</span></td>
                        </tr>
                        <tr>
                            <td><code>Attribute[Name="Role"]</code></td>
                            <td><span class="badge badge-user">User</span></td>
                            <td>
                                {% if current_user.role == 'Administrator' %}
                                <span class="badge badge-admin">Administrator</span>
                                {% else %}
                                <span class="badge badge-user">{{ current_user.role }}</span>
                                {% endif %}
                            </td>
                            <td>
                                {% if current_user.role == 'Administrator' and current_user.user == 'student' %}
                                <span class="badge bg-danger-subtle text-danger fw-bold">Bị ghi đè (RoleOverride)</span>
                                {% else %}
                                <span class="badge bg-success-subtle text-success">Khớp</span>
                                {% endif %}
                            </td>
                        </tr>
                        <tr>
                            <td><code>Attribute[Name="Email"]</code></td>
                            <td>{{ current_user.email }}</td>
                            <td>{{ current_user.email }}</td>
                            <td><span class="badge bg-success-subtle text-success">Khớp</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="card-light p-4 h-100">
                <h6 class="fw-bold mb-2">Phân tích Lỗi Ánh xạ Thuộc tính (Attribute Mapping)</h6>
                {% if current_user.role == 'Administrator' and current_user.user == 'student' %}
                <div class="alert alert-danger small">
                    <strong>CẢNH BÁO LEO THANG ĐẶC QUYỀN:</strong><br>
                    Tài khoản <code>student</code> vốn chỉ thuộc nhóm <code>User</code> trên OpenLDAP, nhưng đã truyền tham số <code>attributes.role=Administrator</code> vào Keycloak IdP để nhận vé SAML Assertion quyền <strong>Administrator</strong>!
                </div>
                {% else %}
                <div class="alert alert-info small">
                    Bạn đang đăng nhập với quyền <code>User</code> tiêu chuẩn từ OpenLDAP. Hãy chạy script kiểm thử trên <code>student-pc</code> để kiểm tra lỗ hổng ghi đè thuộc tính!
                </div>
                {% endif %}
                <p class="small text-secondary mb-0">
                    Bạn có thể chuyển sang tab <strong>Bảng Quản trị Đặc quyền (Admin Console)</strong> để kiểm tra các chức năng chỉ dành cho <code>Administrator</code>.
                </p>
            </div>
        </div>
    </div>
    {% elif tab == 'directory' %}
    <div class="card-light p-4">
        <h6 class="fw-bold mb-3">Danh bạ Tài khoản Đồng bộ từ OpenLDAP (<code>dc=enterprise,dc=corp</code>)</h6>
        <table class="table table-hover table-bordered align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>UID</th>
                    <th>Họ và Tên</th>
                    <th>Phòng ban</th>
                    <th>Email</th>
                    <th>Vai trò gốc trên LDAP</th>
                </tr>
            </thead>
            <tbody>
                {% for emp in employees %}
                <tr>
                    <td><code>{{ emp.uid }}</code></td>
                    <td class="fw-semibold">{{ emp.name }}</td>
                    <td>{{ emp.dept }}</td>
                    <td>{{ emp.email }}</td>
                    <td><span class="badge bg-light text-dark border">{{ emp.ldap_role }}</span></td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
    </div>
    {% elif tab == 'admin' %}
    <div class="card-light p-4">
        <h5 class="fw-bold mb-3">🛡️ Bảng Điều Khiển Quản Trị Hệ Thống (Enterprise Admin Console)</h5>
        {% if current_user.role == 'Administrator' %}
        <div class="alert alert-success small">
            <strong>XÁC THỰC QUYỀN ADMINISTRATOR THÀNH CÔNG!</strong> Bạn đang có toàn quyền truy cập vùng quản trị nhạy cảm của doanh nghiệp thông qua SAML Assertion.
        </div>
        <div class="row g-3">
            <div class="col-md-4">
                <div class="border rounded-3 p-3 bg-light">
                    <div class="fw-bold text-primary mb-1">Khóa Cấu hình Liên kết IAM</div>
                    <div class="small text-secondary">Token: <code>IAM-MASTER-KEY-9981-CORP</code></div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="border rounded-3 p-3 bg-light">
                    <div class="fw-bold text-primary mb-1">Chính sách Phân quyền SAML</div>
                    <div class="small text-secondary">Chế độ: <code>Dynamic Client Attribute Mapper</code></div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="border rounded-3 p-3 bg-light">
                    <div class="fw-bold text-primary mb-1">Trạng thái SIEM Wazuh</div>
                    <div class="small text-secondary">Máy chủ giám sát: <code>172.20.0.30 (UDP 514)</code></div>
                </div>
            </div>
        </div>
        {% else %}
        <div class="alert alert-warning mb-0">
            <strong>403 Forbidden:</strong> Tài khoản <code>{{ current_user.user }}</code> (Vai trò: <code>{{ current_user.role }}</code>) không có quyền truy cập Bảng Quản trị! Yêu cầu thuộc tính SAML <code>Role = Administrator</code>.
        </div>
        {% endif %}
    </div>
    {% elif tab == 'logs' %}
    <div class="card-light p-4">
        <h6 class="fw-bold mb-3">Nhật ký Sự kiện Xác thực SAML &amp; Kiểm toán Gần đây</h6>
        <pre class="bg-light p-3 rounded border small mb-0" style="max-height: 320px; overflow-y: auto;">{{ recent_logs }}</pre>
    </div>
    {% endif %}

    {% else %}
    <!-- Màn hình khi chưa đăng nhập -->
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card-light p-5 text-center mb-4">
                <div class="fs-1 mb-2">🔐</div>
                <h3 class="fw-bold mb-2">Cổng Dịch Vụ Doanh Nghiệp (Service Provider)</h3>
                <p class="text-secondary mb-4">
                    Hệ thống xác thực tập trung SAML 2.0 tích hợp <strong>Keycloak IdP</strong> (<code>172.20.0.10:8080</code>) và <strong>OpenLDAP</strong>.
                </p>
                <div class="d-flex justify-content-center gap-3">
                    <a href="{{ idp_url }}" class="btn btn-primary px-4 py-2 fw-semibold">
                        Đăng nhập qua Keycloak SAML SSO
                    </a>
                </div>
            </div>
        </div>
    </div>
    {% endif %}
</main>

<footer class="py-3 text-center text-secondary small">
    <div class="container">
        Enterprise Cloud Service Provider (172.20.0.10:5000) | Giao diện Nền sáng (Light Theme)
    </div>
</footer>
</body>
</html>"""

@app.route('/')
@app.route('/login')
def index():
    tab = request.args.get('tab', 'dashboard')
    current_user = session.get('user_data') or load_shared_session()
    recent_logs = "Chưa có bản ghi log."
    if os.path.exists(AUDIT_LOG):
        with open(AUDIT_LOG, 'r') as f:
            recent_logs = "".join(f.readlines()[-15:])
    return render_template_string(
        PORTAL_HTML,
        current_user=current_user,
        tab=tab,
        employees=EMPLOYEES,
        recent_logs=recent_logs,
        idp_url=IDP_SAML_URL
    ), 200

@app.route('/saml/acs', methods=['GET', 'POST'])
def saml_acs():
    src_ip = request.args.get('client_ip') or request.headers.get('X-Forwarded-For', request.remote_addr)
    b64_saml = request.args.get('SAMLResponse') or request.form.get('SAMLResponse', '')

    username = 'student'
    role = 'User'
    email = 'student@enterprise.corp'
    dept = 'QA and Security Audit'

    if b64_saml:
        try:
            xml_bytes = base64.b64decode(b64_saml)
            root = etree.fromstring(xml_bytes)
            ns = {'saml': 'urn:oasis:names:tc:SAML:2.0:assertion'}
            nameid_el = root.xpath('//saml:Subject/saml:NameID', namespaces=ns)
            if nameid_el and nameid_el[0].text:
                username = nameid_el[0].text.strip()
            role_el = root.xpath('//saml:Attribute[@Name="Role"]/saml:AttributeValue', namespaces=ns)
            if role_el and role_el[0].text:
                role = role_el[0].text.strip()
            mail_el = root.xpath('//saml:Attribute[@Name="Email"]/saml:AttributeValue', namespaces=ns)
            if mail_el and mail_el[0].text:
                email = mail_el[0].text.strip()
            dept_el = root.xpath('//saml:Attribute[@Name="Department"]/saml:AttributeValue', namespaces=ns)
            if dept_el and dept_el[0].text:
                dept = dept_el[0].text.strip()
        except Exception:
            pass

    user_data = {
        "user": username,
        "role": role,
        "email": email,
        "dept": dept
    }
    session['user_data'] = user_data
    save_shared_session(user_data)

    if role == 'Administrator' and username == 'student':
        write_audit_log(f"[ROLE_OVERRIDE_SUCCESS] srcip={src_ip} user={username} granted_role={role}")
    else:
        write_audit_log(f"[SP_LOGIN_SUCCESS] srcip={src_ip} user={username} granted_role={role}")

    recent_logs = ""
    if os.path.exists(AUDIT_LOG):
        with open(AUDIT_LOG, 'r') as f:
            recent_logs = "".join(f.readlines()[-15:])

    return render_template_string(
        PORTAL_HTML,
        current_user=user_data,
        tab='dashboard',
        employees=EMPLOYEES,
        recent_logs=recent_logs,
        idp_url=IDP_SAML_URL
    ), 200

@app.route('/logout')
def logout():
    session.clear()
    clear_shared_session()
    return redirect('/login')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, use_reloader=False)
