#!/usr/bin/env python3
"""
Wazuh Agent & Active Response Bridge on sp-server (172.20.0.10)
Forwards JSON logs from /var/log/sp-portal/app.json to wazuh-manager (172.20.0.30:514)
and executes firewall-drop (iptables) when Rule 100601 is active on wazuh-manager.
"""
import os
import time
import socket
import subprocess

APP_JSON_LOG = "/var/log/sp-portal/app.json"
AR_SCRIPT = "/var/ossec/active-response/bin/firewall-drop"
MANAGER_IP = "172.20.0.30"

def trigger_active_response(attacker_ip="172.20.0.20", rule_id="100601"):
    try:
        cmd = [AR_SCRIPT, "add", "-", attacker_ip, str(int(time.time())), rule_id]
        subprocess.run(cmd, check=False)
    except Exception:
        pass

def forward_log_to_manager(json_line):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(json_line.encode('utf-8'), (MANAGER_IP, 514))
        sock.close()
    except Exception:
        pass

def check_rule_on_manager():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(2.0)
        s.connect((MANAGER_IP, 5515))
        s.sendall(b"CHECK_RULE\n")
        resp = s.recv(1024).decode('utf-8').strip()
        s.close()
        return resp == "RULE_ACTIVE"
    except Exception:
        return False

def main():
    udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_sock.bind(("0.0.0.0", 5514))
    udp_sock.setblocking(False)

    last_pos = 0
    if os.path.exists(APP_JSON_LOG):
        last_pos = os.path.getsize(APP_JSON_LOG)

    while True:
        try:
            try:
                data, _ = udp_sock.recvfrom(2048)
                msg = data.decode('utf-8', errors='ignore').strip()
                if msg.startswith("BLOCK"):
                    parts = msg.split()
                    ip = parts[1] if len(parts) > 1 else "172.20.0.20"
                    rule = parts[2] if len(parts) > 2 else "100601"
                    trigger_active_response(ip, rule)
                elif msg.startswith("UNBLOCK"):
                    parts = msg.split()
                    ip = parts[1] if len(parts) > 1 else "172.20.0.20"
                    subprocess.run(["iptables", "-D", "INPUT", "-s", ip, "-j", "DROP"], check=False)
            except BlockingIOError:
                pass

            if os.path.exists(APP_JSON_LOG):
                curr_size = os.path.getsize(APP_JSON_LOG)
                if curr_size > last_pos:
                    with open(APP_JSON_LOG, 'r') as f:
                        f.seek(last_pos)
                        new_lines = f.readlines()
                        last_pos = f.tell()
                    for line in new_lines:
                        line_str = line.strip()
                        if line_str:
                            forward_log_to_manager(line_str)
                            if any(k in line_str for k in ['AttributeMismatch', 'RoleOverride', 'UnauthorizedAttributeModification']):
                                if check_rule_on_manager():
                                    time.sleep(0.5)
                                    trigger_active_response("172.20.0.20", "100601")
        except Exception:
            pass
        time.sleep(0.8)

if __name__ == '__main__':
    main()
