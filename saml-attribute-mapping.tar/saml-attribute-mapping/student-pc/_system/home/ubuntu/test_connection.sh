#!/bin/bash
echo "=== KIỂM TRA KẾT NỐI TỪ STUDENT-PC (172.20.0.20) ĐẾN SP-SERVER (172.20.0.10) ==="
echo "1. Ping sp-server (172.20.0.10)..."
ping -c 2 -W 2 172.20.0.10 || echo "[-] KHÔNG THỂ PING SP-SERVER (Đã bị chặn bởi iptables firewall-drop!)"

echo ""
echo "2. Kiểm tra Cổng Dịch Vụ Web SP Portal (http://172.20.0.10:5000)..."
curl -I -s --connect-timeout 2 http://172.20.0.10:5000 | head -n 3 || echo "[-] KHÔNG THỂ TRUY CẬP WEB (Đã bị chặn bởi iptables firewall-drop!)"

echo ""
echo "3. Kiểm tra Dịch vụ Keycloak IdP (http://172.20.0.10:8080)..."
curl -I -s --connect-timeout 2 http://172.20.0.10:8080 | head -n 3 || echo "[-] KHÔNG THỂ KẾT NỐI KEYCLOAK IDP (Đã bị chặn bởi iptables firewall-drop!)"
