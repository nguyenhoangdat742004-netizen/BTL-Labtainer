#!/usr/bin/env python3
# ==============================================================================
# GIAI ĐOẠN 1: SCRIPT DÒ QUÉT CẤU HÌNH ÁNH XẠ THUỘC TÍNH (check_sso_config.py)
# Bạn có thể mở file này bằng: nano check_sso_config.py để chỉnh sửa
# Chạy bằng lệnh: python3 check_sso_config.py
# ==============================================================================
import requests

TARGET_URL = "http://172.20.0.10:8080/realms/EnterpriseRealm/protocol/saml"

def verify_mapper_configuration():
    print("[*] Đang kiểm tra cấu hình endpoint SSO Federation và Protocol Mappers...")
    try:
        response = requests.get(TARGET_URL, params={"probe": "attributes.role"}, timeout=4)
        if response.status_code == 200:
            print("[+] [MISCONFIGURATION DETECTED]: Hệ thống đang cho phép ánh xạ thuộc tính linh hoạt từ client input.")
        else:
            print("[-] Cấu hình an toàn: Mục tiêu đã khóa ánh xạ thuộc tính tĩnh.")
    except Exception as e:
        print("[-] Không thể kết nối tới máy chủ (IP có thể đã bị chặn bởi Active Response):", e)

if __name__ == "__main__":
    verify_mapper_configuration()
