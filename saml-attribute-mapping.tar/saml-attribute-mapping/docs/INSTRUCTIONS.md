# BÀI THỰC HÀNH: KIỂM THỬ CẤU HÌNH VÀ PHÒNG THỦ LỖI ÁNH XẠ THUỘC TÍNH (ATTRIBUTE MAPPING) TRONG SSO SAML 2.0 (`saml-attribute-mapping`)

---

## 1. MÔ HÌNH HỆ THỐNG VÀ KIẾN TRÚC MẠNG (`LAN1: 172.20.0.0/24`)

Hệ thống gồm **03 container**:

1. **`sp-server` (`172.20.0.10` - chạy ngầm):**
   - **OpenLDAP Directory**: Lưu trữ tài khoản gốc `student` / `student123` (thuộc nhóm `User`).
   - **Keycloak SAML 2.0 IdP (`Port 8080`)**: Tích hợp User Federation với OpenLDAP và cấp phát SAML Assertion tại `http://172.20.0.10:8080/realms/EnterpriseRealm/protocol/saml`.
   - **Service Provider Portal (`Port 5000`)**: Ứng dụng web **giao diện nền sáng (Light Theme)** tại `http://172.20.0.10:5000`.
   - **Wazuh Agent & Active Response**: Đẩy log JSON về `wazuh-manager` và thực thi `firewall-drop` (`iptables`).
2. **`wazuh-manager` (`172.20.0.30` - cửa sổ Terminal 1):**
   - Máy chủ giám sát SIEM Wazuh thu thập nhật ký xác thực SAML/LDAP.
   - Tệp cấu hình Rule chuẩn: `/var/ossec/etc/rules/local_rules.xml`.
   - Lệnh khởi động/áp dụng Rule chuẩn: `sudo systemctl restart wazuh-manager` (hoặc `sudo /var/ossec/bin/wazuh-control restart`).
   - Đường dẫn log chuẩn: `/var/ossec/logs/alerts/alerts.log` và `/var/ossec/logs/archives/archives.log`.
3. **`student-pc` (`172.20.0.20` - cửa sổ Terminal 2):**
   - Máy trạm thực hành của người học (tích hợp Firefox, Python3 và các tệp code mẫu).

---

## 2. CÁC BƯỚC THỰC HÀNH CHI TIẾT

### BƯỚC 1: DÒ QUÉT LỖ HỔNG CẤU HÌNH ÁNH XẠ THUỘC TÍNH (TRÊN `student-pc`)

Tại cửa sổ terminal của **`student-pc`**, tệp `check_sso_config.py` đã được tạo sẵn. Bạn có thể mở để xem/chỉnh sửa bằng lệnh:

```bash
nano check_sso_config.py
```

Nội dung chuẩn của tệp `check_sso_config.py`:

```python
import requests

TARGET_URL = "http://172.20.0.10:8080/realms/EnterpriseRealm/protocol/saml"

def verify_mapper_configuration():
    print("[*] Đang kiểm tra cấu hình endpoint SSO Federation và Protocol Mappers...")
    response = requests.get(TARGET_URL, params={"probe": "attributes.role"})
    if response.status_code == 200:
        print("[+] [MISCONFIGURATION DETECTED]: Hệ thống đang cho phép ánh xạ thuộc tính linh hoạt từ client input.")
    else:
        print("[-] Cấu hình an toàn: Mục tiêu đã khóa ánh xạ thuộc tính tĩnh.")

if __name__ == "__main__":
    verify_mapper_configuration()
```

Chạy đoạn code dò quét:

```bash
python3 check_sso_config.py
```

**Kết quả:** Hệ thống thông báo `[+] [MISCONFIGURATION DETECTED]: Hệ thống đang cho phép ánh xạ thuộc tính linh hoạt từ client input.` *(Hoàn thành tiêu chí 1: `1_config_probed`)*.

---

### BƯỚC 2: THỰC THI GHI ĐÈ THUỘC TÍNH & TRUY CẬP TRANG WEB (TRÊN `student-pc`)

Mở tệp `simulate_sso_flow.py` để xem hoặc chỉnh sửa tham số `"attributes.role": "Administrator"`:

```bash
nano simulate_sso_flow.py
```

Nội dung chuẩn của tệp `simulate_sso_flow.py`:

```python
import requests

KEYCLOAK_URL = "http://172.20.0.10:8080/realms/EnterpriseRealm/protocol/saml"
TARGET_APP = "http://172.20.0.10:5000/login"
SESSION = requests.Session()

def test_attribute_mapping():
    print("[*] Bước 1: Khởi tạo phiên làm việc với Service Provider...")
    SESSION.get(TARGET_APP)

    print("[*] Bước 2: Gửi dữ liệu xác thực kèm tham số kiểm tra thuộc tính (Attribute Mapping Test)...")
    payload = {
        "username": "student",
        "password": "student123",
        "attributes.role": "Administrator"
    }

    response = SESSION.post(KEYCLOAK_URL, data=payload, allow_redirects=True)

    if "Welcome, Administrator" in response.text or response.status_code == 200:
        print("[+] THÀNH CÔNG: Hệ thống đã cấp quyền Administrator qua SAML Assertion!")
    else:
        print("[-] Hệ thống đã từ chối tham số thuộc tính tùy chỉnh.")

if __name__ == "__main__":
    test_attribute_mapping()
```

Chạy đoạn code:

```bash
python3 simulate_sso_flow.py
```

*(Hoàn thành tiêu chí 2: `2_role_override_success`)*.

Mở trình duyệt web để xem và thao tác với quyền `Administrator`:

```bash
firefox http://172.20.0.10:5000 &
```

Trên giao diện web **nền sáng (Light Theme)**, bạn sẽ thấy mình đã đăng nhập với tiêu đề **`Welcome, Administrator`** (`QUYỀN QUẢN TRỊ TỐI CAO`) và có thể chuyển qua các tab:
- **Bảng điều khiển & Thuộc tính SAML**
- **Danh bạ Nhân sự (OpenLDAP)**
- **Bảng Quản trị Đặc quyền (Admin Console)**
- **Nhật ký Kiểm toán SSO**

---

### BƯỚC 3: PHÒNG THỦ TRÊN WAZUH SIEM - CẤU HÌNH & ÁP DỤNG RULE (TRÊN `wazuh-manager`)

Chuyển sang cửa sổ terminal của **`wazuh-manager`**:

Xem đoạn mẫu Rule đã được chuẩn bị sẵn:

```bash
cat ~/rule_mau.txt
```

Mở tệp cấu hình `/var/ossec/etc/rules/local_rules.xml`:

```bash
sudo nano /var/ossec/etc/rules/local_rules.xml
```

Copy đoạn Rule dưới đây dán vào trong tệp (bạn có thể tùy ý thêm/sửa/xóa nội dung mô tả hoặc nhóm):

```xml
<group name="sso,saml,ldap,">
  <rule id="100601" level="12">
    <decoded_as>json</decoded_as>
    <match>AttributeMismatch|RoleOverride|UnauthorizedAttributeModification</match>
    <description>Critical SSO Federation: Attribute Mismatch or Unauthorized Role Override Detected</description>
    <group>security_audit,identity_verification,</group>
  </rule>
</group>
```

Lưu tệp (`Ctrl+O`, `Enter`, `Ctrl+X`) và **khởi động lại dịch vụ Wazuh Manager để áp dụng Rule** bằng lệnh mặc định:

```bash
sudo systemctl restart wazuh-manager
```

*(Hoặc sử dụng trình điều khiển gốc của Wazuh: `sudo /var/ossec/bin/wazuh-control restart`)*.
*(Hoàn thành tiêu chí 3: `3_wazuh_rule_configured`)*.

---

### BƯỚC 4: TẤN CÔNG LẠI & XÁC MINH TRANG WEB ĐÃ BỊ CHẶN (TRÊN `student-pc`)

Quay lại cửa sổ terminal của **`student-pc`**, chạy lại đoạn code ghi đè thuộc tính:

```bash
python3 simulate_sso_flow.py
```

Ngay khi sự kiện JSON được gửi về `wazuh-manager`, Rule `100601` sẽ kích hoạt cơ chế **Active Response (`firewall-drop`)**, ra lệnh cho `iptables` trên `sp-server` khóa toàn bộ kết nối từ IP `172.20.0.20` (`student-pc`)! *(Hoàn thành tiêu chí 4: `4_active_response_triggered`)*.

Kiểm tra lại trên trình duyệt Web và Terminal:
- Quay lại cửa sổ trình duyệt **Firefox** (`http://172.20.0.10:5000`) và tải lại trang (**F5**): **Trang web không thể truy cập được nữa (Unable to connect / Connection timed out)**!
- Hoặc kiểm tra bằng `curl -I --connect-timeout 3 http://172.20.0.10:5000`: Kết nối bị chặn hoàn toàn bởi `iptables`!

---

### BƯỚC 5: KIỂM TRA LOG TRÊN WAZUH & CHẤM ĐIỂM `checkwork`

Chuyển sang cửa sổ terminal của **`wazuh-manager`**, đọc tệp log cảnh báo và log lưu trữ bằng lệnh mặc định của Linux:

```bash
cat /var/ossec/logs/alerts/alerts.log
```

```bash
cat /var/ossec/logs/archives/archives.log
```

*(Hoặc theo dõi thời gian thực bằng: `tail -f /var/ossec/logs/alerts/alerts.log`)*.

Bạn sẽ thấy cảnh báo mức 12 (`Rule: 100601 (level 12)`) ghi nhận chi tiết sự kiện `AttributeMismatch|RoleOverride` kèm thông báo kích hoạt Active Response *(Hoàn thành tiêu chí 5: `5_siem_alert_logged`)*.

Tại terminal của máy Host, gõ lệnh chấm điểm kết quả:

```bash
checkwork
```

**Kết quả đạt đủ 5/5 tiêu chí (`Y`):**

```text
Labname saml-attribute-mapping

Student: <email>
 Y -  1_config_probed
 Y -  2_role_override_success
 Y -  3_wazuh_rule_configured
 Y -  4_active_response_triggered
 Y -  5_siem_alert_logged
```
