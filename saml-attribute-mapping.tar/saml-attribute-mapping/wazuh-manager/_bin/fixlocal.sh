#!/bin/bash
# fixlocal.sh for wazuh-manager (172.20.0.30)
grep -q "sp.lab" /etc/hosts 2>/dev/null || echo "172.20.0.10 sp-server sp.lab idp.lab ldap.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "student-pc" /etc/hosts 2>/dev/null || echo "172.20.0.20 student-pc" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "wazuh-manager" /etc/hosts 2>/dev/null || echo "172.20.0.30 wazuh-manager wazuh.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1

mkdir -p /home/ubuntu/Desktop
cat << 'EOF_RULE' > /home/ubuntu/rule_mau.txt
<group name="sso,saml,ldap,">
  <rule id="100601" level="12">
    <decoded_as>json</decoded_as>
    <match>AttributeMismatch|RoleOverride|UnauthorizedAttributeModification</match>
    <description>Critical SSO Federation: Attribute Mismatch or Unauthorized Role Override Detected</description>
    <group>security_audit,identity_verification,</group>
  </rule>
</group>
EOF_RULE
cp -f /home/ubuntu/rule_mau.txt /home/ubuntu/Desktop/rule_mau.txt

cat << 'EOF_GUIDE' > /home/ubuntu/Desktop/HUONG_DAN_WAZUH.txt
================================================================================
HƯỚNG DẪN PHÒNG THỦ TRÊN WAZUH-MANAGER (172.20.0.30) - LỆNH MẶC ĐỊNH CHUẨN
================================================================================
Bước 1: Xem đoạn Rule chuẩn bị sẵn:
        cat ~/rule_mau.txt

Bước 2: Mở file cấu hình rule của Wazuh để dán (hoặc thêm/sửa/xóa):
        sudo nano /var/ossec/etc/rules/local_rules.xml

Bước 3: Khởi động lại dịch vụ Wazuh Manager để áp dụng Rule (Lệnh chuẩn):
        sudo systemctl restart wazuh-manager
        (hoặc: sudo /var/ossec/bin/wazuh-control restart)

Bước 4: Quay sang student-pc chạy lại code tấn công, sau đó kiểm tra log bằng lệnh chuẩn:
        cat /var/ossec/logs/alerts/alerts.log
        cat /var/ossec/logs/archives/archives.log
================================================================================
EOF_GUIDE

sudo chown -R ubuntu:ubuntu /home/ubuntu 2>/dev/null || true
sudo chmod +x /var/ossec/bin/wazuh-control /var/ossec/bin/wazuh-logtest /usr/local/bin/wazuh_manager_daemon.py /etc/rc.local 2>/dev/null || true
sudo /etc/rc.local
echo "[OK] Máy chủ wazuh-manager (172.20.0.30) đã sẵn sàng!"
