# -*- coding: utf-8 -*-
import os, sys

if len(sys.argv) != 3:
    print("Sử dụng: python3 mp3_compressor.py <input.wav> <bitrate>")
    sys.exit(1)

input_file = sys.argv[1]
bitrate = sys.argv[2]
mp3_temp = "temp_channel.mp3"
output_file = "received_audio.wav"

print(f"[!] Đang nén file {input_file} xuống MP3 {bitrate} bằng FFmpeg (Mô phỏng Zalo/FB)...")

# Dọn dẹp file cũ nếu có để tránh lỗi ghi đè
if os.path.exists(mp3_temp): os.remove(mp3_temp)
if os.path.exists(output_file): os.remove(output_file)

# Bước 1: Nén từ WAV sang MP3 để tạo nhiễu kênh truyền
# Dùng lệnh 'ffmpeg' của Linux thay vì 'ffmpeg.exe'
cmd_compress = f"ffmpeg -i {input_file} -b:a {bitrate} {mp3_temp} -loglevel error"
if os.system(cmd_compress) != 0:
    print("[-] LỖI: FFmpeg chưa được cài đặt. Vui lòng chạy lệnh: sudo apt install ffmpeg")
    sys.exit(1)

# Bước 2: Chuyển ngược MP3 về WAV để máy nhận có thể đọc được bằng thư viện scipy
cmd_decompress = f"ffmpeg -i {mp3_temp} {output_file} -loglevel error"
os.system(cmd_decompress)

print(f"[+] Kênh truyền mô phỏng thành công! Đã xuất file cuối cùng: '{output_file}'")
