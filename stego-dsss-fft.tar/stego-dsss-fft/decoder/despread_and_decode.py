# -*- coding: utf-8 -*-
import sys
import numpy as np

if len(sys.argv) != 4:
    print("Sử dụng: python3 despread_and_decode.py extracted_noise.npy <seed> <num_bits>")
    sys.exit(1)

noise = np.load(sys.argv[1])
seed = int(sys.argv[2])
num_bits = int(sys.argv[3])

# 1. Tái tạo PN Sequence y hệt máy gửi
np.random.seed(seed)
band_len = len(noise)
chunk_size = band_len // num_bits

pn_seq = np.random.choice([-1, 1], size=(num_bits, chunk_size))

# 2. Giải mã bằng Tương quan (Correlation)
recovered_bits = []
for i in range(num_bits):
    chunk = noise[i*chunk_size : (i+1)*chunk_size]
    correlation = np.dot(chunk, pn_seq[i])
    # Tương quan dương là bit 1, âm là bit 0
    recovered_bits.append(1 if correlation > 0 else 0)

# 3. Ghép bit thành chữ
chars = []
for i in range(0, len(recovered_bits), 8):
    byte = recovered_bits[i:i+8]
    chars.append(chr(int("".join(map(str, byte)), 2)))

print(f"[+] Bit khôi phục : {recovered_bits}")
print(f"[+] THÔNG ĐIỆP GỐC: '{''.join(chars)}'")
