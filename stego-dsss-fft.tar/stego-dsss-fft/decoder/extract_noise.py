# -*- coding: utf-8 -*-
import os, sys
try:
    import numpy as np
    import scipy
except ImportError:
    os.system("python3 -m pip install --index-url https://pypi.org/simple/ numpy scipy")
    os.execv(sys.executable, ['python3'] + sys.argv)

from scipy.io import wavfile
from scipy import signal
from numpy.fft import rfft

if len(sys.argv) != 3:
    print("Sử dụng: python3 extract_noise.py received_audio.wav cover_audio.wav")
    sys.exit(1)

fs, rec_sig = wavfile.read(sys.argv[1])
_, cov_sig = wavfile.read(sys.argv[2])

# Lấy chiều dài chuẩn của file gốc để làm hệ quy chiếu FFT
orig_len = len(cov_sig)
print("[!] Đang xử lý đồng bộ thời gian tín hiệu để bù trừ nhiễu MP3...")
chunk = min(fs, orig_len, len(rec_sig))

# Tính toán tương quan chéo bằng FFT
corr = signal.correlate(rec_sig[:chunk].astype(float), cov_sig[:chunk].astype(float), mode='full', method='fft')
delay = np.argmax(corr) - chunk + 1

# FIX CHÍ MẠNG: Căn chỉnh tín hiệu nhận (rec_sig) nhưng PHẢI BÙ ZERO để giữ nguyên N
if delay > 0:
    rec_aligned = rec_sig[delay:]
    if len(rec_aligned) < orig_len:
        rec_aligned = np.pad(rec_aligned, (0, orig_len - len(rec_aligned)), 'constant')
    else:
        rec_aligned = rec_aligned[:orig_len]
elif delay < 0:
    rec_aligned = np.pad(rec_sig, (-delay, 0), 'constant')
    rec_aligned = rec_aligned[:orig_len]
else:
    rec_aligned = rec_sig[:orig_len]
    if len(rec_aligned) < orig_len:
        rec_aligned = np.pad(rec_aligned, (0, orig_len - len(rec_aligned)), 'constant')

print(f"[!] Độ trễ MP3: {delay} samples. Đã đồng bộ và ÉP GIỮ NGUYÊN {orig_len} khung FFT!")

# Vì length 2 mảng giờ bằng nhau tuyệt đối, các bin FFT sẽ khớp 100%
Y_freq = rfft(rec_aligned)
X_freq = rfft(cov_sig)

freq_bins = np.fft.rfftfreq(orig_len, 1/fs)
idx_min, idx_max = np.argmax(freq_bins > 1000), np.argmax(freq_bins > 4000)

noise = np.abs(Y_freq[idx_min:idx_max]) - np.abs(X_freq[idx_min:idx_max])
np.save('extracted_noise.npy', noise)
print("[+] Đã trích xuất ma trận nhiễu. Lưu tại extracted_noise.npy")
