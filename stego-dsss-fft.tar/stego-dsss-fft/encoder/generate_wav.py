# -*- coding: utf-8 -*-
import os, sys
try:
    import numpy as np
    import scipy
except ImportError:
    print("[!] HỆ THỐNG: Đang tự động nạp thư viện toán học cho lần chạy đầu tiên...")
    os.system("python3 -m pip install --index-url https://pypi.org/simple/ numpy scipy")
    os.execv(sys.executable, ['python3'] + sys.argv)

from scipy.io import wavfile

print("[!] Đang tạo file âm thanh cover_audio.wav có phổ nền dày (5 giây)...")
# Khai báo các tham số âm thanh cơ bản
sample_rate = 44100
duration = 5.0
t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
# Tạo tín hiệu đa tần kèm nhiễu trắng bảo vệ phổ
signal = 0.5 * np.sin(2 * np.pi * 440 * t) + 0.2 * np.sin(2 * np.pi * 880 * t)
noise = np.random.normal(0, 0.05, signal.shape)
cover_audio = np.clip(signal + noise, -1.0, 1.0)
# Xuất file wav dạng 16-bit PCM
wavfile.write('cover_audio.wav', sample_rate, (cover_audio * 32767).astype(np.int16))
print("[+] Đã tái tạo file 'cover_audio.wav' thành công!")
