# -*- coding: utf-8 -*-
import os, sys
try:
    import numpy as np
except ImportError:
    os.system("python3 -m pip install --index-url https://pypi.org/simple/ numpy scipy")
    os.execv(sys.executable, ['python3'] + sys.argv)

from scipy.io import wavfile
from numpy.fft import irfft

if len(sys.argv) != 2:
    print("Sử dụng: python3 ifft_transform.py <input_spectrum.npz>")
    sys.exit(1)

data = np.load(sys.argv[1])
X_stego = data['X_stego']
fs = data['fs']

# KHẮC PHỤC LỖI CHÍ MẠNG: Dùng np.clip để chống lộn vòng (wrap-around) bảo vệ phổ FFT
raw_signal = irfft(X_stego)
stego_signal = np.clip(raw_signal, -32768, 32767).astype(np.int16)

wavfile.write('stego_audio.wav', fs, stego_signal)
print(f"[+] Đã khôi phục thành miền thời gian an toàn. Lưu tại stego_audio.wav")
