# -*- coding: utf-8 -*-
import os, sys
try:
    import numpy as np
    import scipy
except ImportError:
    print("[!] HỆ THỐNG: Đang tự động nạp thư viện toán học cho lần chạy đầu tiên...")
    os.system("python3 -m pip install --index-url https://pypi.org/simple/ numpy scipy")
    os.execv(sys.executable, ['python3'] + sys.argv)

from scipy.io import wavfile
# Chuyển rfft sang dùng của numpy.fft để tránh lỗi không tìm thấy module trên SciPy bản cũ
from numpy.fft import rfft

if len(sys.argv) != 2:
    print("Sử dụng: python3 fft_transform.py <input_audio.wav>")
    sys.exit(1)

input_file = sys.argv[1]
fs, cover_signal = wavfile.read(input_file)
if len(cover_signal.shape) > 1:
    cover_signal = cover_signal[:, 0]  # Chuyển về Mono nếu là file Stereo

X_freq = rfft(cover_signal)
# Lưu lại tần số lấy mẫu (fs) và ma trận FFT để bước sau dùng
np.savez('spectrum_data.npz', fs=fs, X_freq=X_freq, length=len(cover_signal))
print(f"[+] Đã chuyển {input_file} sang miền tần số. Lưu tại spectrum_data.npz")
