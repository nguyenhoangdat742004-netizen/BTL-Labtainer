# -*- coding: utf-8 -*-
import sys
import numpy as np

if len(sys.argv) != 5:
    print("Sử dụng: python3 spread_and_embed.py spectrum_data.npz <message> <seed> <alpha>")
    sys.exit(1)

data = np.load(sys.argv[1])
X_freq = data['X_freq']
fs = data['fs']
message = sys.argv[2]
seed = int(sys.argv[3])
# Tự động khuếch đại alpha để sống sót qua nén MP3
alpha = float(sys.argv[4]) * 500  

# 1. Chuyển chữ thành bit và biến đổi Bipolar (0 -> -1, 1 -> 1)
bits = [int(b) for char in message for b in format(ord(char), '08b')]
bipolar_msg = np.array(bits) * 2 - 1

# 2. Tạo PN Sequence
np.random.seed(seed)
freq_bins = np.fft.rfftfreq(int(data['length']), 1/fs)
idx_min, idx_max = np.argmax(freq_bins > 1000), np.argmax(freq_bins > 4000)

band_len = idx_max - idx_min
chunk_size = band_len // len(bits)
actual_len = chunk_size * len(bits)

pn_seq = np.random.choice([-1, 1], size=(len(bits), chunk_size))
spread_signal = np.zeros(actual_len)

for i, bit in enumerate(bipolar_msg):
    spread_signal[i*chunk_size : (i+1)*chunk_size] = bit * pn_seq[i]

# 3. FIX CHÍ MẠNG: Nhúng vào Biên độ (Magnitude), giữ nguyên Pha (Phase)
magnitudes = np.abs(X_freq)
phases = np.angle(X_freq)

magnitudes[idx_min:idx_min + actual_len] += alpha * spread_signal

# Khôi phục số phức từ biên độ đã giấu tin và pha gốc
X_stego = magnitudes * np.exp(1j * phases)

np.savez('stego_spectrum.npz', X_stego=X_stego, fs=fs, length=data['length'])
print(f"[+] Đã nhúng '{message}' (seed={seed}, alpha scale={alpha}). Lưu tại stego_spectrum.npz")
