import numpy as np
import soundfile as sf
import sys

def extract_message(stego_file, seed):
    stego, fs = sf.read(stego_file)
    cover, _ = sf.read('cover_audio.wav')

    alpha = 0.05
    start_idx = 5000
    
    # Đọc lại metadata để biết chiều dài cấu trúc bit
    data = np.load('spread_data.npz')
    chip_rate = data['chip_rate']
    num_bits = data['length']
    
    end_idx = start_idx + num_bits * chip_rate
    
    # Bóc tách ma trận hỗn hợp nhiễu
    extracted_mixed = (stego[start_idx:end_idx] - cover[start_idx:end_idx]) / alpha

    # Sinh mã PN dựa trên Seed người dùng cung cấp
    np.random.seed(seed)
    pn_sequence = np.random.choice([-1, 1], size=len(extracted_mixed))

    # Giải trải phổ (Despreading)
    recovered_bits = []
    for i in range(num_bits):
        chunk = extracted_mixed[i*chip_rate : (i+1)*chip_rate]
        pn_chunk = pn_sequence[i*chip_rate : (i+1)*chip_rate]
        
        correlation = np.sum(chunk * pn_chunk)
        # Nếu khóa sai, correlation sẽ tiệm cận 0 (nhiễu). Nếu đúng, nó nhảy vọt lên cao.
        recovered_bits.append(1 if correlation > 0 else 0)

    # Dịch bit nhị phân ngược lại thành Text ASCII
    chars = []
    for i in range(0, len(recovered_bits), 8):
        byte = recovered_bits[i:i+8]
        byte_str = ''.join(str(b) for b in byte)
        chars.append(chr(int(byte_str, 2)))
        
    # Lọc bỏ các ký tự null do padding lúc mã hóa
    message = ''.join([c for c in chars if c.isprintable()])
    
    print(f"[+] Kênh {seed} khôi phục: '{message}'")

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Sử dụng: python3 step4_extract.py <stego_file> <seed>")
        sys.exit(1)
        
    stego_file = sys.argv[1]
    seed = int(sys.argv[2])
    extract_message(stego_file, seed)