import numpy as np
import argparse

def generate_keys():
    parser = argparse.ArgumentParser(description="Khởi tạo mã Seed cho CDMA")
    parser.add_argument('--seed1', type=int, required=True, help="Khóa Seed đài 1")
    parser.add_argument('--seed2', type=int, required=True, help="Khóa Seed đài 2")
    args = parser.parse_args()

    # Lưu trữ thông tin khóa vào một dictionary để các bước sau sử dụng
    keys = {'seed1': args.seed1, 'seed2': args.seed2}
    np.save('cdma_keys.npy', keys)
    
    print(f"[+] Đã tạo và lưu trữ khóa CDMA: Kênh Alpha (Seed={args.seed1}), Kênh Bravo (Seed={args.seed2})")

if __name__ == '__main__':
    generate_keys()