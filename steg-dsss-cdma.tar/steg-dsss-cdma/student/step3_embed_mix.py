import numpy as np
import soundfile as sf
import os
import sys

def create_dummy_cover(filename='cover_audio.wav'):
    fs = 44100
    t = np.linspace(0, 3, fs * 3) # File âm thanh nền dài 3 giây
    # Tạo tiếng nhạc nền đơn giản (sóng sine 440Hz + nhiễu trắng nhẹ)
    cover = 0.1 * np.sin(2 * np.pi * 440 * t) + 0.02 * np.random.randn(len(t))
    sf.write(filename, cover, fs)
    print(f"[*] Đã tự động tạo file sóng mang: {filename}")

def embed_mix():
    if not os.path.exists('cover_audio.wav'):
        create_dummy_cover()

    cover, fs = sf.read('cover_audio.wav')
    data = np.load('spread_data.npz')
    spread1, spread2 = data['spread1'], data['spread2']

    # KỸ THUẬT CDMA: Cộng dồn (Multiplex) cả hai luồng tín hiệu vào cùng một biến
    mixed_signal = spread1 + spread2
    
    alpha = 0.05 # Biên độ khuếch đại ẩn
    start_idx = 5000
    end_idx = start_idx + len(mixed_signal)

    if end_idx > len(cover):
        print("[-] Lỗi: Dung lượng file âm thanh quá ngắn so với độ dài thông điệp!")
        sys.exit(1)

    # Chèn tín hiệu đã Mix vào sóng âm
    stego = np.copy(cover)
    stego[start_idx:end_idx] += alpha * mixed_signal

    sf.write('stego_mixed.wav', stego, fs)
    print("[+] Kịch bản CDMA hoàn tất: Đã trộn tín hiệu của 2 đặc vụ và nhúng vào 'stego_mixed.wav'")

if __name__ == '__main__':
    embed_mix()