import numpy as np
import sys

def text_to_symbols(text):
    bits = ''.join(format(ord(c), '08b') for c in text)
    return np.array([1 if b == '1' else -1 for b in bits])

def spread_multi(msg1, msg2):
    keys = np.load('cdma_keys.npy', allow_pickle=True).item()
    seed1, seed2 = keys['seed1'], keys['seed2']
    
    sym1 = text_to_symbols(msg1)
    sym2 = text_to_symbols(msg2)
    
    chip_rate = 256 # Hệ số trải phổ lớn để tăng tính trực giao
    max_len = max(len(sym1), len(sym2))
    
    # Padding (đệm thêm bit -1) nếu 2 thông điệp dài ngắn khác nhau
    if len(sym1) < max_len:
        sym1 = np.pad(sym1, (0, max_len - len(sym1)), constant_values=-1)
    if len(sym2) < max_len:
        sym2 = np.pad(sym2, (0, max_len - len(sym2)), constant_values=-1)

    # Khởi tạo mã PN cho đài Alpha
    np.random.seed(seed1)
    pn1 = np.random.choice([-1, 1], size=max_len * chip_rate)
    
    # Khởi tạo mã PN cho đài Bravo
    np.random.seed(seed2)
    pn2 = np.random.choice([-1, 1], size=max_len * chip_rate)

    # Nhân symbol với chuỗi PN
    spread1 = np.repeat(sym1, chip_rate) * pn1
    spread2 = np.repeat(sym2, chip_rate) * pn2

    np.savez('spread_data.npz', spread1=spread1, spread2=spread2, chip_rate=chip_rate, length=max_len)
    print(f"[+] Đã trải phổ thành công 2 thông điệp: '{msg1}' và '{msg2}'.")

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Sử dụng: python3 step2_spread_multi.py <msg1> <msg2>")
        sys.exit(1)
    spread_multi(sys.argv[1], sys.argv[2])