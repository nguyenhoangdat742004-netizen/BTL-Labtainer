#!/bin/bash
echo "=== KIỂM TRA KẾT NỐI MẠNG ĐẾN CÁC MÁY CHỦ TRONG BÀI LAB ==="
echo "1. Ping sp-server (172.20.0.10)..."
ping -c 2 172.20.0.10 || echo "[-] KHÔNG THỂ PING SP-SERVER (Có thể IP đã bị Active Response chặn!)"

echo ""
echo "2. Kiểm tra dịch vụ Service Provider Portal (Port 5000)..."
curl -I -s --connect-timeout 3 http://172.20.0.10:5000 | head -n 3 || echo "[-] KHÔNG THỂ KẾT NỐI PORT 5000 (Đã bị chặn bởi iptables firewall-drop!)"

echo ""
echo "3. Kiểm tra dịch vụ Keycloak IdP (Port 8080)..."
curl -I -s --connect-timeout 3 http://172.20.0.10:8080 | head -n 3 || echo "[-] KHÔNG THỂ KẾT NỐI PORT 8080"

echo ""
echo "4. Ping wazuh-manager (172.20.0.30)..."
ping -c 2 172.20.0.30
