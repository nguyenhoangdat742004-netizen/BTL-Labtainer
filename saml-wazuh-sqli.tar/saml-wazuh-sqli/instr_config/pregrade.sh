#!/bin/bash
# Pregrade script for saml-wazuh-sqli
homedir=$1
destdir=$2
cd $homedir/$destdir 2>/dev/null || true
