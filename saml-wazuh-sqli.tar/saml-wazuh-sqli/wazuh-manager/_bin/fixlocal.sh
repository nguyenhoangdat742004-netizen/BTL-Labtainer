#!/bin/bash
# ==============================================================================
# fixlocal.sh for wazuh-manager (saml-wazuh-sqli)
# ==============================================================================

# 1. Cấu hình /etc/hosts
grep -q "$(hostname)" /etc/hosts 2>/dev/null || echo "127.0.0.1 $(hostname)" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "sp.lab" /etc/hosts 2>/dev/null || echo "172.20.0.10 sp-server sp.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "student-pc" /etc/hosts 2>/dev/null || echo "172.20.0.20 student-pc" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "wazuh.lab" /etc/hosts 2>/dev/null || echo "172.20.0.30 wazuh-manager wazuh.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1

# 2. Khởi tạo thư mục và phân quyền
sudo mkdir -p /var/ossec/logs/alerts /var/ossec/logs/archives /var/ossec/etc/rules /var/ossec/etc/decoders
sudo touch /var/ossec/logs/alerts/alerts.log /var/ossec/logs/archives/archives.log
sudo chmod -R 777 /var/ossec/logs /var/ossec/etc/rules /var/ossec/etc/decoders

# 3. Tạo hướng dẫn nhanh trên Desktop của wazuh-manager
mkdir -p /home/ubuntu/Desktop
cat << 'EOF_GUIDE' > /home/ubuntu/Desktop/HUONG_DAN_BLUE_TEAM.txt
================================================================================
NHIỆM VỤ PHÒNG THỦ BLUE TEAM TRÊN WAZUH-MANAGER
================================================================================

🎯 MỤC TIÊU:
1. Viết Custom Decoder (nếu cần) và Custom Rule trong tệp:
   /var/ossec/etc/rules/local_rules.xml
   để phát hiện đòn tấn công SQL Injection (các từ khóa: UNION, SELECT, --).

2. Sau khi lưu rule, chạy lệnh:
   check_rules
   để kiểm tra cú pháp và kích hoạt trạng thái rule.

3. Khi kẻ tấn công gửi payload SQLi, hệ thống sẽ kích hoạt Active Response
   lệnh cho sp-server chạy firewall-drop chặn IP 172.20.0.20!

4. Xem cảnh báo:
   view_alerts
   view_archives
================================================================================
EOF_GUIDE
chown -R ubuntu:ubuntu /home/ubuntu/Desktop

# 4. Cấu hình /etc/rc.local tự khởi động wazuh_manager_daemon qua mọi lần restart
sudo tee /etc/rc.local > /dev/null << 'EOF_RC'
#!/bin/bash
mkdir -p /var/ossec/logs/alerts /var/ossec/logs/archives /var/ossec/etc/rules /var/ossec/etc/decoders
touch /var/ossec/logs/alerts/alerts.log /var/ossec/logs/archives/archives.log
chmod -R 777 /var/ossec/logs /var/ossec/etc/rules /var/ossec/etc/decoders

pkill -f "/usr/local/bin/wazuh_manager_daemon.py" 2>/dev/null || true
nohup python3 /usr/local/bin/wazuh_manager_daemon.py > /var/ossec/logs/manager_service.log 2>&1 &
exit 0
EOF_RC
sudo chmod +x /etc/rc.local
sudo systemctl restart rc-local.service 2>/dev/null || /etc/rc.local

# Khởi động dịch vụ Wazuh Manager nếu có
if [ -f /var/ossec/bin/wazuh-control ]; then
    sudo /var/ossec/bin/wazuh-control start 2>/dev/null || true
fi

echo "[THÀNH CÔNG] Máy chủ wazuh-manager đã sẵn sàng giám sát và điều khiển Active Response!"
