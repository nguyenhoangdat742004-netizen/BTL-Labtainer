#!/bin/bash
# ==============================================================================
# fixlocal.sh for sp-server (saml-wazuh-sqli)
# ==============================================================================

# 1. Cấu hình /etc/hosts
grep -q "$(hostname)" /etc/hosts 2>/dev/null || echo "127.0.0.1 $(hostname)" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "sp.lab" /etc/hosts 2>/dev/null || echo "172.20.0.10 sp-server sp.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "student-pc" /etc/hosts 2>/dev/null || echo "172.20.0.20 student-pc" | sudo tee -a /etc/hosts >/dev/null 2>&1
grep -q "wazuh.lab" /etc/hosts 2>/dev/null || echo "172.20.0.30 wazuh-manager wazuh.lab" | sudo tee -a /etc/hosts >/dev/null 2>&1

# 2. Thiết lập thư mục và quyền ghi log
sudo mkdir -p /var/log/sp-portal /var/ossec/logs /var/ossec/etc /var/ossec/active-response/bin
sudo touch /var/log/sp-portal/app.json /var/log/sp-portal/sqli.log /var/log/sp-portal/auth.log /var/ossec/logs/active-responses.log
sudo chmod -R 777 /var/log/sp-portal /var/ossec/logs
sudo chmod 666 /var/ossec/logs/active-responses.log
sudo chown -R ubuntu:ubuntu /opt/sp-portal /opt/keycloak-idp 2>/dev/null || true

# 3. Đảm bảo quyền thực thi cho script active response
sudo chmod +x /var/ossec/active-response/bin/firewall-drop 2>/dev/null || true

# 4. Cấu hình Wazuh Agent client.keys
sudo tee /var/ossec/etc/client.keys > /dev/null << 'EOF_KEYS'
001 sp-server 172.20.0.10 b3a2f9c8e1d7a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9
EOF_KEYS
sudo chmod 640 /var/ossec/etc/client.keys
sudo chown root:wazuh /var/ossec/etc/client.keys 2>/dev/null || true

# 5. Cài đặt script tự khởi động qua /etc/rc.local (đảm bảo tồn tại qua mọi lần restart)
sudo tee /etc/rc.local > /dev/null << 'EOF_RC'
#!/bin/bash
mkdir -p /var/log/sp-portal /var/ossec/logs /var/ossec/etc /var/ossec/active-response/bin
touch /var/log/sp-portal/app.json /var/log/sp-portal/sqli.log /var/log/sp-portal/auth.log /var/ossec/logs/active-responses.log
chmod -R 777 /var/log/sp-portal /var/ossec/logs
chmod 666 /var/ossec/logs/active-responses.log
chown -R ubuntu:ubuntu /opt/sp-portal /opt/keycloak-idp 2>/dev/null || true
chmod +x /var/ossec/active-response/bin/firewall-drop 2>/dev/null || true

pkill -f "/opt/keycloak-idp/app.py" 2>/dev/null || true
pkill -f "/opt/sp-portal/app.py" 2>/dev/null || true
pkill -f "/opt/sp-portal/ar_bridge.py" 2>/dev/null || true

nohup python3 /opt/keycloak-idp/app.py > /var/log/sp-portal/idp.log 2>&1 &
nohup python3 /opt/sp-portal/app.py > /var/log/sp-portal/sp.log 2>&1 &
nohup python3 /opt/sp-portal/ar_bridge.py > /var/log/sp-portal/ar_bridge.log 2>&1 &
exit 0
EOF_RC
sudo chmod +x /etc/rc.local
sudo systemctl restart rc-local.service 2>/dev/null || /etc/rc.local

# Khởi động Wazuh Agent nếu có
if [ -f /var/ossec/bin/wazuh-control ]; then
    sudo /var/ossec/bin/wazuh-control start 2>/dev/null || true
fi

echo "[THÀNH CÔNG] sp-server đã khởi động IdP (Port 8080), SP Portal (Port 5000), và Wazuh Agent / AR Bridge!"
