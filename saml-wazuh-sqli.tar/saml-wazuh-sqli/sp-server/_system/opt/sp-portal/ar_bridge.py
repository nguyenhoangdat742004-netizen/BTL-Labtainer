#!/usr/bin/env python3
"""
Active Response Bridge & Log Forwarder for sp-server
Lab: saml-wazuh-sqli
"""
import os
import sys
import time
import socket
import subprocess
import json

AR_SCRIPT = "/var/ossec/active-response/bin/firewall-drop"
MANAGER_IP = "172.20.0.30"
MANAGER_RULES_PATH = "/var/ossec/etc/rules/local_rules.xml"
SQLI_LOG = "/var/log/sp-portal/sqli.log"
APP_JSON_LOG = "/var/log/sp-portal/app.json"

def trigger_active_response(attacker_ip="172.20.0.20", rule_id="100201"):
    try:
        cmd = [AR_SCRIPT, "add", "-", attacker_ip, str(int(time.time())), rule_id]
        subprocess.run(cmd, check=True)
        print(f"[ACTIVE-RESPONSE] Executed firewall-drop for IP: {attacker_ip}", flush=True)
    except Exception as e:
        print(f"[-] Error executing active response: {e}", flush=True)

def forward_log_to_manager(json_line):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(json_line.encode('utf-8'), (MANAGER_IP, 514))
        sock.close()
    except Exception:
        pass

def check_rule_on_manager():
    """Kiểm tra máy chủ wazuh-manager xem sinh viên đã viết rule SQLi hay chưa"""
    try:
        # Gửi tín hiệu thăm dò tới wazuh-manager cổng 5515
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(2.0)
        s.connect((MANAGER_IP, 5515))
        s.sendall(b"CHECK_RULE\n")
        resp = s.recv(1024).decode('utf-8').strip()
        s.close()
        return resp == "RULE_ACTIVE"
    except Exception:
        return False

def main():
    print("[*] AR Bridge service started on sp-server...", flush=True)
    
    # 1. Thread / socket lắng nghe lệnh kích hoạt AR từ wazuh-manager trên UDP 5514
    udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_sock.bind(("0.0.0.0", 5514))
    udp_sock.setblocking(False)

    last_pos = 0
    if os.path.exists(APP_JSON_LOG):
        last_pos = os.path.getsize(APP_JSON_LOG)

    while True:
        try:
            # Kiểm tra lệnh AR trực tiếp từ Manager qua UDP
            try:
                data, addr = udp_sock.recvfrom(2048)
                msg = data.decode('utf-8').strip()
                if "BLOCK" in msg:
                    parts = msg.split()
                    ip = parts[1] if len(parts) > 1 else "172.20.0.20"
                    rule = parts[2] if len(parts) > 2 else "100201"
                    trigger_active_response(ip, rule)
            except BlockingIOError:
                pass

            # Đọc tiếp log JSON mới sinh ra và đẩy sang manager
            if os.path.exists(APP_JSON_LOG):
                curr_size = os.path.getsize(APP_JSON_LOG)
                if curr_size > last_pos:
                    with open(APP_JSON_LOG, 'r') as f:
                        f.seek(last_pos)
                        new_lines = f.readlines()
                        last_pos = f.tell()
                    for line in new_lines:
                        line_str = line.strip()
                        if line_str:
                            forward_log_to_manager(line_str)
                            # Nếu có SQLi và Rule đã được tạo trên Manager -> Kích hoạt AR ngay lập tức
                            if any(k in line_str.upper() for k in ['UNION', 'SELECT', '--']):
                                if check_rule_on_manager():
                                    print("[*] SQLi detected AND Rule active on Manager -> Triggering Active Response!", flush=True)
                                    trigger_active_response("172.20.0.20", "100201")

        except Exception as e:
            print(f"[-] AR Bridge loop exception: {e}", flush=True)

        time.sleep(1.0)

if __name__ == '__main__':
    main()
