#!/usr/bin/env python3
"""
Enterprise Cloud Service Provider (SP) - SAML 2.0 SSO Portal
Lab: saml-wazuh-sqli
Chạy trên port 5000, nhận gói tin SAMLResponse tại /saml/acs.
Lỗ hổng: SAML NameID SQL Injection (CWE-89)
Bảo vệ: Wazuh SIEM & Active Response (firewall-drop via iptables)
"""

import os
import sys
import json
import base64
import sqlite3
import datetime
from flask import Flask, request, redirect, session, render_template_string, jsonify, Response
from lxml import etree

# Monkeypatch các curve ECDSA đã bị cryptography 43+ loại bỏ để tương thích với signxml
from cryptography.hazmat.primitives.asymmetric import ec
for curve in ['SECT163K1', 'SECT233K1', 'SECT233R1', 'SECT283R1', 'SECT409K1', 'SECT409R1', 'SECT571K1', 'SECP192R1', 'SECP224R1']:
    if not hasattr(ec, curve):
        setattr(ec, curve, ec.SECP256R1)

import signxml

app = Flask(__name__)
app.secret_key = 'SAML_WAZUH_SQLI_SECRET_KEY_2026'

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_FILE = os.path.join(BASE_DIR, 'database.db')
SAML_DIR = os.path.join(BASE_DIR, 'saml')
IDP_CERT_FILE = os.path.join(SAML_DIR, 'idp_cert.crt')
IDP_KEY_FILE = os.path.join(SAML_DIR, 'idp_private.key')

APP_JSON_LOG = '/var/log/sp-portal/app.json'
SQLI_LOG = '/var/log/sp-portal/sqli.log'
AUTH_LOG = '/var/log/sp-portal/auth.log'

def write_json_log(data_dict):
    """Ghi log định dạng JSON phục vụ Wazuh Agent thu thập"""
    os.makedirs(os.path.dirname(APP_JSON_LOG), exist_ok=True)
    with open(APP_JSON_LOG, 'a') as f:
        f.write(json.dumps(data_dict) + '\n')
        f.flush()

def write_sqli_log(message):
    """Ghi log sự kiện SQL Injection cho mục tiêu đánh giá tự động (Goal 1)"""
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    os.makedirs(os.path.dirname(SQLI_LOG), exist_ok=True)
    with open(SQLI_LOG, 'a') as f:
        f.write(f"{ts} sp-server {message}\n")
        f.flush()

def write_auth_log(message):
    ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    os.makedirs(os.path.dirname(AUTH_LOG), exist_ok=True)
    with open(AUTH_LOG, 'a') as f:
        f.write(f"{ts} sp-server {message}\n")
        f.flush()

# ==============================================================================
# GIAO DIỆN CHUẨN DOANH NGHIỆP THỰC TẾ (ENTERPRISE CORPORATE PORTAL)
# ==============================================================================
BASE_TEMPLATE = """<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ title }} - Enterprise Cloud Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #1e293b; min-height: 100vh; display: flex; flex-direction: column; }
        .navbar-custom { background: #ffffff; border-bottom: 1px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
        .card-custom { border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.03); background: #ffffff; }
        .btn-primary { background-color: #2563eb; border-color: #2563eb; font-weight: 500; }
        .btn-primary:hover { background-color: #1d4ed8; border-color: #1d4ed8; }
        footer { margin-top: auto; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-custom py-3 px-4">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold text-primary" href="/">
            <i class="fa-solid fa-cloud-bolt fa-lg"></i>
            <span>Enterprise Cloud Portal</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navContent">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-4">
                <li class="nav-item"><a class="nav-link active fw-medium" href="/">Trang chủ</a></li>
                <li class="nav-item"><a class="nav-link text-secondary" href="#">Dịch vụ nội bộ</a></li>
                <li class="nav-item"><a class="nav-link text-secondary" href="#">Nhân sự</a></li>
                <li class="nav-item"><a class="nav-link text-secondary" href="#">Hỗ trợ kỹ thuật</a></li>
            </ul>
            <div class="d-flex align-items-center gap-3">
                {% if session.get('user') %}
                <span class="badge bg-light text-dark border px-3 py-2 rounded-pill">
                    <i class="fa-solid fa-circle-user text-primary me-1"></i> {{ session.get('user') }}
                </span>
                <a href="/logout" class="btn btn-outline-danger btn-sm px-3">Đăng xuất</a>
                {% else %}
                <a href="/saml/login" class="btn btn-primary btn-sm px-3">
                    <i class="fa-solid fa-right-to-bracket me-1"></i> Đăng nhập SAML SSO
                </a>
                {% endif %}
            </div>
        </div>
    </div>
</nav>

<main class="flex-grow-1 py-4">
    <div class="container">
        {% block content %}{% endblock %}
    </div>
</main>

<footer class="py-4 text-center text-muted small border-top bg-white">
    <div class="container">
        <span>&copy; 2026 Enterprise Cloud Services. Tất cả quyền được bảo lưu. Xác thực Single Sign-On (SAML 2.0).</span>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>"""

INDEX_PAGE = BASE_TEMPLATE.replace('{% block content %}{% endblock %}', """
<div class="row justify-content-center">
    <div class="col-lg-10">
        <!-- Hero Banner -->
        <div class="card card-custom p-5 mb-4 text-center bg-white">
            <div class="mx-auto mb-3 text-primary" style="font-size: 3rem;">
                <i class="fa-solid fa-shield-halved"></i>
            </div>
            <h2 class="fw-bold text-dark mb-2">Cổng Quản Trị & Dịch Vụ Doanh Nghiệp</h2>
            <p class="text-secondary mx-auto mb-4" style="max-width: 650px;">
                Hệ thống xác thực tập trung bảo vệ tài nguyên nội bộ, hồ sơ nhân viên và dữ liệu bảo mật thông qua chuẩn Single Sign-On (SAML 2.0).
            </p>
            <div>
                <a href="/saml/login" class="btn btn-primary px-4 py-2 rounded-3 shadow-sm">
                    <i class="fa-solid fa-lock me-2"></i>Đăng nhập với SAML SSO
                </a>
            </div>
        </div>

        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="card card-custom p-4 h-100">
                    <div class="text-primary fs-3 mb-2"><i class="fa-solid fa-users-gear"></i></div>
                    <h6 class="fw-bold mb-1">Hồ Sơ Nhân Sự</h6>
                    <p class="text-muted small mb-0">Quản lý và tra cứu thông tin cá nhân, chức vụ và phòng ban trong tổ chức.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-custom p-4 h-100">
                    <div class="text-success fs-3 mb-2"><i class="fa-solid fa-key"></i></div>
                    <h6 class="fw-bold mb-1">Xác Thực Tập Trung</h6>
                    <p class="text-muted small mb-0">Tích hợp giao thức SAML 2.0 với Identity Provider (IdP) đảm bảo đăng nhập một lần an toàn.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-custom p-4 h-100">
                    <div class="text-info fs-3 mb-2"><i class="fa-solid fa-database"></i></div>
                    <h6 class="fw-bold mb-1">Bảo Mật Dữ Liệu</h6>
                    <p class="text-muted small mb-0">Bảo vệ các tài nguyên và thông tin nhạy cảm của hệ thống doanh nghiệp.</p>
                </div>
            </div>
        </div>

        <!-- Trạm Tiếp Nhận Vé Xác Thực SAML (Assertion Consumer Service) -->
        <div class="card card-custom p-4">
            <div class="d-flex align-items-center justify-content-between mb-3 border-bottom pb-2">
                <h6 class="fw-bold text-dark mb-0">
                    <i class="fa-solid fa-id-card text-primary me-2"></i>Tiếp nhận xác thực SAML Assertion (ACS Endpoint: /saml/acs)
                </h6>
                <span class="badge bg-light text-muted border">POST Form / API</span>
            </div>
            <p class="text-muted small mb-3">
                Nhập định danh người dùng (SAML NameID) để tra cứu hồ sơ tài khoản từ cơ sở dữ liệu:
            </p>
            <form action="/saml/acs" method="POST">
                <input type="hidden" name="direct_test" value="true">
                <div class="input-group">
                    <span class="input-group-text bg-light text-secondary"><i class="fa-solid fa-user"></i></span>
                    <input type="text" id="nameid_input" name="raw_nameid" class="form-control font-monospace" placeholder="Nhập tên người dùng hoặc SAML NameID (ví dụ: victim)" value="victim" required>
                    <button type="submit" class="btn btn-primary px-4">
                        <i class="fa-solid fa-magnifying-glass me-1"></i> Xác thực & Tra cứu
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
""")

DASHBOARD_PAGE = BASE_TEMPLATE.replace('{% block content %}{% endblock %}', """
<div class="row justify-content-center">
    <div class="col-lg-10">
        <!-- User Info Card -->
        <div class="card card-custom p-4 mb-4">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                <div class="d-flex align-items-center gap-3">
                    <div class="bg-primary-subtle text-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 54px; height: 54px; font-size: 1.5rem;">
                        <i class="fa-solid fa-user-check"></i>
                    </div>
                    <div>
                        <h4 class="fw-bold mb-1">Hồ Sơ Tài Khoản Doanh Nghiệp</h4>
                        <div class="d-flex align-items-center gap-2">
                            <span class="text-secondary small">Tài khoản xác thực:</span>
                            <span class="badge bg-light text-dark border font-monospace">{{ session.get('user') }}</span>
                            <span class="badge bg-success-subtle text-success border border-success-subtle ms-2">
                                <i class="fa-solid fa-check me-1"></i> SAML SSO Authenticated
                            </span>
                        </div>
                    </div>
                </div>
                <div>
                    <a href="/" class="btn btn-outline-secondary btn-sm px-3 me-2">
                        <i class="fa-solid fa-arrow-left me-1"></i> Trang chủ
                    </a>
                    <a href="/logout" class="btn btn-outline-danger btn-sm px-3">
                        <i class="fa-solid fa-right-from-bracket me-1"></i> Đăng xuất
                    </a>
                </div>
            </div>
        </div>

        <!-- Data Table Card -->
        <div class="card card-custom p-4 mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold text-dark mb-0">
                    <i class="fa-solid fa-address-book text-primary me-2"></i>Dữ Liệu Hồ Sơ Trích Xuất
                </h5>
                <span class="text-muted small">Tổng số bản ghi: <strong>{{ rows|length }}</strong></span>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle border mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="py-3">Tên tài khoản (Username)</th>
                            <th class="py-3">Chức vụ / Vai trò (Role)</th>
                            <th class="py-3">Phòng ban / Dữ liệu (Department / Data)</th>
                            <th class="py-3">Email liên hệ (Email)</th>
                        </tr>
                    </thead>
                    <tbody>
                        {% for row in rows %}
                        <tr>
                            <td><span class="fw-semibold text-dark font-monospace">{{ row[0] }}</span></td>
                            <td><span class="badge bg-primary-subtle text-primary border border-primary-subtle px-3 py-1">{{ row[1] }}</span></td>
                            <td><span class="text-secondary">{{ row[2] }}</span></td>
                            <td><span class="text-secondary">{{ row[3] }}</span></td>
                        </tr>
                        {% endfor %}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
""")

# ==============================================================================
# ENDPOINTS XỬ LÝ SAML VÀ SQL INJECTION
# ==============================================================================
@app.route('/')
def index():
    return render_template_string(INDEX_PAGE, title="Trang chủ")

@app.route('/saml/login')
def saml_login():
    return redirect("http://172.20.0.10:8080/realms/sso-lab/protocol/saml")

@app.route('/saml/acs', methods=['POST'])
def saml_acs():
    src_ip = request.headers.get('X-Forwarded-For', request.remote_addr)
    
    # Tiếp nhận NameID từ form test trực tiếp hoặc từ SAMLResponse XML
    nameid = ""
    is_direct = request.form.get('direct_test', 'false') == 'true'
    
    if is_direct:
        nameid = request.form.get('raw_nameid', '').strip()
    else:
        b64_response = request.form.get('SAMLResponse', '')
        if b64_response:
            try:
                xml_bytes = base64.b64decode(b64_response)
                root = etree.fromstring(xml_bytes)
                ns = {'saml': 'urn:oasis:names:tc:SAML:2.0:assertion'}
                nameid_elem = root.xpath('//saml:Subject/saml:NameID', namespaces=ns)
                if nameid_elem and nameid_elem[0].text:
                    nameid = nameid_elem[0].text.strip()
                else:
                    nameid = "unknown_user"
            except Exception as e:
                print(f"[-] XML parse error: {e}", flush=True)
                nameid = "malformed_saml"
        else:
            nameid = "missing_assertion"

    # LỖ HỔNG BẢO MẬT: Ghép chuỗi trực tiếp giá trị NameID vào câu truy vấn SQLite
    query = f"SELECT username, role, department, email FROM users WHERE username = '{nameid}'"
    
    # Kiểm tra dấu hiệu SQLi
    sqli_keywords = ['UNION', 'SELECT', '--', 'OR 1=1', 'OR "1"="1"']
    is_sqli = any(k in nameid.upper() for k in sqli_keywords)

    rows = []
    flag_found = None
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()
        conn.close()

        for r in rows:
            for col in r:
                if isinstance(col, str) and 'FLAG{' in col:
                    flag_found = col
    except Exception as e:
        rows = [("ERROR", "SQL_EXCEPTION", str(e), "")]

    # Ghi nhận log JSON cho Wazuh SIEM
    now_iso = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
    json_event = {
        "timestamp": now_iso,
        "src_ip": src_ip,
        "endpoint": "/saml/acs",
        "method": "POST",
        "saml": {
            "nameid": nameid,
            "auth_method": "PasswordProtectedTransport",
            "issuer": "http://172.20.0.10:8080/realms/sso-lab"
        },
        "sql": {
            "query": query,
            "status": "SUCCESS" if not any(r[0] == "ERROR" for r in rows) else "FAILED",
            "rows_returned": len(rows)
        },
        "alert": "POTENTIAL_SQL_INJECTION" if is_sqli else "NORMAL",
        "message": f"SAML ACS authentication completed for NameID: {nameid}"
    }
    write_json_log(json_event)

    # Nếu có SQLi, ghi nhận log riêng phục vụ đánh giá tự động Goal 1
    if is_sqli:
        write_sqli_log(f"[SQLI_QUERY_EXECUTED] src_ip={src_ip} nameid='{nameid}' query=\"{query}\" flag_exposed={bool(flag_found)}")

    write_auth_log(f"[AUTH] src_ip={src_ip} user={nameid} is_sqli={is_sqli} rows={len(rows)}")

    session['user'] = nameid[:30]
    return render_template_string(
        DASHBOARD_PAGE,
        title="Bảng điều khiển",
        rows=rows,
    )

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

@app.route('/api/logs')
def api_logs():
    """Endpoint trả về 10 log JSON gần nhất"""
    logs = []
    if os.path.exists(APP_JSON_LOG):
        with open(APP_JSON_LOG, 'r') as f:
            for line in f.readlines()[-10:]:
                if line.strip():
                    try:
                        logs.append(json.loads(line.strip()))
                    except Exception:
                        pass
    return jsonify(logs)

if __name__ == '__main__':
    print("[*] Enterprise SAML SP Portal starting on 0.0.0.0:5000...", flush=True)
    app.run(host='0.0.0.0', port=5000)
