# Labtainers: SAML SQL Injection & Wazuh SIEM Active Response (saml-wazuh-sqli)

## 📌 Tổng quan bài thực hành
Bài lab mô phỏng kịch bản diễn tập thực chiến Red Team & Blue Team:
- **Red Team**: Khai thác lỗ hổng **SQL Injection (CWE-89)** thông qua tham số `NameID` trong vé xác thực SAML 2.0 để trích xuất Secret Flag từ cơ sở dữ liệu.
- **Blue Team**: Xây dựng **Custom Rule trên Wazuh SIEM** để phân tích nhật ký JSON từ ứng dụng Flask và tự động kích hoạt **Active Response (firewall-drop via iptables)** chặn vĩnh viễn IP kẻ tấn công.

---

## 🏗️ Kiến trúc bài lab (3 Container)
- **`sp-server` (`172.20.0.10`)**: 
  - Service Provider Flask Portal (Port 5000) dính lỗi SQLi.
  - Keycloak SAML Identity Provider (Port 8080).
  - Wazuh Agent & iptables firewall-drop.
- **`wazuh-manager` (`172.20.0.30`)**:
  - Máy chủ giám sát trung tâm Wazuh Server / SIEM.
  - File cấu hình quy tắc: `/var/ossec/etc/rules/local_rules.xml`.
  - Điều phối Active Response.
- **`student-pc` (`172.20.0.20`)**:
  - Máy trạm kiểm thử của sinh viên (Firefox, Burp Suite, Python3).
  - Lệnh đánh giá: `checkwork`.

---

## 🎯 5 Tiêu chí đánh giá tự động (checkwork Goals)
| Mục tiêu | Mô tả tiêu chí đánh giá |
| :--- | :--- |
| `1_sqli_executed` | Log của Flask ghi nhận payload SQLi đã chạy thành công ở Giai đoạn 1. |
| `2_wazuh_rule_created` | Xác nhận sinh viên đã tạo thành công rule phát hiện SQLi trong `/var/ossec/etc/rules/local_rules.xml`. |
| `3_active_response_triggered` | Log `/var/ossec/logs/active-responses.log` ghi nhận lệnh block IP đã được thực thi. |
| `4_attacker_blocked` | Hệ thống mạng xác nhận `student-pc` bị chặn kết nối hoàn toàn tới `sp-server` ở tầng iptables. |
| `5_flag_submitted` | Sinh viên nộp cờ bí mật vào hệ thống (`submit_flag <FLAG>`). |

---

## 🚀 Khởi động bài lab
```bash
labtainer saml-wazuh-sqli
```
Chi tiết các bước thực hành xem tại [INSTRUCTIONS.md](docs/INSTRUCTIONS.md).
