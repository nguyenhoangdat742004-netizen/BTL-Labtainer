import numpy as np
import soundfile as sf

# ==========================================
# 1. Đọc file âm thanh đã giấu tin (Stego)
# ==========================================
audio, sample_rate = sf.read("stego.wav")

# Xử lý lấy kênh đầu tiên nếu là âm thanh Stereo (2 kênh)
if len(audio.shape) > 1:
    audio_signal = audio[:, 0]
else:
    audio_signal = audio

# ==========================================
# 2. Cấu hình tham số giải mã (Giống phía gửi)
# ==========================================
pn_code = np.array([1, -1, 1, 1, -1, 1, -1, -1])
chips_per_bit = len(pn_code)

# Số bit cần khôi phục ("HELLO" = 5 ký tự * 8 bit = 40 bits)
num_bits = 40

# ==========================================
# 3. Trích xuất tín hiệu DSSS & Giải phổ
# ==========================================
recovered_bits = []

for i in range(num_bits):
    start = i * chips_per_bit
    end = start + chips_per_bit
    segment = audio_signal[start:end]
    
    # Tính độ tương quan (Correlation)
    correlation = np.sum(segment * pn_code)
    
    # Quyết định ngưỡng (Thresholding) dựa trên BPSK
    if correlation > 0:
        recovered_bits.append(1)
    else:
        recovered_bits.append(0)

# ==========================================
# 4. Chuyển đổi chuỗi Bit thành Văn bản (ASCII)
# ==========================================
chars = []
for i in range(0, len(recovered_bits), 8):
    byte = recovered_bits[i:i+8]
    byte_str = ''.join(map(str, byte))
    # Đảm bảo không bị lỗi nếu chuỗi bit rỗng hoặc lỗi format
    if byte_str:
        chars.append(chr(int(byte_str, 2)))

message = ''.join(chars).strip()

# ==========================================
# 5. In kết quả chuẩn chỉnh trên cùng 1 dòng
# ==========================================
print(f"Recovered Message: {message}")
